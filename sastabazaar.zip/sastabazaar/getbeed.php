<?php
    require_once 'conn.php';
    $sel=mysql_query("select price from product where productid='$_REQUEST[how]'");
    $sell=mysql_fetch_array($sel);
    //echo $sell[0];
    if($sell[0]<$_REQUEST[price])
    {
        
        
            $date=date('Y-m-d');
        mysql_query("insert into beed values (0,'$_REQUEST[how]','$_SESSION[user]','$_REQUEST[price]','$date')");
        
        
        
    }
    
        
   ?>
    <div>
                        <h3>show beed</h3>
                        <div class="gbm">
                        <?php
                            $dd=  mysql_query("select * from beed where productid=$_REQUEST[how] order by bprice desc");
                            while($dd1=  mysql_fetch_array($dd))
                            {
                                $dr=  mysql_query("select image,name from registration where userid='$dd1[2]'");
                                $dr1=  mysql_fetch_array($dr);
                        ?>
                        
                            <div style="float: left;">
                                <img src="<?php echo $dr1[0]; ?>" width="100px" height="100px" style="border-radius:150px;"/>
                            </div>
                            <div class="ree">
                                <div class="gbm1">
                                    <?php echo $dr1[1]; ?>
                                </div>
                                <div class="gbm1">
                                    <?php echo $dd1[3]; ?>
                                </div>
                                <div class="gbm1">
                                    <?php echo $dd1[4]; ?>
                                </div>
                            </div>
                            <div style="clear: both;">
                                
                            </div>    
                        
                                                            <?php
                                                                }
                                                            ?>
                            </div>
    </div>
