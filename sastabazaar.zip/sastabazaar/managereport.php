<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
        
    $perpage=2;
    $ketla=mysql_query("select count(billid) from bill");
    $chhe=mysql_fetch_array($ketla);
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
        <script>
        $(".document").ready(function(){
            $(".mainp").hide();
            $(".tbutton").click(function(){
                $(".mainp").toggle(1000);  
            });
        });
        
        </script>
        <script type="text/javascript">
            function printdiv()
            {
                var p=document.getElementById('print');
                var pp=window.open("","_blank");
                
                pp.document.open();
                pp.document.write('<html><body onload="window.print()">'+p.innerHTML+'</html>');
                pp.document.close();
            }
        </script>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
          <div class="manag" id="report">
              <h3>manage report
              <div style="float: right;margin-right: 20px;">
                        <?php
                            $cont=  mysql_query("select count(billid) from bill");
                            $contt=  mysql_fetch_array($cont);
                            echo "total report are : ".$contt[0];
                        ?>
              </div>
              </h3><br>
              <div class="tbutton">
                      <button type="submit" name="report">Report Search</button>
              </div>
              <div class="mainp" style="background: white;margin-left: 10px;border: 1px solid #e44f2b;font-size: 12px;">
                  
                  <div class="bpenal1">
                      <table>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">B</b>uyer&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="userbill(this.value);">
                                      <option>--select--</option>
                                      <?php
                                            $u=  mysql_query("select distinct(userid) from bill");
                                            while($uu=  mysql_fetch_array($u))
                                            {
                                      ?>
                                      <option value="<?php echo $uu[0]; ?>"><?php echo $uu[0]; ?></option>

                                      <?php
                                            }
                                      ?>
                                    </select>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">B</b>ill <b style="color: #e44f2b;font-size: 17px;">N</b>o&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="trabon(this.value);">
                                      <option>--select--</option>
                                      <?php
                                            $b=  mysql_query("select billid from bill");
                                            while($bi=  mysql_fetch_array($b))
                                            {
                                      ?>
                                      <option value="<?php echo $bi[0]; ?>"><?php echo $bi[0]; ?></option>

                                      <?php
                                            }
                                      ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">C</b>ountry&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="tracon(this.value);">
                                      <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from country");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[1]?>"><?php echo $row[1]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">S</b>tate&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="trasta(this.value);">
                                       <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from state");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[2]?>"><?php echo $row[2]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">C</b>ity&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="tracity(this.value);">
                                       <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from city");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[2]?>"><?php echo $row[2]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                      </table>
                  </div>
                  <div class="tpenal3">
                      <table>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">A</b>mount&nbsp;&nbsp;:&nbsp;</td>
                              <td>
                                    <input type="text" name="lp" style="padding: 5px;width: 74px;" id="lop"/>
                                    <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                    <input type="text" name="hp" style="padding: 5px;width: 74px;" id="hip"/>
                                    <img src="images/update2.png" width="25px" style="vertical-align: middle;" onclick="lohip1(document.getElementById('lop').value,document.getElementById('hip').value);"/>
                              </td>
                          </tr>    
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">D</b>ate&nbsp;:&nbsp;</td>
                              <td>
                                    <input type="text" name="date" style="padding: 5px;width: 74px;" id="datee"/>
                                    <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                    <input type="text" name="date" style="padding: 5px;width: 74px;" id="date1"/> 
                                    <img src="images/update2.png" width="25px" style="vertical-align: middle;" onclick="datee1(document.getElementById('datee').value,document.getElementById('date1').value);"/>
                              </td>    
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">M</b>onth&nbsp;:&nbsp;</td>
                              <td>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mon1"/>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mon2"/>
                                  <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mon3"/>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mon4"/>
                                <img src="images/update2.png" width="25px" style="vertical-align: middle;" onclick="month4(document.getElementById('mon1').value,document.getElementById('mon2').value,document.getElementById('mon3').value,document.getElementById('mon4').value);"/>
                              </td>    
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">Y</b>ear&nbsp;:&nbsp;</td>
                              <td>
                                  <input type="text" name="date" style="padding: 5px;width: 74px;" id="year"/>
                                  <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                 <input type="text" name="date" style="padding: 5px;width: 74px;" id="year1"/> 
                                <img src="images/update2.png" width="25px" style="vertical-align: middle;" onclick="yearr1(document.getElementById('year').value,document.getElementById('year1').value);"/>
                              </td>    
                          </tr>
                      </table>
                  </div>
              </div>
              <div class="tmain" id="utra">
                     
              </div>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>