<?php
    require_once 'conn.php';
    $_SESSION[page]="contact";
    if(isset($_REQUEST[click]))
    {
        if($_REQUEST[name]=="")
        {
            $ename=1;
        }
        if($_REQUEST[email]=="")
        {
            $eemail=1;
        }
        if($_REQUEST[mobile]=="")
        {
            $emobile=1;
        }
        if($_REQUEST[message]=="")
        {
            $emessage=1;
        }
        $pname='/^[a-zA-Z ]+$/';
        if(!preg_match($pname, $_REQUEST[name]))
        {
            $ename2=1;
        }
        $pmobile='/^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]+$/';
        $pmobile1='/^..........$/';
        if(!preg_match($pmobile, $_REQUEST[mobile]) || !preg_match($pmobile1, $_REQUEST[mobile]))
        {
            $emobile2=1;
        }
        if($ename!=1 && $eemail!=1 && $emobile!=1 && $emessage!=1 && $ename2!=1 && $emobile2!=1)
        {
            $in=mysql_query("insert into contact values(0,'$_REQUEST[name]','$_REQUEST[email]','$_REQUEST[mobile]','$_REQUEST[message]')");
            $send=1;
        }
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  		    <?php
                        require_once 'menu.php';
                    ?>
    </div>
</div>
 <div class="main">
 	<div class="wrap">
     <div class="preview-page">
     				<div class="contact_info">
                                    <div class="map">
                                            <iframe width="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#888;text-align:left;font-size:0.85em">View Larger Map</a></small>
                                    </div>
      				</div>
         
				  <div class="contact-form" style="font-size: 15px;">
				  	<h3><b style="color: #e44f2b;font-size: 18px;">C</b>ontact <b style="color: #e44f2b;font-size: 18px;">U</b>s</h3>
					    <form method="post" action="" name="contact">
                                                <table>
                                                    <tr>
                                                        <td colspan="2">
                                                           <?php
                                                                if($send==1)
                                                                {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                                                }
                                                            ?> 
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <input name="name" type="text" placeholder="Enter Name"/>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($ename==1)
                                                                {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                                                }
                                                                else
                                                                {
                                                                    if($ename2==1)
                                                                    {
                                                                        echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                                                    }
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <input name="email" type="email" placeholder="Enter Email"/>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($eemail==1)
                                                                {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <input name="mobile" maxlength="10" type="text" placeholder="Enter Mobile" />
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($emobile==1)
                                                                {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                                                }
                                                                else
                                                                {
                                                                    if($emobile2==1)
                                                                    {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                                                    }
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <span><textarea name="message" placeholder="Enter Message" ></textarea></span>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($emessage==1)
                                                                {
                                                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    
                                                </table>     
						   <div class="clear"></div>
						   <div>
						   		<button type="submit" value="Submit"  class="feedbackbutton" name="click">Submit</button>
						   		<button type="reset" class="feedbackbutton" name="clear">Clear</button>
                                                                <div class="clear"></div>
						  </div>
                                                   <font style="font-size: 10px;color: red;">note : * blank | ^ invalid </font>
					    </form>
				  </div>
                                <div class="contact" style="font-size: 15px;">
                                    <h3><b style="color: #23272a;font-size: 18px;">C</b>ompany <b style="color: #23272a;font-size: 18px;">I</b>nformation :</h3>
                                    sastabazaar<br><br>
                                    address:185/ravidarshan society,<br>near shyamdham chowk, <br>nanavarachha,surat,<br> gujarat,india<br>
                                    pincode:395006<br><br>
                                    fax_no:+44 (0)20 3147 4872<br><br>
                                    telephone_no:0261 25525525<br><br>
                                    email address:sastabazaar2015@gmail.com
                                </div>    
                    </div>		
         </div> 
    </div>
 </div>
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

