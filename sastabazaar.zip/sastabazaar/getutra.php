<?php
    require_once 'conn.php';
    
    if($_REQUEST[buyer]!="")
    {
        $gb=  mysql_query("select * from bill where userid='$_REQUEST[buyer]'");
    }
    if($_REQUEST[tbn]!="")
    {
        $gb=  mysql_query("select * from bill where billid='$_REQUEST[tbn]'");
    }
    if($_REQUEST[tc]!="")
    {
        $gb=  mysql_query("select b.*,r.* from bill b,registration r where b.userid=r.userid and r.country='$_REQUEST[tc]'");
    }
    if($_REQUEST[ts]!="")
    {
        $gb=  mysql_query("select b.*,r.* from bill b,registration r where b.userid=r.userid and r.state='$_REQUEST[ts]'");
    }
    if($_REQUEST[tcty]!="")
    {
        $gb=  mysql_query("select b.*,r.* from bill b,registration r where b.userid=r.userid and r.city='$_REQUEST[tcty]'");
    }
    if($_REQUEST[lop]!="")
    {
        $gb=  mysql_query("select * from bill where amount between $_REQUEST[lop] and $_REQUEST[hip]");
    }
    
?>


<div class="thead">
                      <b>s</b>ummery &nbsp;&nbsp;<b>r</b>eport&nbsp;&nbsp; <b>o</b>f&nbsp;&nbsp; <b>t</b>ransaction &nbsp;&nbsp;<b>o</b>f &nbsp;&nbsp;<b>y</b>our &nbsp;&nbsp;<b>f</b>rom
                      <button type="submit" onclick="printdiv();">&nbsp;&nbsp;Print&nbsp;&nbsp;</button>
                  </div>
                  <div class="thead1" id="print">
                      <div>
                          <form method="post" action="">
                          <table width="100%">
                              <tr>
                                  <th>transaction no</th>
                                  <th>bill no</th>
                                  <th>transaction date</th>
                                  <th>user</th>
                                  <th>amount</th>
                              </tr>
                              <?php
                                    $c=0;
                                    while($row=mysql_fetch_array($gb))
                                    {
                                        $c++;
                              ?>
                              <tr>
                                  <td><?php echo $c; ?></td>
                                  <td><?php echo $row[0]; ?></td>
                                  <td><?php echo $row[4]; ?></td>
                                  <td><?php echo $row[1]; ?></td>
                                  <td><?php echo $row[2]; ?></td>
                              </tr>
                              <?php
                                    }
                              ?>
                          </table>
                      </form>
                      </div>
                      <div style="background: #23272a;color: white;font-size: 15px;padding: 10px;border: 1px solid #e44f2b;">
                          <?php
                                        $r=  mysql_query("select sum(amount) from bill where userid='$_REQUEST[buyer]'");
                                        $rr=  mysql_fetch_array($r);
                          ?>
                          <font style="font-size: 15px;padding-left:1122px;"><b style="color: #e44f2b;font-size: 18px;">T</b>otal&nbsp; <b style="color: #e44f2b;font-size: 18px;">A</b>mount &nbsp;: &nbsp;<?php echo $rr[0]; ?>&nbsp;<b style="color: #e44f2b;">&#8377;</b></font>    
                      </div>
                  </div> <br>
