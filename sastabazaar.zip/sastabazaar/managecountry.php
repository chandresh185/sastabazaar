<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(countryid) from country");
    $chhe=mysql_fetch_array($ketla);
        if(isset($_REQUEST[send]))
        {
            if($_REQUEST[name]=="")
            {
                $ename=1;   
            }
            $pname='/^[a-zA-Z ]+$/';
            if(!preg_match($pname, $_REQUEST[name]))
            {
                $ename1=1;
            }
            $g=mysql_query("select * from country ");
            while($gg=  mysql_fetch_array($g))
            {
                if(stristr($gg[1],$_REQUEST[name]))
                {
                    $ename2=1;
                }
            }
            if($ename!=1 && $ename1!=1  && $ename2!=1)
           {
               $in=mysql_query("insert into country values(0,'$_REQUEST[name]')");
               $send=1;
               header('location:managecountry.php?base=1#country');
           }
        }
?>

<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="country();">
    <script type="text/javascript">
        $(".document").ready(function(){
            $(".cadd").hide();
            $(".cbutton").click(function(){
                $(".cadd").toggle(1000);  
            });
        });
        
        </script>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          
        <?php
        require_once 'cover.php';
        ?>
        <div class="managecountry" id="country">
                    <h3>manage country
                    <div style="float: right;margin-right: 20px;">
                        <?php
                            $cont=  mysql_query("select count(countryid) from country");
                            $contt=  mysql_fetch_array($cont);
                            echo "total country are : ".$contt[0];
                        ?>
                    </div>
                    </h3><br>
                    <div class="cmain">
                        <button class="cbutton" type="submit" value="Submit" name="send">Add Here</button>  
                        <input type="text" name="search" onkeyup="search1(this.value,'country');" placeholder="Search Here" />
                        <a href="delete.php?all=country"><img src="images/delete2.png" title="delete all records" width="30px" style="vertical-align: middle;"/></a>
                    </div>
                    <div class="cadd">
                        <form method="post" action="">
                        <?php
                            if($send==1)
                            {
                                echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                            }
                        ?>
                        <table>
                            <tr>
                                <td>
                                    <input type="text" name="name" placeholder="Enter Your country"/>
                                </td>
                                <td>
                                    <?php
                                        if($ename==1)
                                        {
                                            echo "<font color=red size=3px>*</font>";
                                        }
                                        else
                                        {
                                            if($ename1==1)
                                            {
                                                echo "<font color=red size=3px>^</font>";
                                            }
                                            else
                                            {
                                                if($ename2==1)
                                                {
                                                    echo "<font color=red size=3px><-</font>";
                                                }  
                                            }
                                        }                                                                    
                                     ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <button type="submit" value="Submit" name="send">Submit</button>     
                                    <button type="reset" name="clear">Clear</button>
                                    <div class="clear"></div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <br><font style="font-size: 10px;color: red;">note : * blank | ^ invalid | <- duplication</font>
                                </td>
                            </tr>
                        </table>
			</form>
                    </div>
                    <div class="cdis">
                        <form method="post" action="">
                            <center>
                                <table id="disid" width="100%">
                                    <th>name</th>
                                    <th>delete</th>
                                    <th>update</th>
                                     <?php
                                        $no=$_REQUEST[base];
                                        $st=($no*$perpage)-$perpage;
                                        $data=mysql_query("select * from country limit $st,$perpage");
                                        while($row=mysql_fetch_array($data))
                                        {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=country"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>
                                        <td>
                                            <a href="upcountry.php?id=<?php echo $row[0]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                        </td>
                                    
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                     
                                </table><br>
                                <ul align="center">
                                                <?php
                                                    $page=$chhe[0]/$perpage;
                                                    $page=ceil($page);
                                                    if($page>5)
                                                    {
                                                        if($_REQUEST[base]>=1 && $_REQUEST[base]<=5)
                                                        {
                                                            $start=1;
                                                            $end=5;
                                                        }
                                                        else
                                                        {
                                                            if($_REQUEST[next]<=$page)
                                                            {
                                                                $start=$_REQUEST[next]-4;
                                                                $end=$_REQUEST[next];
                                                            }
                                                        }  
                                                    }
                                                    else
                                                    {
                                                        $start=1;
                                                        $end=$page;
                                                    }
                                                    if($start>=1 && $end<=5)
                                                    {
                                            
                                                    }
                                                    else
                                                    {
                                                ?>
                                                <li style="background: #23272a;"><a href="managecountry.php?next=<?php if($end>1){echo $end-1;}else{echo $page;} ?>&base=<?php if($end>1){echo $end-1;}else{echo $page;} ?>#country" style="color: white;"><</a></li>
                                                <?php
                                            
                                                }
                                                for($i=$start;$i<=$end;$i++)
                                                {
                                            
                                                    if($i==$_REQUEST[base])
                                                    {
                                                ?>
                                                <li style="background: #e44f2b;border:1px solid #23272a;"><a href="managecountry.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#country" style="color: white;"><?php echo $i; ?></a></li>
                                                <?php
                                            
                                                    }
                                                    else
                                                    {
                                                ?>
                                                <li style="background: #23272a;"><a href="managecountry.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#country" style="color: white;"><?php echo $i; ?></a></li>
                                                <?php
                                                }
                                            } 
                                        
                                                if($page>5)
                                                {
                                     
                                            ?>
                                            <li style="background: #23272a;"><a href="managecountry.php?next=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>&base=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>#country" style="color: white;">></a></li>
                                            <?php
                                                }
                                            ?>
                                            </ul><br>
                            </center>
                        </form>
                    </div>
            </div>
        <div style="clear: both;">
            
        </div>     
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
