<!DOCTYPE HTML>
<?php
    require_once 'conn.php';
    $b=mysql_query("select max(billid) from bill where userid='$_SESSION[user]'");
    $bb=mysql_fetch_array($b);
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=2)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    require_once 'head.php';
?>
<body onload="billl('<?php echo $bb[0]; ?>');">
        <script type="text/javascript">
            function printdiv()
            {
                var p=document.getElementById('print');
                var pp=window.open("","_blank");
                
                pp.document.open();
                pp.document.write('<html><body onload="window.print()">'+p.innerHTML+'</html>');
                pp.document.close();
            }
        </script>
	<?php
            require_once 'updatebcover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'bcover.php';
          ?>
          <div class="adminright" id="bill">
              <div class="cp" style="margin-left: 30px;margin-top: 1px;">
                  <a href="buyerhome.php#buyerhome" style="color: white;">&vltri;</a>
              </div>
              <div class="bselect">
                  <b>B</b>ill <b>N</b>o&nbsp;&nbsp;:&nbsp;&nbsp;
                  <select onchange="billl(this.value);">
                  <?php
                        $p=mysql_query("select billid from bill where userid='$_SESSION[user]' order by billid desc");
                        while($pp=mysql_fetch_array($p))
                        {
                  ?>
                  <option value="<?php echo $pp[0]; ?>"><?php echo $pp[0]; ?></option>
                  <?php
                        }
                  ?>
                  </select>
                  
              </div>
              <div class="bamount">
                  <b>A</b>mount&nbsp;&nbsp;:&nbsp;
                  <input type="text" name="lp" id="lp"/>
                    <b>&nbsp;to&nbsp;</b> 
                  <input type="text" name="hp" id="hp"/>
                  <img src="images/update2.png" width="20px" style="vertical-align: middle;" onclick="lphp(document.getElementById('lp').value,document.getElementById('hp').value);"/>
              </div>
              <br>
              <div class="bmain" id="print">
                  
              </div><br>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>