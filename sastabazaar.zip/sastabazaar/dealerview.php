<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="setdealerhistory();">   
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'ucover.php';
          ?>
          <div class="adminright" id="vpost">
              <div class="cp">
                  <a href="dealerhome.php#dealerhome" style="color: white;">&vltri;</a>
              </div>
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;float: left;margin-top: 30px;height: 420px;width: 50px;margin-left: 100px;">
                  <br><br>a<br>c<br>t<br>i<br>v<br>e<br><br> p<br>o<br>s<br>t
              </div>
              <div class="cp" style="margin-top: 460px;">
                  <a href="dealerhome.php#dealerhome" style="color: white;">&vltri;</a>
              </div>
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;position: absolute;margin-top: 500px;height: 417px;width: 50px;margin-left: 100px;">
                  <br><br>d<br>e<br>a<br>c<br>t<br>i<br>v<br>e<br><br> p<br>o<br>s<br>t
              </div>
              <div class="cp" style="margin-top: 930px;">
                  <a href="dealerhome.php#dealerhome" style="color: white;">&vltri;</a>
              </div>
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;position: absolute;margin-top: 970px;height: 417px;width: 50px;margin-left: 100px;">
                  <br><br>h<br>i<br>s<br>t<br>o<br>r<br>y
              </div>
              <div id="dehisid">
                  
              </div><br>
              <div style="clear: both;"></div>
         </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
