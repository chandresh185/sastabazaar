<?php
    require_once 'conn.php';
    if($_SESSION[hardik]=="")
    {
        header('location:buyerhome.php');
    }
    if(isset($_REQUEST[pay]))
    {
//        $pa1=  mysql_query("select total from cart where userid='$_SESSION[user]' and productid='$_REQUEST[id]'");
//        $ppa1=mysql_fetch_array($pa1);
//        $tot=$tot+$ppa1[0];
        
        $y=date(Y);
        $m=date(m);
        $d=date(d);
        $date=$y."-".$m."-".$d;
        $h=date(h);
        $mm=date(i);
        $s=date(s);
        $time=$h.":".$mm.":".$s;
        $dt=$date." ".$time;
        $inn2=mysql_query("insert into bill values(0,'$_SESSION[user]','$_SESSION[hardik]'+'$_SESSION[sp]',0,'$dt','$_SESSION[mt]','$_SESSION[mv]','$_SESSION[add]')");
        
        $m=mysql_query("select max(billid) from bill where userid='$_SESSION[user]'");
        $mm1=mysql_fetch_array($m);
        
        $s=mysql_query("select * from cart where userid='$_SESSION[user]'");
        while($ss=  mysql_fetch_array($s))
        {
            $k=mysql_query("delete from wishlist where productid=$ss[1] and userid='$_SESSION[user]'");
            $g1=mysql_query("insert into tra values(0,'$mm1[0]','$ss[1]','$ss[4]','$ss[3]','$ss[5]')");
            //echo $g1;
            $up=mysql_query("update product set stock=stock-$ss[3] where productid=$ss[1]");
        }
        $d=mysql_query("delete from cart where userid='$_SESSION[user]'");
        
        unset ($_SESSION[mt]);
        unset ($_SESSION[hardik]);
        unset ($_SESSION[maintot]);
        unset ($_SESSION[mv]);
        unset ($_SESSION[add]);
        unset ($_SESSION[sp]);
        
        header('location:http://www.paypal.com/cgi-bin/webscr');
        
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main">
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap">
		          	   <h3>Latest Products</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
			                   <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
    	  <div class="content_bottom">
              <div style="padding: 10px;">
                   <?php
                        $name=  mysql_query("select name from registration where userid='$_SESSION[user]'");
                        $n=  mysql_fetch_array($name);
                   ?>
                  <p>Payable Amount :<font>&#8377;<?php echo $_SESSION[hardik]+$_SESSION[sp]; ?></font></p>
                  <hr>
                  <form action="" method="post" name="pay">
                      <input type="hidden" name="ceo" value="SastaBazaar"/>
                      <input type="hidden" name="business" value="SastaBazaar"/>
                      <input type="hidden" name="currency" value="rupees"/>
                      <input type="hidden" name="amount" value="<?php echo $_SESSION[hardik]+$_SESSION[sp]; ?>"/>
                      <br>
                      <p style="text-transform: capitalize;margin-left: 15px;">
                          Hey,<?php echo $n[0]; ?>you have pay total amount is <font style="color: #e44f2b;">&#8377;<?php echo $_SESSION[hardik]+$_SESSION[sp]; ?></font>
                      </p>
                      <br>
                      <button type="submit" name="pay" >
                          <img src="http://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"/>
                          
                      </button>    
                      <br>
                      <p>
                          Make payment with paypal- it's Fast,free & secure !
                      </p>
                  </form>
              </div>
         </div>
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

