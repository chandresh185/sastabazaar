<!DOCTYPE HTML>
<?php
    require_once 'conn.php';
    
    if($_SESSION[user]=="")
    {
        header('location:index.php');
    }
    else
    {
        if($_SESSION[user]!="")
        {
            $ekk=mysql_query("select * from cart where userid='$_SESSION[user]' and productid= '$_REQUEST[id]'");
        
            $ekk1=  mysql_fetch_array($ekk);
            //echo $ekk1[1];
            
            if($ekk1[0]=="")
            {
                $get=mysql_query("select price from product where productid=$_REQUEST[id]");
                $gett=mysql_fetch_array($get);
                $in=mysql_query("insert into cart values(0,$_REQUEST[id],'$_SESSION[user]',1,$gett[0],$gett[0])");
                //header('location:index.php');
            }
        }
    }
    require_once 'head.php';
?>
    <body>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'bcover.php';
          ?>
              <div style="padding: 1px;">
                <div class="managecart" id="cart">
               
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;float: left;height: 450px;width: 50px;margin-left: 100px;">
                  <br><br>c<br>o<br>n<br>f<br>i<br>r<br>m<br><br> p<br>r<br>o<br>d<br>u<br>c<br>t
              </div><br>
                <div style="margin-left: 10px;margin-bottom: 10px;">
                <form method="post" action="">
                  <center>
                      <table id="price" width="70%">
                            <th>no</th>
                            <th>product image</th>
                            <th>product name</th>
                            <th>price</th>
                            
                            <th>qty</th>
                            <th>total price</th>
                           
                            <?php
                                    $c=0;
                                    $all=mysql_query("select p.productname,c.* from product p,cart c where p.productid=c.productid and c.userid='$_SESSION[user]'");
                                    while($rec=  mysql_fetch_array($all))
                                    {
                                        $set=mysql_query("select productimage from product_mstr2 where productid='$rec[2]'");
                                        $set1=mysql_fetch_array($set);
                                        $c++;  
                            ?>
                            <tr align="center">
                                
                                <td>
                                    <?php
                                        echo $c; 
                                    ?>
                                </td>
                                <td>
                                   <img src="<?php echo $set1[0]; ?>" style="border-radius:3px;width: 50px;height: 60px;"/>
                                </td>
                                <td>
                                    <?php
                                        echo "$rec[0]"; 
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo "$rec[5]"; 
                                    ?>
                                </td>
                                
                                <td>
                                   <?php
                                        echo $rec[4];
                                   ?>
                                </td>
                                <td>
                                    <?php
                                       
                                        echo $rec[5]*$rec[4]; 
                                    ?>
                                </td>
                             
                            </tr>
                            <?php
                                $tot=$rec[5]*$rec[4];
                                $maintot=$maintot+$tot;
                                }
                            ?>       
                            
                            <tr id="grandid" >
                                
                                <td colspan="7" style="background: #23272a;padding: 15px;color: white;text-align: right;font-size: 15px;font-weight: bold;">
                                    grand total :
                                        <?php
                                           echo $maintot;
                                        ?>
                                </td>
                            </tr>
                            <tr align="right" >
                                <td colspan="7">
                                    <a href="managecart.php" style="background: #23272a;color: white;font-size: 12px;padding: 10px;text-decoration: none;">back to cart</a>
                                    <a href="payment.php" style="background: #23272a;color: white;font-size: 12px;padding: 10px;text-decoration: none;">confirm</a>
                                </td>
                            </tr>
                      </table>
                  </center>
                </form>  
                </div>
              </div>
            </div>    
          <div style="clear: both;">
              
          </div>
     </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
                    
