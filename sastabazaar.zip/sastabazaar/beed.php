<?php
    require_once 'conn.php';
    $cc=0;
    $data11=  mysql_query("select * from product_mstr2 where productid='$_REQUEST[id]'");
    while($row11=  mysql_fetch_array($data11))
    {
        $cc++;
        if($cc==1)
        {
            $pat=$row11[2];
            break;
        }
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="getphoto1('<?php echo $pat; ?>');">
        
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main">
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap">
		          	   <h3>Latest Products</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
                                            <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
            <div class="content_bottom">
                <div>
                    <div class="auction1">
                        auction
                    </div>
                </div>
                <div style="padding: 10px;">
                    <?php
                        $data=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                        while($row1= mysql_fetch_array($data))
                                        {
                    ?>
                    <div class="date">
                        <br><center><?php echo $row1[13]; ?></center>
                    </div>
                    <div class="date1">
                        <center>Date</center>
                    </div>
                    <div class="price">
                        <br><center><?php echo $row1[8]; ?></center>
                    </div>
                    <div style="background: #23272a;border-radius:3px;text-transform: capitalize;float: right;margin-top: 115px;margin-right:-120px;width:100px;color: white;padding: 10px;">
                        <center>price</center>
                    </div>
                    <div class="imagem" style="margin-left: 430px;width: 450px;">
                        <?php
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[5]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c==1)
                                                {
                                                    ?>
                        <div id="acphoto">
                            
                        </div>
                        
                        <?php
                                                }
                                                if ($c!=0)
                                                {
                        ?>
                        <div style="display: inline;">
                            <img src="<?php echo $row2[2]; ?>" onclick="getphoto1('<?php echo $row2[2]; ?>');" class="aphoto" onclick="mjj()"/>
                        </div>     
                        <?php
                                                }
                                            }
                       ?>
                           
                    </div>
                    <div class="gb3" id="beedd">
                        <h3>show beed</h3>
                        <div class="gbm">
                            <?php
                                 $dd=  mysql_query("select * from beed where productid='$row1[5]' order by bprice desc");
                                 while($dd1=  mysql_fetch_array($dd))
                                 {
                                    $dr=  mysql_query("select image,name from registration where userid='$dd1[2]'");
                                    $dr1=  mysql_fetch_array($dr);
                            ?>
                            <div style="float: left;">
                                <img src="<?php echo $dr1[0]; ?>" width="100px" height="100px" style="border-radius:150px;"/>
                            </div>
                            <div class="ree">
                                <div class="gbm1">
                                    <?php echo $dr1[1]; ?>
                                </div>
                                <div class="gbm1">
                                    <?php echo $dd1[3]; ?>
                                </div>
                                <div class="gbm1">
                                    <?php echo $dd1[4]; ?>
                                </div>
                            </div>
                            <div style="clear: both;">
                                
                            </div>  
                            <?php
                                 }
                            ?>
                        </div>
                    </div>
                     <?php
                        if($_SESSION[type]=="2")
                        {
                     ?>
                    <div class="gb1">
                        <h3>give beed</h3>
                        <div class="bgb">
                            <form method="post" action="">
                                <input type="text" id="beed" name="beed1" placeholder="Enter Beed Price"/>
                                
                                <br><button type="button" name="gbeed" onclick="getbeed1('<?php echo $row1[5]; ?>');"><center>Beed</center></button>
                                <button type="reset"><center>Clear</center></button>
                            </form>
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                                            <?php
                                                }
                                            ?>
                    <div style="clear: both;"></div>
                </div>
                <?php
                                        }
                ?>
            </div>
         </div>
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

