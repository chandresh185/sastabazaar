<?php
    require_once 'conn.php';
?>

<div>
                                <ul>
                                    <?php
                                        $n=0;
                                        if($_REQUEST[shu]=="nathi")
                                        {
                                            $data=mysql_query("select * from product where maincateid='5' and auction='0' and active=1 and producttype='old' limit 0,$_REQUEST[how1]");
                                        }
                                        else
                                        {
                                            $u=mysql_query("select userid from registration where name like '$_REQUEST[shu]'");
                                            $uu=mysql_fetch_array($u);
                                            
                                            $data=mysql_query("select * from product where maincateid='5' and auction='0' and active=1 and producttype='new' and userid like '$uu[0]'");
                                        }
                                        while($row1= mysql_fetch_array($data))
                                        {
//                                            $n++;
//                                            if($n>9)
//                                            {
//                                                break;
//                                            }
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[5]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c>1)
                                                {
                                                    break;
                                                }
                                    ?>
                                    <div>
                                    <li style="display: inline;">
                                        <div style="padding: 10px;">
                                            <div style="float: left;">
                                                <img width="230px" height="325px" src="<?php echo $row2[2];?>" style="border-radius:5px;box-shadow:1px 1px 1px #e44f2b;"/>
                                            </div>
                                            <div style="background: white;float: left;width: 630px;height: 305px;padding: 10px;border-radius:5px;margin-left: 10px;box-shadow:1px 1px 1px #23272a;" class="pro2">
                                                <table width="100%">
                                                    <tr>
                                                        <td colspan="2">
                                                            <div style="background: #e44f2b;padding: 5px;color: white;">
                                                                <center><b style="color: #23272a;">D</b>etail</center>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="12%"><b>I</b>tems <b>N</b>ame : </td>
                                                        <td><?php echo $row1[6]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>C</b>ompany :</td>
                                                        <td>
                                                            <?php
                                                            $g=mysql_query("select * from company where companyid=$row1[4]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[2];
                                                        ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>D</b>iscription :</td>
                                                        <td><?php echo $row1[7]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>P</b>rice :</td>
                                                        <td><?php echo $row1[8]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="vertical-align: middle;"><b>I</b>mages :</td>
                                                        <td>
                                                            <?php
                                                                $data1=mysql_query("select * from product_mstr2 where productid='$row1[5]'");
                                                                while($row2= mysql_fetch_array($data1))
                                                                {
                                                            ?>
                                                            <img width="50px" height="65px" src="<?php echo $row2[2];?>" style="border-radius:5px;box-shadow:1px 1px 1px #e44f2b;margin: 2px;"/>
                                                            <?php
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" style="background: #e44f2b;">
                                                            <center>
                                                                <?php
                                                                    if ($row1[12]=='new')
                                                                    {
                                                                ?>
                                                                <a href="managecart.php?id=<?php echo $row1[5]; ?>#cart"><img src="images/cart.png" title="add to cart" width="28px"/></a>  
                                                                <?php
                                                                    }
                                                                ?>
                                                                <a href="wishlist.php? id=<?php echo $row1[5]; ?>&shu=product"><img src="images/wish.png" title="add to wishlist" width="25px" style="margin-right: 20px;margin-left: 20px;"/></a>
                                                                <a href="rating.php?id=<?php echo $row1[5]; ?>&shu=product"><img src="images/ret.png" title="give rate" width="28px" style="margin-right: 20px;"/></a>
                                                                <a href="productdetail.php?id=<?php echo $row1[5]; ?>#prodetail"><img src="images/ditale.png" title="show in details" width="28px"/></a>
                                                            </center>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                                
                                            <div style="clear: both;">
                                        
                                            </div>
                                        </div>
                                    </li>
                                    </div>
                                    <div style="clear: both;">
                                        
                                    </div>
                                   
                                </ul>
                                <?php
                                        }
                                     }   
                                     if($_REQUEST[shu]=="nathi")
                                     {
                                    ?>
                                    
    <div class="vm" onclick="bmilt('<?php echo $_REQUEST[how1]+5; ?>','nathi')" >
        <center>View More</center>
    </div>
                                    <?php
                                     }
                                     ?>
                            </div>