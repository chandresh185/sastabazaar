<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(productid) from product");
    $chhe=mysql_fetch_array($ketla);
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="selp('<?php echo $_REQUEST[base]; ?>');">
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
    </div>
</div>
          <?php
              require_once 'cover.php';
          ?>
          <div class="manag" id="sadpost">
              <h3>manage adpost
              <div style="float: right;margin-right: 20px;">
                        <?php
                            $cont=  mysql_query("select count(productid) from product");
                            $contt=  mysql_fetch_array($cont);
                            echo "total post are : ".$contt[0];
                        ?>
              </div>
              </h3><br>
              <div class="udis" style="background: white;margin-bottom: 3px;border: 1px solid #e44f2b;margin-left: 10px;padding: 15px;">
                  <ul align="center">
                                        <?php
                                            $page=$chhe[0]/$perpage;
                                            $page=ceil($page);
                                            if($page>5)
                                            {
                                                if($_REQUEST[base]>=1 && $_REQUEST[base]<=5)
                                                {
                                                    $start=1;
                                                    $end=5;
                                                }
                                                else
                                                {
                                                    if($_REQUEST[next]<=$page)
                                                    {
                                                        $start=$_REQUEST[next]-4;
                                                        $end=$_REQUEST[next];
                                                    }
                                                }  
                                            }
                                            else
                                            {
                                                $start=1;
                                                $end=$page;
                                            }
                                            if($start>=1 && $end<=5)
                                            {
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;border:1px solid #23272a;"><a href="manageselleradpost.php?next=<?php if($end>1){echo $end-1;}else{echo $page;} ?>&base=<?php if($end>1){echo $end-1;}else{echo $page;} ?>#sadpost" style="color: white;"><</a></li>
                                        <?php
                                            
                                        }
                                        for($i=$start;$i<=$end;$i++)
                                        {
                                            
                                            if($i==$_REQUEST[base])
                                            {
                                        ?>
                                        <li style="background: #e44f2b;border:1px solid #23272a;"><a href="manageselleradpost.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#sadpost" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;border:1px solid #23272a;"><a href="manageselleradpost.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#sadpost" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                        }
                                        } 
                                        
                                        if($page>5)
                                        {
                                     
                                        ?>
                                        <li style="background: #23272a;border:1px solid #23272a;"><a href="manageselleradpost.php?next=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>&base=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>#sadpost" style="color: white;">></a></li>
                                        <?php
                                        }
                                        ?>
                                    </ul>
              </div>
              <div class="umain" style="margin-left: 10px;">
                    <input type="text" name="search" onkeyup="search1(this.value,'product');" placeholder="Search Here"/>
                    <a href="delete.php?all=sadpost"><img src="images/delete2.png" title="delete all records" width="30px" style="vertical-align: middle;"/></a>
              </div>
              <div class="udis" id="seller" style="margin-left: 10px;">
                  <form method="post" action="">
                      
                  </form>    
              </div>      
          </div>
        <div style="clear: both;">
            
        </div>
    </div>  
   <?php
            require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script> 
</body>
</html>

