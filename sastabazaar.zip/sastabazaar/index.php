<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
    
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main" >
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap">
		          	   <h3>Main Categories</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
                                            <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
    	  <div class="content_bottom">
    	    <?php
                    require_once 'sidemenu.php';
            ?>
    	    	
    	    	<div class="content-bottom-right" style="font-size: 15px;">
    	    	<h3><b style="color: #e44f2b;font-size: 18px;">B</b>rowse <b style="color: #e44f2b;font-size: 18px;">A</b>ll <b style="color: #e44f2b;font-size: 18px;">C</b>ategories</h3>
	            <div class="section group">
				<div class="grid1 images">
                                    <a href="product.php#mobile"><img src="images/footer/mobile.png" alt="" /></a>
                                </div>
                                <div class="op1">
                                    <center>mobile</center>
				</div>
				<div class="grid1 img1">
                                    <a href="eproduct.php#elec"><img src="images/footer/computer.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>electronics</center> 
				</div>
				<div class="grid1 img2">
                                    <a href="vproduct.php#vehicle"><img src="images/footer/car.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;vehicals</center>
				</div>
				<div class="grid1 img3">
                                    <a href="hproduct.php#home"><img src="images/footer/home.png" alt="" /></a>
				 </div>
                                 <div class="op1">
                                     <center>home & furniturs</center>
				</div>
                                <div class="grid1 img4">
                                    <a href="bproduct.php#book"><img src="images/footer/book.png" alt="" /></a> 
				</div>
                                <div class="op1">
                                    <center>books & cds</center>
				</div>
				<div class="grid1 img5">
                                    <a href="fproduct.php#fation"><img src="images/footer/bag.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center><br/>fashion</center>
				</div>
				<div class="grid1 img6">
                                    <a href="spproduct.php#sport"><img src="images/footer/sport.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>sports & health</center>
				</div>
				<div class="grid1 img7">
                                   <a href="jproduct.php#job"><img src="images/footer/Business-Businessman-icon.png" alt="" /></a>
				 </div>
                                 <div class="op1">
                                     <center>jobs</center>
				</div>
				<div class="grid1 img8">
                                    <a href="rproduct.php#real"><img src="images/footer/realestate.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>realestate</center>
				</div>
				<div class="grid1 img9">
                                    <a href="pproduct.php#pets"><img src="images/footer/pet.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>pets</center>
				</div>
				<div class="grid1 img10">
                                    <a href="kproduct.php#kids"><img src="images/footer/kids.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center> kids & baby</center>
				</div>
				<div class="grid1 img11">
                                    <a href="auction.php#auction"><img src="images/footer/Cultures-Thor-Hammer-icon.png" alt="" /></a>
				</div>
                                <div class="op1">
                                    <center>auction</center>
				</div>
			    </div>
			    
		      </div>
		      <div class="clear"></div>
		   </div>
         </div>
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

