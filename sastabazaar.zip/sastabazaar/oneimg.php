    
<?php
    require_once 'conn.php';
                                        
                                        $data=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                        while($row1= mysql_fetch_array($data))
                                        {
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[4]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c==1)
                                                {
                                                    ?>
                                  
                                                    <img id="mjimg" src='<?php echo $row2[2] ?>' width='320px' height='380px' style='border-radius:5px;box-shadow:1px 1px 1px #e44f2b;'/><br><br>
                                                <?php
                                                    }
                                                else
                                                {
                                    ?>
                                  
                                                    <img src="<?php echo $row2[2]; ?>" style="border-radius:3px;margin-left: 2px;box-shadow:1px 1px 1px #e44f2b;" width="80px" height="80px" onclick="mj()"/>
                                                    <img src="<?php echo $row2[2]; ?>" onclick="getphoto('<?php echo $row2[2]; ?>')" style="position: absolute;margin-top: -390px;width: 80px;height: 80px;border-radius:100px;box-shadow:1px 1px 1px #e44f2b;" onclick="mj()"/>    
                                  <?php
                                                }
                                            }
                                        }
                                  ?>