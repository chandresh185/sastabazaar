<?php
    require_once 'conn.php';
        if(isset($_REQUEST[sendd]))
        {
            if($_REQUEST[mail]=='')
             {
                    $su1=1;
              }
            if($su1!=1)
           {
               $in=mysql_query("insert into email values(0,'$_REQUEST[mail]')");
               $send=1;
           }
        }
?>

<form action="" method="post">
    <table>
        <tr>
                                       <td colspan="2">
                                           <?php
                                                                 if($send==1)
                                                                    {
                                                                        echo "<font color=red size=3px>Send Successfully</font>";
                                                                    }
                                           ?>
                                       </td>
                                   </tr>
        <br>
        <tr>
            <td>
                Email Subscribe :&nbsp;&nbsp;&nbsp;
            </td>
            <td>
                <input type="email" name="mail" value="" placeholder=" Your Email Subscribe "/>
                <?php
                                                                    if($su1==1)
                                                                    {
                                                                        echo "<font color=red size=3px>*</font>";
                                                                    }
                                             ?>
                &nbsp;&nbsp;<button type="submit" name="sendd" title="we send info about new stock and sell offer via email">send</button>
            </td>
        </tr>
        <tr>
            <td>
                <br>
            </td>
        </tr>
    </table>
</form>