<?php
require_once 'conn.php';
require_once 'PHPMailerAutoload.php';


if(isset($_REQUEST[submit]))
{
    $s=mysql_query("select userid,que,ans from registration where userid='$_REQUEST[userid]'");
    $ss=  mysql_fetch_array($s);
    
    if(!stristr($ss[0],$_REQUEST[userid]))
    {
        $in=1;
    }
    
    if($ss[1]!=$_REQUEST[que])
    {
        $q=1;
    }
    
    if($ss[2]!=$_REQUEST[ans])
    {
        $a=1;
    }
    if($in!=1 && $q!=1 && $a!=1)
    {
        $g=mysql_query("select email,password from registration where userid='$_REQUEST[userid]'");
        $gg=mysql_fetch_array($g);
        $id=$gg[0];
        
        $mail = new PHPMailer;

        $mail->isSMTP();

        $mail->SMTPDebug = 0;

        //Ask for HTML-friendly debug output
        $mail->Debugoutput = 'html';

        //Set the hostname of the mail server
        $mail->Host = 'smtp.gmail.com';

        //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
        $mail->Port = 587;

        //Set the encryption system to use - ssl (deprecated) or tls
        $mail->SMTPSecure = 'tls';

        //Whether to use SMTP authentication
        $mail->SMTPAuth = true;

        //Username to use for SMTP authentication - use full email address for gmail
        $mail->Username = "sastabazaar2015@gmail.com";

        //Password to use for SMTP authentication
        $mail->Password = "jaiswaminarayan";

        //Set who the message is to be sent from
        $mail->setFrom('sastabazaar2015@gmail.com', 'sastabazaar');

        //Set an alternative reply-to address
        $mail->addReplyTo('sastabazaar2015@gmail.com', 'sastabazaar');

        //Set who the message is to be sent to
        $mail->addAddress($id, 'sastabazaar');

        //Set the subject line
        $mail->Subject = 'sastabazaar Forget Password';

        //Read an HTML message body from an external file, convert referenced images to embedded,
        //convert HTML into a basic plain-text alternative body
        $message="Hey, Your Current sastabazaar Password Is $gg[1] , Please Next Time Be Carefully.";
        $mail->msgHTML($message, dirname(__FILE__));

        //Replace the plain text body with one created manually
        $mail->AltBody = 'sastabazaar';

        //Attach an image file
        //$mail->addAttachment('images/phpmailer_mini.png');

        //send the message, check for errors
        if (!$mail->send()) 
        {
            $done=1;
            //echo "Mailer Error: " . $mail->ErrorInfo;
        } 
        else
        {
            $done=2;
            //echo "Message sent!";
        }
    }
}

?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'header.php';
        ?>
  		    <?php
                        require_once 'menu.php';
                    ?>
    </div>
</div>   
 <div class="main">
 	<div class="wrap">
            <div class="preview-page">       
                <div class="contact-form" style="font-size: 15px;">
                    <h3><b style="color: #e44f2b;font-size: 18px;">F</b>orget <b style="color: #e44f2b;font-size: 18px;">P</b>assword  <b style="color: #e44f2b;font-size: 18px;">?</b></h3>
		<form method="post" action="" name="feedback">
                    <table>
                        <tr>
                            <td>User ID : </td>
                            <td>
                                <input name="userid" type="text" placeholder="Enter Your ID" />
                                
                            </td>
                            <td>
                                <?php
                                    if($in==1)
                                    {
                                        echo "<font color=red size=2px>Invalid</font>";
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>security question :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="que" name="que">
                                    <option>--Select--</option>
                                    <option>Your Favourite Sport?</option>
                                    <option>Your Favourite Car?</option>
                                    <option>Your Favourite Actor?</option>
                                    <option>Your Favourite Actress?</option>
                                </select>
                                
                             </td>
                             <td>
                                 <?php
                                    if($q==1)
                                    {
                                        echo "<font color=red size=2px>Invalid</font>";
                                    }
                                ?>
                             </td>
                        </tr>
                        <tr>
                            <td>security answer :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="ans" type="text" placeholder="Enter Answer"/>
                             </td>
                             <td>
                                 
                                <?php
                                    if($a==1)
                                    {
                                        echo "<font color=red size=2px>Invalid</font>";
                                    }
                                ?>
                             </td>    
                        </tr>
                        <tr>
                            <td colspan="3">
                                <button type="submit" class="fop" name="submit">get your password via email</button>
                            
                                 <?php
                                    if($done==1)
                                    {
                                        echo "<font color=red size=2px>Server Authentication Problems</font>";
                                    }
                                    else
                                    {
                                        if($done==2)
                                        {
                                            echo "<font color=green size=2px>Email Send Successfully See Your Account</font>";
                                        }
                                    }
                                ?>
                            </td>
                        </tr>
                    </table>
		</form>
                </div>
            </div>		
         </div> 
    </div>
 </div>
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

