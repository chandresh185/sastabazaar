
<?php
    if($_SESSION[user]=="")
    {    

    }
    else
    {
  
 ?>
        <script type="text/javascript">
            c=0;
            function chalu()
            {
                c++;
                s=0,
                $jovu=$('.my');
                function inte()
                {
                    s++;
                    if(s==180)
                        {
                            window.location.href="logout.php";
                        }
                }
                if(c==1)
                {
                    setInterval(inte,1000);
                }
            }
            $(document).ready(function(){
                chalu();
                $(document).keydown(function(e){
                    if(e.which>=0 && e.which<=255)
                    {
                        chalu();
                    }
                });
                $(document).click(function(){
                    chalu();
                });
            });
        </script>
    <?php
        }
    ?>
<script>
    function settimee()
    {
        start=60;
        m=19;
        timepass=1000;
        $dis=$('.waitt');
        var recall=setInterval(function(){
            if(start>=0)
                {
                    start--;
                    if(start==0)
                        {
                            m=m-1;
                            start=60;
                        }
                        if(m==0)
                            {
                                clearInterval(recall);
                                
                                window.location.href="index.php";
                            }
                            else
                                {
                                    $dis.text(m+":"+start);
                                }
                }
       
    },timepass);
    }
    </script>

<?php
    
    if(isset($_REQUEST[send]))
    {
        $ok=$_REQUEST[username];
        $okk=mysql_real_escape_string($ok);
        
        $okp=$_REQUEST[pass];
        $okkp=mysql_real_escape_string($okp);
        
        $in=mysql_query("select * from login where userid='$_REQUEST[username]'");
        $a=mysql_fetch_array($in);
        if($a[0]=="$_REQUEST[username]" && $a[1]=="$_REQUEST[pass]")
        {
            $dt=date('Y-m-d');
            $ti=date('H:i:s');
            $_SESSION[type]=$a[2];
            $_SESSION[user]=$a[0];
            $_SESSION[timee]=$ti;
            $_SESSION[datee]=$dt;
            if($a[2]==1)
            {   
                header('location:dealerhome.php');
            }
            if($a[2]==2)
            {
                header('location:buyerhome.php');
            }    
            if($a[2]==3)
            {
                header('location:sellerhome.php');
            }
            if($a[2]==0)
            {
                header('location:admin.php');
            }    
        }
        else
        {
            $e=1;
            if($_SESSION[wrong]<=3)
            {
                if($_SESSION[wrong]==3)
                {
                    $_SESSION[wrong]+=2;
                }
                else
                {
                    $_SESSION[wrong]+=1;
                }
            }
            if($_SESSION[wrong]==3)
            {
                $_SESSION[t]=date('h:i:s');
                $h=date(h);
                $mm=date(i)+20;
                if($mm>60)
                {
                    $h=$h+1;
                    $mm-=60;
                }
                $nt=$h.":".$mm.":"."00";
                $_SESSION[nt]=$nt;
            }
        }
    }
?>
<div style="background: #e44f2b;padding: 15px;">
    <?php
        $_SESSION[wrong];
        if($_SESSION[wrong]>=3)
        {
            if($_SESSION[nt]<=date('h:i:s'))
            {
                $_SESSION[wrong]=0;
            }
        }
    ?>
    
    <div class="topheader">
        <ul>
            <li>
                <?php
                
                    if(isset($_SESSION[user]))
                    {
                        echo "<a href=logout.php>logout&nbsp;|</a>";
                    }
                    else
                    {
                ?>
                <a href=""><img src="images/LockUser.png" title="login" style="width: 10px;"/>&nbsp;&nbsp;login&nbsp;&nbsp;|</a>
                <ul <?php if($e==1){ ?> style="display: block;" <?php } ?>>
                                                        <li>
                                                            <div class="login">
                                                                <form method="post" action="">
                                                                    <table>
                                                                        <tr>
                                                                            <td align="center">
                                                                                <img src="images/LockUser.png" class="lock" alt="" />
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <br>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <?php
                                                                                    if($_SESSION[wrong]>=3)
                                                                                    {
                                                                                ?>
                                                                                <input name="username" type="text" placeholder="Enter User Name" readonly="true" />
                                                                                <?php
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                ?>
                                                                                <input name="username" type="text" placeholder="Enter User Name"/>
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                            </td>
                                                                                
                                                                        </tr>
                                                                        
                                                                        <tr>
                                                                            <td>
                                                                                <?php
                                                                                    if($_SESSION[wrong]>=3)
                                                                                    {
                                                                                ?>
                                                                                <input name="pass" type="password" placeholder="********" readonly="true" />
                                                                                <?php
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                ?>
                                                                                <input name="pass" type="password" placeholder="********" />
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                            </td>
                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <?php
                                                                                    if($_SESSION[wrong]>=3)
                                                                                    {
                                                                                ?>
                                                                                <?php
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                ?>
                                                                                <button type="submit" class="" name="send">submit</button>
                                                                                <button type="reset" class="" name="clear">clear</button>
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                                <?php
                                                            if($_SESSION[wrong]>0)
                                                            {
                                                                if($_SESSION[wrong]>=3)
                                                                {
                                                                    if($_SESSION[wrong]==3)
                                                                    {
                                                                        echo "<p class='waitt' style='font-size:10px;color:white;'><script>settimee();</script></p>";
                                                                    }
                                                                    else
                                                                    {
                                                                        echo "<p class='waitt1' style='font-size:10px;color:white;'></p>";
                                                                    }
                                                                    echo "<font color='white' size='2'>wait from $_SESSION[t] to $_SESSION[nt]</font>";
                                                                }
                                                                else
                                                                {
                                                                    echo "<font color='white' size='1' style='margin-left:-190px;font-size:12px;'>wait $_SESSION[wrong] try</font>";
                                                                }
                                                            }
                                                         ?>
                                                                            </td>
                                                                        </tr>
                                                                        <tr style="color: white;">
                                                                            <td>
                                                                                <br><a href="forgot.php">Forget Password ?</a>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <font style="font-size: 11px;color: white;">you have maximum three wrong try to login then block for 20 minutes.</font>
                                                                            </td>
                                                                        </tr>
                                                                        
                                                                    </table>
                                                                </form>    
                                                            </div>
                                                        </li>
                                                    </ul>
                                                    <?php
                                                        }
                                                    ?>
            </li>
            <li>
                <?php
                
                    if($_SESSION[user]!="")
                    {
                        if($_SESSION[type]==0)
                        {   
                            //echo "hi";
                            echo "<a href='admin.php#dash'>dashboard</a>";
                            
                        }
                        elseif($_SESSION[type]==1)
                        {
                            //echo "hii";
                            echo "<a href='dealerprofile.php#dealerprofile'><img src='images/footer/Business-Businessman-icon.png' title='My profile' style='width: 10px;'/>&nbsp;&nbsp;profile</a>";
                        }
                        elseif($_SESSION[type]==2)
                        {
                            //echo "hii";
                            echo "<a href='buyerprofile.php#buyerprofile'><img src='images/footer/Business-Businessman-icon.png' title='My profile' style='width: 10px;'/>&nbsp;&nbsp;profile</a>";
                        }
                        else
                        {
                            //echo "hii";
                            echo "<a href='sellerprofile.php#sellerprofile'><img src='images/footer/Business-Businessman-icon.png' title='My profile' style='width: 10px;'/>&nbsp;&nbsp;profile</a>";
                        }
                    }
                    else
                    {
                ?>
                <a href="registration.php">&nbsp;registration</a>
                <?php
                    }
                ?>
            </li>
            <li>
                <div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
            </li>
        </ul>
    </div>
    <div class="tophead">
        <ul>
            
            <li>
                <a href="">&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/wish.png" title="Add To Wishlist" style="width: 10px;"/>&nbsp;&nbsp;wishlist&nbsp;&nbsp;&nbsp;&nbsp;|</a>
                <ul>
                    <li>
                        <div class="wishname" style="">
                            <center><img src="images/wish.png" title="Add To Wishlist" style="width:15px;margin-left: -160px;"/>&nbsp;&nbsp;<b style="color:#e44f2b;font-size: 20px;">w</b>ishlist<a href="delete.php?all=wish" style="margin-top: -20px;margin-left: 210px;"><img src="images/remove11.png" style="width: 15px;"/></a></center>         
                        </div>
                        <div style="border: 1px solid #23272a;overflow: auto;height: 300px;">
                           <?php
                                            if($_SESSION[user]=="")
                                            {
                           ?> 
                            <p style="color: white;padding: 5px;">if items in your wishlist are missing, <a href="">login to your account</a> to view them</p>
                                         <?php
                                            }
                                            else
                                            {
                                                
                                            $tot=  mysql_query("select count(wishlistid) from wishlist where userid='$_SESSION[user]'");
                                            $tot1=  mysql_fetch_array($tot);
                                            if($tot1[0]!=0)
                                             {
                                                    $w=mysql_query("select * from wishlist where userid='$_SESSION[user]'");
                                                    while($ww=  mysql_fetch_array($w))
                                                    {
                                                            $www=  mysql_query("select p.productname,p.price,pp.* from product p, product_mstr2 pp where pp.productid='$ww[1]' and p.productid=pp.productid");
                                                            $www1=  mysql_fetch_array($www);
                        
                    ?> 
                            <div>
                                <div class="wishimage">
                                    <img src="<?php echo $www1[4]; ?>" style="width: 70px;height: 70px;border-radius:3px;"/>
                                </div>
                                <div class="wishinfo"><br>
                                    <p style="text-align: left;font-size: 15px;text-transform: capitalize;margin-top: -10px;"><?php echo $www1[0]; ?></p><br>
                                    <p style="text-align: left;font-size: 15px;"> Price :<?php echo $www1[1]; ?>/-</p><br>
                                    <a href="managecart.php?id=<?php echo $ww[1]; ?>#cart"  style="margin-top: -10px;margin-left: 10px;"><img src="images/cartt1.png"></a>
                                    <a href="productdetail.php?id=<?php echo $ww[1]; ?>&shu=prodetail#prodetail" style=" margin-top: -27px;margin-left: 40px;"><img src="images/more1.png"></a>
                                    <a href="delete.php?id=<?php echo $ww[0]; ?>&ek=wish" style="margin-top: -27px;margin-left: 70px;" ><img src="images/remove1.png"/></a>
                                </div>
                                
                                <div style="clear: both;"></div>
                                <hr style="background: black;padding: 1px;border: none;"></hr>
                            </div>
                            <?php
                                    }
                                }
                                else
                                {
                                    echo "<center><p style='font-size:15px;'>No any Wish in your Account..,</p></center>";
                                }
                                echo "<br>";
                                if($tot1[0]!=0)
                                {
                            ?>
                            <p align="center" style="font-size: 15px;background: #23272a;padding: 10px;margin-top: -28px;text-transform: capitalize; "> Total Wish Item : &nbsp;<b style="color: #e44f2b;"><?php echo $tot1[0]; ?></b></p>
                            <?php
                                    }
                                    else
                                    {
                            ?>
                            <center><p style="font-size: 15px;background: #23272a;padding: 10px;"> Total Wish Item : &nbsp;&nbsp;0</p></center> 
                            <?php
                                    }
                                }
                            ?>
                        </div>
                    </li>
                </ul>
            </li>
            <li>
                <a href="">&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/cart.png" title="Add To Cart" style="width: 10px;"/>&nbsp;&nbsp;shopping cart</a>
                <ul>
                    <li>
                        <div class="wishname" style="">
                            <center><img src="images/cart.png" title="add to cart" style="width:15px;margin-left: -130px;"/>&nbsp;&nbsp;<b style="color:#e44f2b;font-size: 20px;">s</b>hopping <b style="color:#e44f2b;font-size: 20px;">c</b>art<a href="delete.php?all=cart" style="margin-top: -20px;margin-left: 210px;"><img src="images/remove11.png" style="width: 15px;"/></a></center>         
                        </div>
                        <div style="border: 1px solid #23272a;overflow: auto;height: 300px;">
                           <?php
                                            if($_SESSION[user]=="")
                                            {
                           ?> 
                            <p style="color: white;padding: 5px;">if items in your Shopping cart are missing, <a href="">login to your account</a> to view them</p>
                                         <?php
                                            }
                                            else
                                            {
                                                
                                            $tot=  mysql_query("select count(cartid) from cart where userid='$_SESSION[user]'");
                                            $tot1=  mysql_fetch_array($tot);
                                            if($tot1[0]!=0)
                                             {
                                                    $ch=mysql_query("select * from cart where userid='$_SESSION[user]'");
                                                    while($cd=mysql_fetch_array($ch))
                                                    {
                                                        $image= mysql_query("select p.productname,p.price,pp.* from product p, product_mstr2 pp where pp.productid='$cd[1]' and p.productid=pp.productid");
                                                        $imagee=  mysql_fetch_array($image);
                        
                    ?> 
                            <div>
                                <div class="wishimage">
                                    <img src="<?php echo $imagee[4]; ?>" style="width: 70px;height: 70px;border-radius:3px;"/>
                                </div>
                                <div class="wishinfo"><br>
                                    <p style="text-align: left;font-size: 15px;text-transform: capitalize;margin-top: -10px;"><?php echo $imagee[0]; ?></p><br>
                                    <p style="text-align: left;font-size: 15px;"> Price :<?php echo $imagee[1]; ?>/-</p><br>
                                    <a href="managecart.php?id=<?php echo $cd[1]; ?>#cart"  style="margin-top: -10px;margin-left: 10px;"><img src="images/cartt1.png"></a>
                                    <a href="productdetail.php?id=<?php echo $cd[1]; ?>&shu=prodetail#prodetail" style=" margin-top: -27px;margin-left: 40px;"><img src="images/more1.png"></a>
                                    <a href="delete.php?id=<?php echo $cd[0]; ?>&ek=cart" style="margin-top: -27px;margin-left: 70px;" ><img src="images/remove1.png"/></a>
                                </div>
                                
                                <div style="clear: both;"></div>
                                <hr style="background: black;padding: 1px;border: none;"></hr>
                            </div>
                            <?php
                                    }
                                }
                                else
                                {
                                    echo "<center><p style='font-size:15px;'>You Have Not Yet Any Purchesing in your Account..,</p></center>";
                                }
                                echo "<br>";
                                if($tot1[0]!=0)
                                {
                            ?>
                            <p align="center" style="font-size: 15px;background: #23272a;padding: 10px;margin-top: -28px;text-transform: capitalize; "> Total Wish Item : &nbsp;<b style="color: #e44f2b;"><?php echo $tot1[0]; ?></b></p>
                            
                            <?php
                                    }
                                    else
                                    {
                            ?>
                            <center><p style="font-size: 15px;background: #23272a;padding: 10px;"> Total Wish Item : &nbsp;&nbsp;0</p></center> 
                            
                            <?php
                                    }
                                }
                            ?>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
        
        
        
    </div>
</div>
<div class="header" >
    <div class="wrap">
        <div class="header_top">
            <div class="logo">
                <a href="index.php"><img src="images/namelogo.png" alt="" /></a>
	    </div>
            <div class="header_top_right">
                <div class="search_box">
                    <span>Search</span>
                        <form method="post" action="">
                            <input type="text" onkeyup="gsearch(this.value);" value="" placeholder="Search here" /><button type="submit" value=""></button>
                            <div id="search" style="background: white;position: absolute;margin-top: 3px;width: 197px;z-index: 999;">
                               
                            </div>    
                        </form>
                     <div class="like">
                        <div class="iconlike">
                            <a href="preview.php"><img src="images/footer/1420910828_46-facebook-128.png" alt="" title="facebook" /></a>
                        </div>
                        <div class="iconlike">
                            <a href="preview.php"><img src="images/footer/google.png" alt="" title="google" /></a>
                        </div>
                        <div class="iconlike">
                            <a href="preview.php"><img src="images/footer/1420917859_47-skype-128.png" alt="" title="skype" /></a>
                        </div>
                        <div class="iconlike">
                            <a href="preview.php"><img src="images/footer/1420910644_51-linkedin-128.png" alt="" title="linkedin" /></a>
                        </div>
                    </div>
		</div>
            </div>
            <div class="clear"></div>
        </div> 