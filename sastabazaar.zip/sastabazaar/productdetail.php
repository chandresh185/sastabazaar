<?php
    require_once 'conn.php';
    if(isset($_REQUEST[send1]))
    {
        if($_REQUEST[review]=="")
        {
            $er1=1;
        }
        if($er1!=1)
        {
            $date=date('Y-m-d');
            $time=date('h:i:s');
            mysql_query("insert into review values (0,'$_SESSION[user]',$_REQUEST[id],'$_REQUEST[review]','0','$date $time')");
        }
    }
    $cc=0;
    $data11=  mysql_query("select * from product_mstr2 where productid='$_REQUEST[id]'");
    while($row11=  mysql_fetch_array($data11))
    {
        $cc++;
        if($cc==1)
        {
            $pat=$row11[2];
            break;
        }
    }
                                            
        
                                            
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="getphoto('<?php echo $pat; ?>');">
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main">
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap">
		          	   <h3>Latest Products</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
			                   <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
                      <div class="prod1">
                          <div class="prodetail" id="prodetail">
                              <h3>
                                  <b style="color: #23272a;font-size: 18px;">P</b>roduct&nbsp; <b style="color: #23272a;font-size: 18px;">D</b>etail . . <b style="color: #23272a;font-size: 18px;">!</b>
                              </h3>
                              <div class="prod2">
                                  <?php
                                        
                                        $data=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                        while($row1= mysql_fetch_array($data))
                                        {
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[5]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c==1)
                                                {
                                                    ?>
                                  <div id="missphoto" style="width: 500px;position: relative;height: 380px;margin-bottom: 10px;">
                                      
                                  </div>
                                                    
                                                <?php
                                                    }
                                                if ($c!=0)
                                                {
                                    ?>
                                  
                                                    <img src="<?php echo $row2[2]; ?>" onclick="getphoto('<?php echo $row2[2]; ?>')" class="inphoto" width="80px" height="80px" onclick="mj()"/>
                                                    
                                                    <img src="<?php echo $row2[2]; ?>" onclick="getphoto('<?php echo $row2[2]; ?>')" class="inphoto1" onclick="mj()"/>     
                                  <?php
                                                }
                                                
                                            }
                                        }
                                  ?>
                                                    
                                                   
                              
                              </div>  
                              <div class="prodetail1">
                                  <?php
                                                    $dat=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                                    $r=mysql_fetch_array($dat);
                                                    
                                              ?>
                                  <table width="100%">
                                      <tr>
                                          <td colspan="2"><h3><b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">d</b>iscription :</h3></td>
                                      </tr>
                                      <tr>
                                          <td colspan="2" style="padding-left: 30px;">
                                              <?php
                                                    echo $r[7];
                                              ?>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td><h3><b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">i</b>tems :</h3>
                                            <div style="width: 200px;">
                                                <table>
                                                    <tr>
                                                        
                                                        <td>
                                                        <?php
                                                            $g=mysql_query("select * from maincategories where maincateid=$r[2]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[1];
                                                        ?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                          <td>
                                              <h3>
                                                  <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">t</b>ype :
                                              </h3>
                                              <div style="width: 200px;">
                                                  <table>
                                                      <tr>
                                                          <td>
                                                              <?php
                                                                    $g=mysql_query("select * from subcategories where subcateid=$r[3]");
                                                                    $gg=  mysql_fetch_array($g);
                                                                    echo $gg[2];
                                                                ?>
                                                          </td>
                                                      </tr>
                                                  </table>
                                              </div>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td><h3><b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">c</b>ompany :</h3>
                                            <div style="width: 200px;">
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <?php
                                                                $g=mysql_query("select * from company where companyid=$r[4]");
                                                                $gg=  mysql_fetch_array($g);
                                                                echo $gg[2];
                                                            ?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                          <td rowspan="4"><h3><b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">o</b>wners <b style="color: #e44f2b;font-size: 18px;">i</b>nfo :</h3>
                                            <div style="width: 200px;">
                                                <?php
                                                   
                                                ?>
                                                <table width="360px" >
                                                    <tr>
                                                        <td>
                                                            Name :<?php echo $r[0];  ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>    
                                                    <tr>
                                                        <td>
                                                            <?php
                                                                $r1=mysql_query("select * from registration where userid='$r[0]'");
                                                                $rr=  mysql_fetch_array($r1);
                                                                
                                                            ?>
                                                            Contact :
                                                            <?php echo $rr[5]; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            Email :
                                                            <?php echo $rr[4]; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            City :
                                                            <?php echo $rr[8]; ?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                          
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <h3>
                                                  <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">i</b>tems <b style="color: #e44f2b;font-size: 18px;">n</b>ame : 
                                              </h3>
                                              <div style="width: 200px;">
                                                  <table>
                                                      <tr>
                                                          <td>
                                                              <?php echo $r[6];?>
                                                          </td>
                                                      </tr>
                                                  </table>
                                              </div>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                            <h3>
                                                <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">p</b>rice   :
                                            </h3>
                                            <div style="width: 200px;">
                                                <table>
                                                    <tr>
                                                        <td><?php echo $r[8];?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                          <td>
                                            <h3>
                                                <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">R</b>ating :
                                            </h3>
                                            <div style="width: 200px;">
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <div>
                                                                <?php
                                                                    $ret=  mysql_query("select count(rateid) from rating where productid=$_REQUEST[id]");
                                                                    $ret1=  mysql_fetch_array($ret);
                                                                    $rt=$ret1[0];
                                                                    $ml=$rt*5;
                    //                                                echo $ret1[0];
                                                                 ?>
                                                                <img src="images/ret.png" title="add rate" width="25px" />
                                                                <img src="images/ret.png" title="add rate" width="25px" />
                                                                <img src="images/ret.png" title="add rate" width="25px" />
                                                                <img src="images/ret.png" title="add rate" width="25px" />
                                                                <img src="images/ret.png" title="add rate" width="25px" />
                                                            </div>
                                                            <div style="background: white;margin-top: -30px;position: absolute;width: 138px;height: 30px;margin-left:<?php echo $ml; ?>px;">
                                                                
                                                            </div>    
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td colspan="2">
                                            <h3>
                                                <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">A</b>dd <b style="color: #e44f2b;font-size: 18px;">H</b>ere  :
                                            </h3>
                                            <div style="width: 530px;">
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <?php
                                                                if ($row1[12]=='new')
                                                                {
                                                            ?>
                                                            <a href="managecart.php?id=<?php echo $r[5]; ?>#cart"><img src="images/cart.png" title="add to cart" width="30px"/></a>  
                                                            <?php
                                                                }
                                                            ?>
                                                            <a href="wishlist.php? id=<?php echo $r[5]; ?>&shu=product"><img src="images/wish.png" title="add to wishlist" width="26px" style="margin-left: 50px;"/></a>
                                                            <a href="inq.php?id=<?php echo $r[5]; ?>"><img src="images/1425975193_Info_2-24.png" title="inquire" width="27px" style="margin-left: 50px;"/></a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <h3>
                                                  <b style="font-size: 12px;">&Del;</b>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">S</b>tock : 
                                              </h3>
                                              <div style="width: 200px;">
                                                  <table>
                                                      <tr>
                                                          <td>
                                                              <?php echo $r[14];?>
                                                          </td>
                                                      </tr>
                                                  </table>
                                              </div>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <br>
                                          </td>
                                      </tr>
                                  </table>
                              </div>
                          </div>
		      </div>
                <div class="clear"></div>
         </div>
      <div style="margin-left: 15px;padding: 10px;">
          <script type="text/javascript">
              $(document).ready(function(){
                  
              
       $(".one").css('background','white');
        $(".one").css('color','#e44f2b');
           $(".one").css('border','1px #23272a solid');
          $(".one").css('border-bottom','none');
        $(".two").css('background','#23272a');
         $(".two").css('color','white');
         $(".three").css('background','#23272a');
         $(".three").css('color','white');
         $("#two1").hide();
         $(".beed").hide();
                $("#three1").hide();
        
            $("#one").click(function(){
       $(".one").css('background','white');
         $(".one").css('color','#e44f2b'); 
           $(".one").css('border','1px #23272a solid');
          $(".one").css('border-bottom','none');
            $(".three").css('background','#23272a');
         $(".three").css('color','white');
          $(".two").css('background','#23272a');
         $(".two").css('color','white');
          $("#one1").show();
          $(".review2").show();
          $(".beed").hide();
          $("#two1").hide();
                $("#three1").hide();
                
        
      
    });
      
 
    $("#two").click(function(){
        $(".two").css('background','white');
        $(".two").css('color','#e44f2b');
        
           $(".two").css('border','1px #23272a solid');
          $(".two").css('border-bottom','none');
         $(".one").css('background','#23272a');
         $(".one").css('color','white');
          $(".three").css('background','#23272a');
         $(".three").css('color','white');
         $("#one1").hide();
         $(".review2").hide();
         $(".beed").show();
          $("#two1").show();
                $("#three1").hide();
        
      
    });
    });
         </script>
          <div id="one" class="one" style="padding: 10px;cursor: pointer;padding-left: 25px;padding-right: 25px;background: yellow;float: left;">
              <b style="color: #e44f2b;font-size: 18px;">R</b>eview
          </div>
          <div id="two" class="two" style="padding: 10px;cursor: pointer;padding-left: 25px;padding-right: 25px;background: green;float: left;margin-left: 5px;margin-right: 5px;">
              <b style="color: #e44f2b;font-size: 18px;">D</b>etails
          </div>
         
          <div style="clear: both;">
              
          </div>
            <div id="one1" class="review" style="overflow: auto;">
                <h3><b style="color: #e44f2b;font-size: 18px;">R</b>eview</h3>
                <div>
                    <?php
                        $i=mysql_query("select * from review where productid='$_REQUEST[id]' and active=1");
                        while($ii=mysql_fetch_array($i))
                        {
                            $i1=mysql_query("select image from registration where userid='$ii[1]'");
                            $ii1=mysql_fetch_array($i1);
                        
                    ?>
                    <div style="float: left;">
                        <img src="<?php echo $ii1[0];?>" style="width: 80px;height: 80px;border-radius:150px;border: 1px solid #23272a;"/>
                    </div>   
                    <div class="re">
                        <font style="padding-left: 10px;font-size:15px;text-transform: capitalize;"><?php echo $ii[3]; ?></font><br><br><br>
                        <font style="padding-left: 370px;"><?php echo $ii[5]; ?></font>
                    </div>
                    <div style="clear: both;">
                        
                    </div>
                    <?php 
                        }
                    ?>
                   
                </div>
            </div>
         
            <div id="two1" class="review" style="overflow: auto;">
                <h3><b style="color: #e44f2b;font-size: 18px;">D</b>etail</h3>
                <div>
                    <form method="post" action="">
                        <table width="100%">
                            <th colspan="2" style="background: #e44f2b;color: white;padding: 10px;font-size: 15px;text-align: left;"><b style="color: #23272a;font-size: 18px;">D</b>iscription . . <b style="color: #23272a;font-size: 18px;">!</b></th>
                            <tr>
                                <td>
                                    <br>
                                </td>
                            </tr> 
                            <tr>
                                <td colspan="2">
                                    <?php echo $r[7]; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <br>
                                </td>
                            </tr> 
                            <th colspan="2" style="background: #e44f2b;color: white;padding: 10px;font-size: 15px;text-align: left;"><b style="color: #23272a;font-size: 18px;">O</b>wners <b style="color: #23272a;font-size: 18px;">I</b>nfo . . <b style="color: #23272a;font-size: 18px;">!</b></th>
                            <tr>
                                <td>
                                    <br>
                                </td>
                            </tr>    
                            <tr>
                                <td style="padding: 10px;"  width="10%"><b style="color: #e44f2b;font-size: 18px;">N</b>ame :</td>
                                <td style="padding: 10px;"><?php echo $r[0]; ?></td>
                            </tr>
                            <tr>
                                <td style="padding: 10px;"><b style="color: #e44f2b;font-size: 18px;">C</b>ontact :</td>
                                <td style="padding: 10px;">
                                    <?php
                                        $r1=mysql_query("select * from registration where userid='$r[0]'");
                                        $rr=  mysql_fetch_array($r1);
                                        echo $rr[5];
                                   ?>
                                </td>
                            </tr>    
                            <tr>
                                <td style="padding: 10px;"><b style="color: #e44f2b;font-size: 18px;">E</b>mail :</td>
                                <td style="padding: 10px;"><?php echo $rr[4]; ?></td>
                            </tr>
                            <tr>
                                <td style="padding: 10px;"><b style="color: #e44f2b;font-size: 18px;">C</b>ity :</td>
                                <td style="padding: 10px;"><?php echo $rr[8]; ?></td>
                            </tr>    
                        </table>
                    </form>
                </div>
            </div>
            
            <?php
                if($_SESSION[user]!="")
                {
            ?>
            <div class="review2">
                
                <h3><b style="color: #e44f2b;font-size: 18px;">A</b>dd <b style="color: #e44f2b;font-size: 18px;">R</b>eview</h3><br>
                <form method="post" action="">
                    <table width="100%">
                        <tr>
                            <td>
                                <textarea name="review" placeholder="Enter Review" style="vertical-align: top;width: 335px;padding: 10px;height: 50px;border-radius:5px;"></textarea>
                                <?php
                                    if($er1==1)
                                    {
                                        echo "<font color=red>*</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <button type="submit" class="feedbackbutton" name="send1">send</button>
                                <button type="reset" class="feedbackbutton" name="clear1">clear</button>
                            </td>
                        </tr>
                    </table>
                </form>
                
            
            </div>
            <?php
                }
            ?>
            
            <div style="clear: both;">
                
            </div>
      </div>
        
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

