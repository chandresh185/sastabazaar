
<head> 
<title>SastaBazaar | log sasta kehte he , ham sasta bechte he</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<meta name="google-translate-customization" content="76e796471402f3e8-f2b61ecbf46a5f61-g152cb97a486f48c4-13"></meta>

<link href='http://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="images/ek.png" rel="icon" title=""/>
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script src="js/jquery.openCarousel.js" type="text/javascript"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/set.js"></script>
</head>