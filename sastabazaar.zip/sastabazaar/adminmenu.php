<div class="adminleft">
              <center><p>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">W</b>elcome Mr.&nbsp;/&nbsp;Mrs.<br>
              <?php
                    $im=  mysql_query("select image from registration where userid='$_SESSION[user]'");
                    $imm=  mysql_fetch_array($im);
                
              ?>
               &nbsp;&nbsp;&nbsp;<img src="<?php echo $imm[0]; ?>" width="130px" height="130px" style="border-radius:100px;border: 2px solid #e44f2b;"/>
              <?php
                $in=  mysql_query("select * from registration where userid = '$_SESSION[user]'");
                $a=  mysql_fetch_array($in);
                echo $a[1];
              ?></p></center>
                <ul>
                    <li><a href="admin.php?base=1#dash">dashboard</a></li>
                    <li><a href="managecountry.php?base=1#country">manage country</a></li>     
                    <li><a href="managestate.php?base=1#state1">manage state</a></li>
                    <li><a href="managecity.php?base=1#city1">manage city</a></li>
                    <li><a href="managefeedback.php?base=1#feed">manage feedback</a></li>
                    <li><a href="managecontact.php?base=1#contact">manage contact</a></li>
                    <li><a href="manageuser.php?base=1#user">manage user</a></li>
                    <li><a href="managead_rate.php?base=1#adrate">manage ad_rate</a></li>
                    <li><a href="manageemail.php?base=1#emaile">manage email</a></li>
                    <li><a href="managemaincategories.php?base=1#maincate">manage maincategories</a></li>
                    <li><a href="managesubcategories.php?base=1#subcate">manage subcategories</a></li>
                    <li><a href="managecompany.php?base=1#company">manage company</a></li>
                    <li><a href="manageselleradpost.php?base=1#sadpost">manage adpost</a></li>
                    <li><a href="showbill.php?base=1#bil">manage bill</a></li>
                    <li><a href="managereview.php?base=1#review">manage review</a></li>
                    <li><a href="managetransaction.php?base=1#tran">manage transaction</a></li>
                    <li><a href="managereport.php?base=1#report">manage summer report</a></li>
                    <li><a href="manageinq.php?base=1#inquire">manage inquire</a></li>
                    <li><a href="graph.php?base=1#grapha">general graph</a></li>
                </ul>
          </div>