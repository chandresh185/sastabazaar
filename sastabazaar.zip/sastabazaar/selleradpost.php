<?php
    require_once 'conn.php';
    if(isset($_REQUEST[submit]))
    {
       $c=mysql_query("select * from maincategories where maincateid=$_REQUEST[maincate]");
       while($cc=  mysql_fetch_array($c))
       {
           $maincate=$cc[1];
       }
       $s=mysql_query("select * from subcategories where subcateid=$_REQUEST[subcate]");
       while($st=  mysql_fetch_array($s))
       {
           $subcate=$st[2];
       }
       $ci=mysql_query("select * from company where companyid=$_REQUEST[company]");
       while($cci=  mysql_fetch_array($ci))
       {
           $company=$cci[2];
       }
       if($_REQUEST[maincate]=='--Select--')
       {
           $emaincate=1;
       }
       if($_REQUEST[subcate]=='--Select--')
       {
           $esubcate=1;
       }
       if($_REQUEST[company]=='--Select--')
       {
           $ecompany=1;
       }
       if($_REQUEST[productname]=='')
       {
           $eproductname=1;
       }
       if($_REQUEST[productinfo]=='')
       {
           $eproductinfo=1;
       }
       
       if($_REQUEST[price]=='')
       {
           $eprice=1;
       }
       
       if($eproductname!=1 && $eproductinfo!=1 && $eprice!=1 && $maincate!=1 && $subcate!=1 && $company!=1)
       {
           if($_REQUEST[choice]=="")
           {
               $date=date('Y-m-d');
               $inn=mysql_query("insert into product values('$_SESSION[user]',0,'$_REQUEST[maincate]','$_REQUEST[subcate]','$_REQUEST[company]',0,'$_REQUEST[productname]','$_REQUEST[productinfo]','$_REQUEST[price]','0','0','0','old','$date','0')");
               //echo $inn;
               
           }
           else
           {
               $date=date('Y-m-d');
                $inn=mysql_query("insert into product values('$_SESSION[user]','$_REQUEST[choice]','$_REQUEST[maincate]','$_REQUEST[subcate]','$_REQUEST[company]',0,'$_REQUEST[productname]','$_REQUEST[productinfo]','$_REQUEST[price]','0','0','0','old','$date','0')");
                //echo $inn;
           }
           $send=1;
           $m=1;
       }
    }
    
    
       if(isset($_REQUEST[edit]))
       {
           //echo "hi";
       
          $hart=  mysql_query("select max(imageid) from product_mstr2");
          $hartt=  mysql_fetch_array($hart);
//       /*file uploading*/
    
                $fname=$_FILES[proimg][name];
                //echo $fname."  name   ";
                $types=substr($_FILES[proimg][type],6);
                //echo $types;
                $siz=$_FILES[proimg][size];
                $siz=$siz/1024;
                $siz=$siz/1024;
                //echo $siz. "   size ";
                $ex=".".substr($_FILES[proimg][type],6);
                //echo $ex;
                if($siz<=7)
                {
                    //echo "hii";
                
                    if($ex==".jpg" || $ex==".jpeg" || $ex==".png" || $ex==".gif" || $ex==".bitmap")
                    {
                        
                        //echo "hi";
                        if($hartt[0]=="")
                        {
                            //echo "hndfr";
                            $nwname='product_'.$ex;
                            //echo $nwname; 
                        }
                        else
                        {
                            $nwname='product_'.$hartt[0].$ex;
                        }
                        $path1="product/".$nwname;
                        $path2=dirname(__FILE__)."/product/".$nwname;
                        //echo $nwname;
                        //echo $path1;
                        //echo $path2;
                    }
                    else
                    {
                        $er1=1;
                    }    
                }
////            else
////            {
////                $er2=1;
////            }
//                
//              
//              /*file uploading end*/  
//                
                  if(er1!=1)
                  {
                      
                   //   echo "zgdbt";
                        $inn1=mysql_query("insert into product_mstr2 values('$_REQUEST[pro]','0','$path1')");
                        //echo $inn1;
                        move_uploaded_file($_FILES[proimg][tmp_name],$path2);
                        $m=1;
                  }    
       }
//        if(isset($_REQUEST[exit]))
//        {
//            $m=0;
//        }
       
    
    
    
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'updatescover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'scover.php';
          ?>
        <div class="adminright" id="sadpost">
                <div class="cp">
                  <a href="sellerhome.php#sellerhome" style="color: white;">&vltri;</a>
              </div>
              <div class="ep" style="position: relative;">
                  <br><br>a<br>d<br>d<br><br> p<br>o<br>s<br>t  
              </div>
                    <div class="contact-form" style="margin-left: 250px;">
                        
                        <?php
                            if($m!=1)
                          {
                        ?>
                    <form action="" method="post" >
                    <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                  ?>    
                    <table>
                        <tr>
                            <td colspan="2">
                                <input type="radio" name="choice" value="auction"/>Auction
                            </td>    
                        </tr>
                        <tr>
                            <td>item :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="maincate" onchange="setsubcate(this.value)">
                                    <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from maincategories");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[0]?>"><?php echo $row[1]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                                <?php
                                    if($emaincate==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>type :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="subcate" id="subcate" onchange="setcompany(this.value)">
                                   
                                </select>
                                <?php
                                    if($esubcate==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>company :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>    
                                <select class="select" name="company" id="company">
                                    
                                </select>
                                <?php
                                    if($ecompany==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td> item name :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input type="text" name="productname" placeholder="Enter Productname" />
                            </td>
                            <td>
                                <?php
                                    if($eproductname==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td style="vertical-align: top;">item discription :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <textarea name="productinfo" placeholder="Enter Product Discription" ></textarea>
                            </td>
                            <td>
                                <?php
                                    if($eproductinfo==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>
                        </tr>    
                        <tr>
                            <td>price :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input type="text" name="price" placeholder="Enter Price" />
                            </td>
                            <td>
                                <?php
                                    if($eprice==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                    </table>    
                        <div>
                                <button type="submit" class="feedbackbutton" name="submit">next</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
                                <font style="font-size: 10px;color: red;position: absolute;margin-top: -80px;">note : * blank | ^ invalid </font>
			</div>
                    
                  </form>
                          <?php
                            }
                            else
                            {
                        ?>
                        <form action="" method="post" enctype="multipart/form-data">
                            <table>
                                <tr>
                                    <td>product id :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                    <td colspan="2">
                                        <?php
                                            $dataa=  mysql_query("select max(productid) from product");
                                            $roww=mysql_fetch_array($dataa);
                                        ?>
                                        <input type="text" value="<?php echo $roww[0]; ?>" name="pro" readonly="true"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>product image :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                    <td>
                                        <input type="file" name="proimg"/>
                                    </td>
                                    <td>
                                    <?php
                                        if($er1==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                        elseif($er2==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                    ?>
                                    </td>
                                </tr>
                            </table>
                            <div>
                                <button type="submit" class="feedbackbutton" name="edit">edit</button>
                                <button type="submit" class="feedbackbutton" name="exit">exit</button>
                                <div class="clear"></div>
                            </div>
                        </form>
                        
                        <?php
                           }
                        ?>
               </div>         
           </div>
        <div style="clear: both;">
            
        </div>
    </div>  
   <?php
            require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script> 
</body>
</html>

