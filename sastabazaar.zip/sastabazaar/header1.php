<div class="header_bottom">
			   <div class="slider-text">
                               <h2><b>W</b>elcome </h2>
			   	<p>SastaBazaar operates as a national online classified market place for use goods such as mobile, electronics & computer, vehicles, house & furniture, books & cd, clothing, sports & health, jobs, real estate.  </p>
			   	
                           </div>
                            <div class="slider-img">
                                <img src="images/ek.png" alt="" class="ek"/>
                                <img src="images/be.png" alt="" class="be"/>
                            </div>
                            <div class="clear"></div>
                     </div>