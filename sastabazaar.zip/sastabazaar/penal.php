<?php  
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
?>    