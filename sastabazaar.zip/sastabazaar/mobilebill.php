<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <div style="padding: 5px;background: #454c58;width: 821px;border-radius:3px;">
            <div style="padding: 1px 10px 10px 10px;background: #828d93;color:white;width: 800px;border-radius:3px;border:black solid 1px;">
                <center><img src="mymobile/ganesh.png" style="width: 50px;">
                    <p style="font-size: 10px;margin-top: -5px;">|| Shree Ganesay Nmah ||</p>
                </center>
                <div style="float: left;padding: 10px;width: 250px;">
                    logo
                </div>
                <div style="float: left;font-size: 10px;margin-left: 530px;width: 250px;margin-top: -40px;">
                    <p>Toll-Free No : 1800-7874-3232</p>
                    <p>Email Address : mobilestore@gmail.com</p>
                </div>
                <div style="clear: both;">
                    
                </div>
            </div>
            <div style="margin-top: 5px;border-radius:3px;background: #828d93;color:white;padding: 10px;border:black solid 1px;">
                <div  style="margin-left: -10px;">
                    <table>
                        <tr>
                            <td>
                                <img src="mymobile/nokia-logo.png"  style="width: 100px;height: 50px;">
                            </td>
                            <td>
                                <img src="mymobile/samsung-logo.png"  style="width: 100px;height: 50px;">
                            </td>
                            <td>
                                <img src="mymobile/lg_preview.png"  style="width: 100px;height: 50px;">
                            </td>
                            <td>
                                <img src="mymobile/apple_logo.png"  style="width: 80px;height: 70px;">
                            </td>
                            <td>
                                <img src="mymobile/2000px-Blackberry_Logo.svg"  style="width: 180px;height: 50px;">
                            </td>
                            <td>
                                <img src="mymobile/intex.jpg"  style="width: 100px;height: 50px;">
                            </td>
                            <td>
                                <img src="mymobile/Micromax_SVG_Logo.svg.png"  style="width: 110px;height: 50px;">
                            </td>
                        </tr>
                    </table>
                    
                </div>
            </div>
            <div style="margin-top: 5px;padding: 10px;border-radius:3px;border:black solid 1px;background: #828d93;color:white;">
                <div style="width: 517px;float: left;">
                    <table style="text-transform: capitalize;font-size: 12px;">
                        <tr>
                            <td style="width: 50px;background:#454c58;padding: 5px;border-radius:3px;">
                                Name :
                            </td>
                            <td style="padding: 5px;width: 500px;border-bottom: black solid 1px;">
                                
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50px;background:#454c58;padding: 5px;border-radius:3px;">
                                Mobile :
                            </td>
                            <td style="border-bottom: black solid 1px;padding: 5px;width: 500px;">
                                
                            </td>
                        </tr>
                    </table>
                </div>
                <div style="width: 235px;margin-left: 5px;float: left;">
                    <table style="text-transform: capitalize;font-size: 12px;">
                        <tr>
                            <td style="background:#454c58;padding: 5px;border-radius:3px;">
                                Bill No :
                            </td>
                            <td style="border-bottom: black solid 1px;padding: 5px;width: 150px;">
                                
                            </td>
                        </tr>
                        <tr>
                            <td style="background:#454c58;padding: 5px;border-radius:3px;">
                                Date :
                            </td>
                            <td style="border-bottom: black solid 1px;padding: 5px;">
                                
                            </td>
                        </tr>
                    </table>
                </div>
                <div style="clear: both;"></div>
            </div>
            <div style="background: #828d93;color:white;margin-top: 5px;border-radius:3px;border: black solid 1px;padding: 5px; ">
                
                <div style="width: 517px;float: left;">
                    <table style="text-transform: capitalize;font-size: 12px;">
                    <tr>
                        <td style="width:100px;background:#454c58;padding: 5px;border-radius:3px; ">
                            Company name :
                        </td>
                        <td style="width:400px;border-bottom: black solid 1px;padding: 5px; ">
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px;background:#454c58;padding: 5px; border-radius:3px;">
                            Imei :
                        </td>
                        <td style="width:400px;border-bottom: black solid 1px;padding: 5px; ">
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px;background:#454c58;padding: 5px; border-radius:3px;">
                            Battery :
                        </td>
                        <td style="width:400px;border-bottom: black solid 1px;padding: 5px; ">
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px;background:#454c58;padding: 5px;border-radius:3px; ">
                            Charger :
                        </td>
                        <td style="width:400px;border-bottom: black solid 1px;padding: 5px; ">
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width:100px;border-bottom: black solid 1px;padding: 5px;text-align: center; ">
                            6<sup>th</sup>
                        </td>
                        <td style="width:400px;padding: 5px;vertical-align: bottom; ">
                            months Battery & Charger / guarantee
                        </td>
                    </tr>
                    
                    <tr>
                        <td style="width:100px;border-bottom: black solid 1px;padding: 5px;text-align: center; ">
                            12<sup>th</sup>
                        </td>
                        <td style="width:400px;padding: 5px;vertical-align: bottom; ">
                            months Mobile Phone Warranty
                        </td>
                        
                    </tr>
                    
                </table>
                </div>
                <div style="width:240px;float: left;margin-left: 5px;">
                    <div>
                        <div style="padding: 10px;text-align: center;background:#454c58;border-radius:3px;">
                        AMOUNT
                         </div>
                        
                        <div style="margin-top: 5px;padding: 10px;background:#454c58;border-radius:3px;height: 110px;">
                        
                        </div>
                        
                        
                    </div>
                    
                </div>
               
                <div style="clear: both;">
                    
                </div>
                <div style="padding: 10px;text-transform: capitalize;font-size: 15px;float: left;">
                    <p><b>Note : solded Goods can't take back</b>&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
                    
                    TOTAL</p>
                </div>
                <div style="float: left;padding: 10px;margin-top:13px;width: 220px;border-radius:3px;background:#454c58; ">
                    hi
                </div>
                <div style="clear: both;">
                    
                </div>
            </div>
            <div style="background: #828d93;color:white;padding: 10px;margin-top:5px;border-radius:3px;border:black solid 1px;">
                <div  style="float: left;padding: 5px;width: 500px;border-radius:3px;background:#454c58;">
                    <table>
                    <tr>
                        <td>
                            heey
                        </td>
                    </tr>
                </table>
                </div>
                <div style="float: left;padding: 5px;border-radius:3px;background:#454c58;width: 270px;margin-left: 5px;">
                    <table>
                    <tr>
                        <td>
                            hello
                        </td>
                    </tr>
                </table>
                </div>
                <div style="clear: both;"></div>
                
            </div>
        </div>
    </body>
</html>
