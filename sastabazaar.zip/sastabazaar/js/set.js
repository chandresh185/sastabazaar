/*$(document).ready(function(){
    
    var shu;
    $(".search").keydown(function(){
        shu=$(".search").val();
        alert(shu);
    });
    
});*/

var sv1;




function getmilt1(hid,sh)
{
    //alert(how);
    sv1=GetXmlHttpObject();
    if(sv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="genmultiview1.php?hid="+hid+"&sh="+sh;
     //   alert(url);
        sv1.onreadystatechange=sil1;
        sv1.open("GET",url,true);
        sv1.send(null);
}

function sil1()
{
    if (sv1.readyState==4)
	{

		document.getElementById("genmultiview1").innerHTML=sv1.responseText;

	}
}




var yer4;




function yearr1(year,year1)
{
    //alert(year);
    //alert(year1);
    yer4=GetXmlHttpObject();
    if(yer4==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getyeartra.php?year="+year+"&year1="+year1;
     //   alert(url);
        yer4.onreadystatechange=yer41;
        yer4.open("GET",url,true);
        yer4.send(null);
}

function yer41()
{
    if (yer4.readyState==4)
	{

		document.getElementById("utra").innerHTML=yer4.responseText;

	}
}




var mann;




function month4(mon1,mon2,mon3,mon4)
{
    //alert(mon1);
    //alert(mon2);
    //alert(mon3);
    //alert(mon4);
    mann=GetXmlHttpObject();
    if(mann==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getmonthtra.php?mon1="+mon1+"&mon2="+mon2+"&mon3="+mon3+"&mon4="+mon4;
     //   alert(url);
        mann.onreadystatechange=mann1;
        mann.open("GET",url,true);
        mann.send(null);
}

function mann1()
{
    if (mann.readyState==4)
	{

		document.getElementById("utra").innerHTML=mann.responseText;

	}
}





var date;




function datee1(datee,date1)
{
   // alert(datee);
   // alert(date1);
    date=GetXmlHttpObject();
    if(date==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getdateutra.php?datee="+datee+"&date1="+date1;
     //   alert(url);
        date.onreadystatechange=date2;
        date.open("GET",url,true);
        date.send(null);
}

function date2()
{
    if (date.readyState==4)
	{

		document.getElementById("utra").innerHTML=date.responseText;

	}
}






var lph;




function lohip1(lop,hip)
{
    //alert(sh);
    lph=GetXmlHttpObject();
    if(lph==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?lop="+lop+"&hip="+hip;
     //   alert(url);
        lph.onreadystatechange=lph1;
        lph.open("GET",url,true);
        lph.send(null);
}

function lph1()
{
    if (lph.readyState==4)
	{

		document.getElementById("utra").innerHTML=lph.responseText;

	}
}





var tct;




function tracity(tcty)
{
    //alert(sh);
    tct=GetXmlHttpObject();
    if(tct==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?tcty="+tcty;
     //   alert(url);
        tct.onreadystatechange=tct1;
        tct.open("GET",url,true);
        tct.send(null);
}

function tct1()
{
    if (tct.readyState==4)
	{

		document.getElementById("utra").innerHTML=tct.responseText;

	}
}







var tsta;




function trasta(ts)
{
    //alert(sh);
    tsta=GetXmlHttpObject();
    if(tsta==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?ts="+ts;
     //   alert(url);
        tsta.onreadystatechange=tsta1;
        tsta.open("GET",url,true);
        tsta.send(null);
}

function tsta1()
{
    if (tsta.readyState==4)
	{

		document.getElementById("utra").innerHTML=tsta.responseText;

	}
}






var tcon;




function tracon(tc)
{
    //alert(sh);
    tcon=GetXmlHttpObject();
    if(tcon==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?tc="+tc;
     //   alert(url);
        tcon.onreadystatechange=tcon1;
        tcon.open("GET",url,true);
        tcon.send(null);
}

function tcon1()
{
    if (tcon.readyState==4)
	{

		document.getElementById("utra").innerHTML=tcon.responseText;

	}
}




var tbno;




function trabon(tbn)
{
    //alert(sh);
    tbno=GetXmlHttpObject();
    if(tbno==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?tbn="+tbn;
     //   alert(url);
        tbno.onreadystatechange=tbno1;
        tbno.open("GET",url,true);
        tbno.send(null);
}

function tbno1()
{
    if (tbno.readyState==4)
	{

		document.getElementById("utra").innerHTML=tbno.responseText;

	}
}



var userb;




function userbill(buyer)
{
    //alert(sh);
    userb=GetXmlHttpObject();
    if(userb==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getutra.php?buyer="+buyer;
     //   alert(url);
        userb.onreadystatechange=userb1;
        userb.open("GET",url,true);
        userb.send(null);
}

function userb1()
{
    if (userb.readyState==4)
	{

		document.getElementById("utra").innerHTML=userb.responseText;

	}
}



var man;




function getmonth(mn1,mn2,mn3,mn4)
{
    //alert(mn1);
    //alert(mn2);
    //alert(mn3);
    //alert(mn4);
    man=GetXmlHttpObject();
    if(man==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getmonthbill.php?mn1="+mn1+"&mn2="+mn2+"&mn3="+mn3+"&mn4="+mn4;
     //   alert(url);
        man.onreadystatechange=man1;
        man.open("GET",url,true);
        man.send(null);
}

function man1()
{
    if (man.readyState==4)
	{

		document.getElementById("printt").innerHTML=man.responseText;

	}
}




var dat;




function dtdt1(dt,dt1)
{
    //alert(dt);
    //alert(dt1);
    dat=GetXmlHttpObject();
    if(dat==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getdatebill.php?dt="+dt+"&dt1="+dt1;
     //   alert(url);
        dat.onreadystatechange=dat1;
        dat.open("GET",url,true);
        dat.send(null);
}

function dat1()
{
    if (dat.readyState==4)
	{

		document.getElementById("printt").innerHTML=dat.responseText;

	}
}


var yer;




function yeye1(ye,ye1)
{
   // alert(ye);
    //alert(ye1);
    yer=GetXmlHttpObject();
    if(yer==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getyearbill.php?ye="+ye+"&ye1="+ye1;
     //   alert(url);
        yer.onreadystatechange=yer1;
        yer.open("GET",url,true);
        yer.send(null);
}

function yer1()
{
    if (yer.readyState==4)
	{

		document.getElementById("printt").innerHTML=yer.responseText;

	}
}







var cit;




function setcitybill(ccname)
{
    //alert(ccname);
    cit=GetXmlHttpObject();
    if(cit==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?ccname="+ccname;
   //alert(url);
        cit.onreadystatechange=cit1;
        cit.open("GET",url,true);
        cit.send(null);
}

function cit1()
{
    if (cit.readyState==4)
	{

		document.getElementById("printt").innerHTML=cit.responseText;

	}
}





var sta;




function setstabill(sname)
{
    //alert(sname);
    sta=GetXmlHttpObject();
    if(sta==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?sname="+sname;
  // alert(url);
        sta.onreadystatechange=sta1;
        sta.open("GET",url,true);
        sta.send(null);
}

function sta1()
{
    if (sta.readyState==4)
	{

		document.getElementById("printt").innerHTML=sta.responseText;

	}
}




var deldeh;




function deldealerhis(prodid1)
{
    //alert(status);
    //alert(proid);
    deldeh=GetXmlHttpObject();
    if(deldeh==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getdealerhistory.php?prodid1="+prodid1;
    //alert(url);
        deldeh.onreadystatechange=deldeh1;
        deldeh.open("GET",url,true);
        deldeh.send(null);
}

function deldeh1()
{
    if (deldeh.readyState==4)
	{

		document.getElementById("dehisid").innerHTML=deldeh.responseText;

	}
}



var dehact;




function setdeacthistory(status1,proid1)
{
    //alert(status1);
    //alert(proid1);
    dehact=GetXmlHttpObject();
    if(dehact==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getdealerhistory.php?status1="+status1+"&proid1="+proid1;
    //alert(url);
        dehact.onreadystatechange=dehact1;
        dehact.open("GET",url,true);
        dehact.send(null);
}

function dehact1()
{
    if (dehact.readyState==4)
	{

		document.getElementById("dehisid").innerHTML=dehact.responseText;

	}
}



var dehis;




function setdealerhistory()
{
    //alert(cname);
    dehis=GetXmlHttpObject();
    if(dehis==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getdealerhistory.php";
    //alert(url);
        dehis.onreadystatechange=dehis1;
        dehis.open("GET",url,true);
        dehis.send(null);
}

function dehis1()
{
    if (dehis.readyState==4)
	{

		document.getElementById("dehisid").innerHTML=dehis.responseText;

	}
}





var delh;




function delhis(prodid)
{
    //alert(status);
    //alert(proid);
    delh=GetXmlHttpObject();
    if(delh==null)
        {
            alert("browser does not support");
            return;
        }
        var url="gethistory.php?prodid="+prodid;
    //alert(url);
        delh.onreadystatechange=delh1;
        delh.open("GET",url,true);
        delh.send(null);
}

function delh1()
{
    if (delh.readyState==4)
	{

		document.getElementById("hisid").innerHTML=delh.responseText;

	}
}





var hact;




function setacthistory(status,proid)
{
    //alert(status);
    //alert(proid);
    hact=GetXmlHttpObject();
    if(hact==null)
        {
            alert("browser does not support");
            return;
        }
        var url="gethistory.php?status="+status+"&proid="+proid;
    //alert(url);
        hact.onreadystatechange=hact1;
        hact.open("GET",url,true);
        hact.send(null);
}

function hact1()
{
    if (hact.readyState==4)
	{

		document.getElementById("hisid").innerHTML=hact.responseText;

	}
}






var his;




function sethistory()
{
    //alert(cname);
    his=GetXmlHttpObject();
    if(his==null)
        {
            alert("browser does not support");
            return;
        }
        var url="gethistory.php";
    //alert(url);
        his.onreadystatechange=his1;
        his.open("GET",url,true);
        his.send(null);
}

function his1()
{
    if (his.readyState==4)
	{

		document.getElementById("hisid").innerHTML=his.responseText;

	}
}



var cont;




function setconbill(cname)
{
    //alert(cname);
    cont=GetXmlHttpObject();
    if(cont==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?cname="+cname;
   //alert(url);
        cont.onreadystatechange=conth1;
        cont.open("GET",url,true);
        cont.send(null);
}

function conth1()
{
    if (cont.readyState==4)
	{

		document.getElementById("printt").innerHTML=cont.responseText;

	}
}





function beed(pno)
{
    window.location.href="beed.php?id="+pno;
}


var ac;




function activepro()
{
    //alert();
    ac=GetXmlHttpObject();
    if(ac==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getactive.php";
     //   alert(url);
        ac.onreadystatechange=ac1;
        ac.open("GET",url,true);
        ac.send(null);
}

function ac1()
{
    if (ac.readyState==4)
	{

		document.getElementById("active").innerHTML=ac.responseText;

	}
}




var be;




function getbeed1(how)
{
    //alert(how);
    
    var price=document.getElementById("beed").value;
    //alert(price);        
    
   //alert(price);
    be=GetXmlHttpObject();
    if(be==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getbeed.php?how="+how+"&price="+price;
     //   alert(url);
        be.onreadystatechange=be1;
        be.open("GET",url,true);
        be.send(null);
}

function be1()
{
    if (be.readyState==4)
	{

		document.getElementById("beedd").innerHTML=be.responseText;

	}
}




var kmv1;




function kmilt1(how,shu,kyathi)
{
    //alert(how);
    kmv1=GetXmlHttpObject();
    if(kmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="kmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        kmv1.onreadystatechange=kmil1;
        kmv1.open("GET",url,true);
        kmv1.send(null);
}

function kmil1()
{
    if (kmv1.readyState==4)
	{

		document.getElementById("kmultiview1").innerHTML=kmv1.responseText;

	}
}




var kmv;




function kmilt(how1,shu)
{
    //alert(how1);
    kmv=GetXmlHttpObject();
    if(kmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="kmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        kmv.onreadystatechange=kmil;
        kmv.open("GET",url,true);
        kmv.send(null);
}

function kmil()
{
    if (kmv.readyState==4)
	{

		document.getElementById("kmultiview1").innerHTML=kmv.responseText;

	}
}





var pmv1;




function pmilt1(how,shu,kyathi)
{
    //alert(how);
    pmv1=GetXmlHttpObject();
    if(pmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="pmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        pmv1.onreadystatechange=pmil1;
        pmv1.open("GET",url,true);
        pmv1.send(null);
}

function pmil1()
{
    if (pmv1.readyState==4)
	{

		document.getElementById("pmultiview1").innerHTML=pmv1.responseText;

	}
}




var pmv;




function pmilt(how1,shu)
{
    //alert(how1);
    pmv=GetXmlHttpObject();
    if(pmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="pmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        pmv.onreadystatechange=pmil;
        pmv.open("GET",url,true);
        pmv.send(null);
}

function pmil()
{
    if (pmv.readyState==4)
	{

		document.getElementById("pmultiview1").innerHTML=pmv.responseText;

	}
}






var rmv1;




function rmilt1(how,shu,kyathi)
{
    //alert(how);
    rmv1=GetXmlHttpObject();
    if(rmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="rmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        rmv1.onreadystatechange=rmil1;
        rmv1.open("GET",url,true);
        rmv1.send(null);
}

function rmil1()
{
    if (rmv1.readyState==4)
	{

		document.getElementById("rmultiview1").innerHTML=rmv1.responseText;

	}
}




var rmv;




function rmilt(how1,shu)
{
    //alert(how1);
    rmv=GetXmlHttpObject();
    if(rmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="rmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        rmv.onreadystatechange=rmil;
        rmv.open("GET",url,true);
        rmv.send(null);
}

function rmil()
{
    if (rmv.readyState==4)
	{

		document.getElementById("rmultiview1").innerHTML=rmv.responseText;

	}
}






var jmv1;




function jmilt1(how,shu,kyathi)
{
    //alert(how);
    jmv1=GetXmlHttpObject();
    if(jmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="jmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        jmv1.onreadystatechange=jmil1;
        jmv1.open("GET",url,true);
        jmv1.send(null);
}

function jmil1()
{
    if (jmv1.readyState==4)
	{

		document.getElementById("jmultiview1").innerHTML=jmv1.responseText;

	}
}




var jmv;




function jmilt(how1,shu)
{
    //alert(how1);
    jmv=GetXmlHttpObject();
    if(jmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="jmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        jmv.onreadystatechange=jmil;
        jmv.open("GET",url,true);
        jmv.send(null);
}

function jmil()
{
    if (jmv.readyState==4)
	{

		document.getElementById("jmultiview1").innerHTML=jmv.responseText;

	}
}





var spmv1;




function spmilt1(how,shu,kyathi)
{
    //alert(how);
    spmv1=GetXmlHttpObject();
    if(spmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="spmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        spmv1.onreadystatechange=spmil1;
        spmv1.open("GET",url,true);
        spmv1.send(null);
}

function spmil1()
{
    if (spmv1.readyState==4)
	{

		document.getElementById("spmultiview1").innerHTML=spmv1.responseText;

	}
}




var spmv;




function spmilt(how1,shu)
{
    //alert(how1);
    spmv=GetXmlHttpObject();
    if(spmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="spmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        spmv.onreadystatechange=spmil;
        spmv.open("GET",url,true);
        spmv.send(null);
}

function spmil()
{
    if (spmv.readyState==4)
	{

		document.getElementById("spmultiview1").innerHTML=spmv.responseText;

	}
}






var fmv1;




function fmilt1(how,shu,kyathi)
{
    //alert(how);
    fmv1=GetXmlHttpObject();
    if(fmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="fmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        fmv1.onreadystatechange=fmil1;
        fmv1.open("GET",url,true);
        fmv1.send(null);
}

function fmil1()
{
    if (fmv1.readyState==4)
	{

		document.getElementById("fmultiview1").innerHTML=fmv1.responseText;

	}
}




var fmv;




function fmilt(how1,shu)
{
    //alert(how1);
    fmv=GetXmlHttpObject();
    if(fmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="fmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        fmv.onreadystatechange=fmil;
        fmv.open("GET",url,true);
        fmv.send(null);
}

function fmil()
{
    if (fmv.readyState==4)
	{

		document.getElementById("fmultiview1").innerHTML=fmv.responseText;

	}
}






var bmv1;




function bmilt1(how,shu,kyathi)
{
    //alert(how);
    bmv1=GetXmlHttpObject();
    if(bmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="bmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        bmv1.onreadystatechange=bmil1;
        bmv1.open("GET",url,true);
        bmv1.send(null);
}

function bmil1()
{
    if (bmv1.readyState==4)
	{

		document.getElementById("bmultiview1").innerHTML=bmv1.responseText;

	}
}




var bmv;




function bmilt(how1,shu)
{
    //alert(how1);
    bmv=GetXmlHttpObject();
    if(bmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="bmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        bmv.onreadystatechange=bmil;
        bmv.open("GET",url,true);
        bmv.send(null);
}

function bmil()
{
    if (bmv.readyState==4)
	{

		document.getElementById("bmultiview1").innerHTML=bmv.responseText;

	}
}





var hmv1;




function hmilt1(how,shu,kyathi)
{
    //alert(how);
    hmv1=GetXmlHttpObject();
    if(hmv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="hmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        hmv1.onreadystatechange=hmil1;
        hmv1.open("GET",url,true);
        hmv1.send(null);
}

function hmil1()
{
    if (hmv1.readyState==4)
	{

		document.getElementById("hmultiview1").innerHTML=hmv1.responseText;

	}
}




var hmv;




function hmilt(how1,shu)
{
    //alert(how1);
    hmv=GetXmlHttpObject();
    if(hmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="hmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        hmv.onreadystatechange=hmil;
        hmv.open("GET",url,true);
        hmv.send(null);
}

function hmil()
{
    if (hmv.readyState==4)
	{

		document.getElementById("hmultiview1").innerHTML=hmv.responseText;

	}
}





var vmc1;




function vmilt1(how,shu,kyathi)
{
    //alert(how);
    vmc1=GetXmlHttpObject();
    if(vmc1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="vmultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        vmc1.onreadystatechange=vmil1;
        vmc1.open("GET",url,true);
        vmc1.send(null);
}

function vmil1()
{
    if (vmc1.readyState==4)
	{

		document.getElementById("vmultiview1").innerHTML=vmc1.responseText;

	}
}




var vmv;




function vmilt(how1,shu)
{
    //alert(how1);
    vmv=GetXmlHttpObject();
    if(vmv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="vmultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        vmv.onreadystatechange=vmil;
        vmv.open("GET",url,true);
        vmv.send(null);
}

function vmil()
{
    if (vmv.readyState==4)
	{

		document.getElementById("vmultiview1").innerHTML=vmv.responseText;

	}
}





var emv1;




function emilt1(how,shu,kyathi)
{
    //alert(how);
    emv1=GetXmlHttpObject();
    if(emv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="emultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        emv1.onreadystatechange=emil1;
        emv1.open("GET",url,true);
        emv1.send(null);
}

function emil1()
{
    if (emv1.readyState==4)
	{

		document.getElementById("emultiview1").innerHTML=emv1.responseText;

	}
}




var emv;




function emilt(how1,shu)
{
    //alert(how1);
    emv=GetXmlHttpObject();
    if(emv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="emultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        emv.onreadystatechange=emil;
        emv.open("GET",url,true);
        emv.send(null);
}

function emil()
{
    if (emv.readyState==4)
	{

		document.getElementById("emultiview1").innerHTML=emv.responseText;

	}
}




var amv1;




function amilt1(how,shu,kyathi)
{
    //alert(how);
    amv1=GetXmlHttpObject();
    if(amv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="amultiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        amv1.onreadystatechange=amil1;
        amv1.open("GET",url,true);
        amv1.send(null);
}

function amil1()
{
    if (amv1.readyState==4)
	{

		document.getElementById("amultiview1").innerHTML=amv1.responseText;

	}
}




var amv;




function amilt(how1,shu)
{
    //alert(how1);
    amv=GetXmlHttpObject();
    if(amv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="amultiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        amv.onreadystatechange=amil;
        amv.open("GET",url,true);
        amv.send(null);
}

function amil()
{
    if (amv.readyState==4)
	{

		document.getElementById("amultiview1").innerHTML=amv.responseText;

	}
}



var aphoto;
function getphoto1(ky)
{
    //alert(kyo);
    aphoto=GetXmlHttpObject();
    if(aphoto==null)
        {
            alert("browser does not support");
            return;
        }
        var url="takephoto.php?ky="+ky;
        //alert(url);
        aphoto.onreadystatechange=aphoto1;
        aphoto.open("GET",url,true);
        aphoto.send(null);
}
function aphoto1()
{
    if (aphoto.readyState==4)
	{

		document.getElementById("acphoto").innerHTML=aphoto.responseText;

	}
}






var seaph;
function getphoto(kyo)
{
    //alert(kyo);
    seaph=GetXmlHttpObject();
    if(seaph==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getphoto.php?kyo="+kyo;
        //alert(url);
        seaph.onreadystatechange=sea1ph;
        seaph.open("GET",url,true);
        seaph.send(null);
}
function sea1ph()
{
    if (seaph.readyState==4)
	{

		document.getElementById("missphoto").innerHTML=seaph.responseText;

	}
}





var s;
function gsearch(str)
{
    //alert(str);
    s=GetXmlHttpObject();
    if(s==null)
        {
            alert("browser does not support");
            return;
        }
        var url="globalsearch.php?str="+str;
      //alert(url);
        s.onreadystatechange=s1;
        s.open("GET",url,true);
        s.send(null);
}

function s1()
{
    if (s.readyState==4)
	{

		document.getElementById("search").innerHTML=s.responseText;

	}
}



var sea;
function search1(str,str1)
{
    //alert(sh);
    sea=GetXmlHttpObject();
    if(sea==null)
        {
            alert("browser does not support");
            return;
        }
        var url="search.php?val="+str+"&shu="+str1;
     //   alert(url);
        sea.onreadystatechange=sea1;
        sea.open("GET",url,true);
        sea.send(null);
}

function sea1()
{
    if (sea.readyState==4)
	{

		document.getElementById("disid").innerHTML=sea.responseText;

	}
}







var sse;
function slact(pid)
{
    //alert(sh);
    sse=GetXmlHttpObject();
    if(sse==null)
        {
            alert("browser does not support");
            return;
        }
        var url="upgetseller.php?id="+pid+"&base=1";
     //   alert(url);
        sse.onreadystatechange=sse1;
        sse.open("GET",url,true);
        sse.send(null);
}

function sse1()
{
    if (sse.readyState==4)
	{

		document.getElementById("seller").innerHTML=sse.responseText;

	}
}


var se;




function selp(base)
{
    //alert(sh);
    se=GetXmlHttpObject();
    if(se==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getseller.php?base="+base;
     //   alert(url);
        se.onreadystatechange=se1;
        se.open("GET",url,true);
        se.send(null);
}

function se1()
{
    if (se.readyState==4)
	{

		document.getElementById("seller").innerHTML=se.responseText;

	}
}


var mff1;

function mjj()
{
    //alert(sh);
    mff1=GetXmlHttpObject();
    if(mff1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="oneimg1.php";
     //   alert(url);
        mff1.onreadystatechange=mjj1;
        mff1.open("GET",url,true);
        mff1.send(null);
}

function mjj1()
{
    if (mff1.readyState==4)
	{

		document.getElementById("mjimg1").innerHTML=mff1.responseText;

	}
}







var mf1;

function mj()
{
    //alert(sh);
    mf1=GetXmlHttpObject();
    if(mf1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="oneimg.php";
     //   alert(url);
        mf1.onreadystatechange=mj1;
        mf1.open("GET",url,true);
        mf1.send(null);
}

function mj1()
{
    if (mf1.readyState==4)
	{

		document.getElementById("mjimg").innerHTML=mf1.responseText;

	}
}





var mv1;




function milt1(how,shu,kyathi)
{
    //alert(how);
    mv1=GetXmlHttpObject();
    if(mv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="multiview1.php?how="+how+"&shu="+shu+"&kyathi="+kyathi;
     //   alert(url);
        mv1.onreadystatechange=mil1;
        mv1.open("GET",url,true);
        mv1.send(null);
}

function mil1()
{
    if (mv1.readyState==4)
	{

		document.getElementById("multiview1").innerHTML=mv1.responseText;

	}
}




var mv;




function milt(how1,shu)
{
    //alert(how1);
    mv=GetXmlHttpObject();
    if(mv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="multiview.php?how1="+how1+"&shu="+shu;
     //   alert(url);
        mv.onreadystatechange=mil;
        mv.open("GET",url,true);
        mv.send(null);
}

function mil()
{
    if (mv.readyState==4)
	{

		document.getElementById("multiview1").innerHTML=mv.responseText;

	}
}





var bi11;




function lphp1(lp,hp)
{
    //alert(sh);
    bi11=GetXmlHttpObject();
    if(bi11==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?lp="+lp+"&hp="+hp;
     //   alert(url);
        bi11.onreadystatechange=bil11;
        bi11.open("GET",url,true);
        bi11.send(null);
}

function bil11()
{
    if (bi11.readyState==4)
	{

		document.getElementById("printt").innerHTML=bi11.responseText;

	}
}








var rv1;




function act(rid)
{
    //alert(sh);
    rv1=GetXmlHttpObject();
    if(rv1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="upact.php?id="+rid+"&base=1";
     //   alert(url);
        rv1.onreadystatechange=rw1;
        rv1.open("GET",url,true);
        rv1.send(null);
}

function rw1()
{
    if (rv1.readyState==4)
	{

		document.getElementById("view").innerHTML=rv1.responseText;

	}
}









var rv;




function rev(base)
{
    //alert(sh);
    rv=GetXmlHttpObject();
    if(rv==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getreview.php?base="+base;
     //   alert(url);
        rv.onreadystatechange=rw;
        rv.open("GET",url,true);
        rv.send(null);
}

function rw()
{
    if (rv.readyState==4)
	{

		document.getElementById("view").innerHTML=rv.responseText;

	}
}







var idu;




function bon(bn)
{
    //alert(sh);
    idu=GetXmlHttpObject();
    if(idu==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?bn="+bn;
     //   alert(url);
        idu.onreadystatechange=idu1;
        idu.open("GET",url,true);
        idu.send(null);
}

function idu1()
{
    if (idu.readyState==4)
	{

		document.getElementById("printt").innerHTML=idu.responseText;

	}
}







var ub;




function ubill(uname)
{
    //alert(sh);
    ub=GetXmlHttpObject();
    if(ub==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php?uname="+uname;
     //   alert(url);
        ub.onreadystatechange=ubb;
        ub.open("GET",url,true);
        ub.send(null);
}

function ubb()
{
    if (ub.readyState==4)
	{

		document.getElementById("printt").innerHTML=ub.responseText;

	}
}







var adb;




function adminb()
{
    //alert(sh);
    adb=GetXmlHttpObject();
    if(adb==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getallbill.php";
     //   alert(url);
        adb.onreadystatechange=adbb;
        adb.open("GET",url,true);
        adb.send(null);
}

function adbb()
{
    if (adb.readyState==4)
	{

		document.getElementById("printt").innerHTML=adb.responseText;

	}
}







var bi1;




function lphp(lp,hp)
{
    //alert(sh);
    bi1=GetXmlHttpObject();
    if(bi1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getbill.php?lp="+lp+"&hp="+hp;
     //   alert(url);
        bi1.onreadystatechange=bil1;
        bi1.open("GET",url,true);
        bi1.send(null);
}

function bil1()
{
    if (bi1.readyState==4)
	{

		document.getElementById("print").innerHTML=bi1.responseText;

	}
}







var bi;




function billl(bno)
{
    //alert(sh);
    bi=GetXmlHttpObject();
    if(bi==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getbill.php?bid="+bno;
     //   alert(url);
        bi.onreadystatechange=bil;
        bi.open("GET",url,true);
        bi.send(null);
}

function bil()
{
    if (bi.readyState==4)
	{

		document.getElementById("print").innerHTML=bi.responseText;

	}
}


var cap1;




function ref1()
{
    //alert(sh);
    cap1=GetXmlHttpObject();
    if(cap1==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getpaycap.php";
     //   alert(url);
        cap1.onreadystatechange=refe1;
        cap1.open("GET",url,true);
        cap1.send(null);
}

function refe1()
{
    if (cap1.readyState==4)
	{

		document.getElementById("pcapid").innerHTML=cap1.responseText;

	}
}






var cap;




function ref()
{
    //alert();
    cap=GetXmlHttpObject();
    if(cap==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getcap.php";
      //alert(url);
        cap.onreadystatechange=refe;
        cap.open("GET",url,true);
        cap.send(null);
}

function refe()
{
    if (cap.readyState==4)
	{

		document.getElementById("capid").innerHTML=cap.responseText;

	}
}




var grand;




function setgrand()
{
    //alert(sh);
    grand=GetXmlHttpObject();
    if(grand==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getgrand.php";
     //   alert(url);
        grand.onreadystatechange=grandChanged;
        grand.open("GET",url,true);
        grand.send(null);
}

function grandChanged()
{
    if (grand.readyState==4)
	{

		document.getElementById("grandid").innerHTML=grand.responseText;

	}
}



var cart;




function setprice(qty,rate,id)
{
    //alert(qty);
    cart=GetXmlHttpObject();
    if(cart==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getprice.php?qty="+qty+"&rate="+rate+"&id="+id;
    //alert(url);
        cart.onreadystatechange=priceChanged;
        cart.open("GET",url,true);
        cart.send(null);
}

function priceChanged()
{
    if (cart.readyState==4)
	{

		document.getElementById("price").innerHTML=cart.responseText;

	}
}



var xmlhttpp;




function shu(sh)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getcont.php?id="+sh
     //   alert(url);
        xmlhttpp.onreadystatechange=stt;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}

function stt()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("cont").innerHTML=xmlhttpp.responseText;

	}
}






var xmlhttp;

function setstate(name)
{
    //alert(name);
    xmlhttp=GetXmlHttpObject();
    if(xmlhttp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getstate.php?id="+name;
     //   alert(url);
        xmlhttp.onreadystatechange=st;
        xmlhttp.open("GET",url,true);
        xmlhttp.send(null);
}
function st()
{
    if (xmlhttp.readyState==4)
	{

		document.getElementById("state").innerHTML=xmlhttp.responseText;

	}
}


function setcity(name)
{
    //alert(name);
    xmlhttp=GetXmlHttpObject();
    if(xmlhttp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getcity.php?id="+name;
     //   alert(url);
        xmlhttp.onreadystatechange=ct;
        xmlhttp.open("GET",url,true);
        xmlhttp.send(null);
}
function ct()
{
    if (xmlhttp.readyState==4)
	{

		document.getElementById("city").innerHTML=xmlhttp.responseText;

	}
}

function setsubcate(name)
{
    //alert(name);
    xmlhttp=GetXmlHttpObject();
    if(xmlhttp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getsubcate.php?id="+name;
     //   alert(url);
        xmlhttp.onreadystatechange=sub;
        xmlhttp.open("GET",url,true);
        xmlhttp.send(null);
}
function sub()
{
    if (xmlhttp.readyState==4)
	{

		document.getElementById("subcate").innerHTML=xmlhttp.responseText;

	}
}

function setcompany(name)
{
    //alert(name);
    xmlhttp=GetXmlHttpObject();
    if(xmlhttp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="getcompany.php?id="+name;
     //   alert(url);
        xmlhttp.onreadystatechange=com;
        xmlhttp.open("GET",url,true);
        xmlhttp.send(null);
}
function com()
{
    if (xmlhttp.readyState==4)
	{

		document.getElementById("company").innerHTML=xmlhttp.responseText;

	}
}



function country()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discountry.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=co;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function co()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("country3").innerHTML=xmlhttpp.responseText;

	}
}
function counttry(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discountry.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=co1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function co1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("country3").innerHTML=xmlhttpp.responseText;

	}
}
function state()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disstate.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=stt;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function stt()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("state3").innerHTML=xmlhttpp.responseText;

	}
}
function statte(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disstate.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=stt1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function stt1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("state3").innerHTML=xmlhttpp.responseText;

	}
}

function city()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discity.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=c;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}

function c()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("city3").innerHTML=xmlhttpp.responseText;

	}
}

function citty(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discity.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=c1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}

function c1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("city3").innerHTML=xmlhttpp.responseText;

	}
}
function feedback()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disfeedback.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=fee;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function fee()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("feedback3").innerHTML=xmlhttpp.responseText;

	}
}
function feed(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disfeedback.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=fee1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function fee1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("feedback3").innerHTML=xmlhttpp.responseText;

	}
}
function contact()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discontact.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=con;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function con()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("contact3").innerHTML=xmlhttpp.responseText;

	}
}
function contact1(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="discontact.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=con1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function con1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("contact3").innerHTML=xmlhttpp.responseText;

	}
}
function user()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disuser.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=use;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function use()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("user3").innerHTML=xmlhttpp.responseText;

	}
}
function user1(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disuser.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=use1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function use1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("user3").innerHTML=xmlhttpp.responseText;

	}
}
function adrate()
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disad_rate.php";
     //   alert(url);
        xmlhttpp.onreadystatechange=ad;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function ad()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("adrate3").innerHTML=xmlhttpp.responseText;

	}
}
function adrate1(str,str1)
{
    //alert(sh);
    xmlhttpp=GetXmlHttpObject();
    if(xmlhttpp==null)
        {
            alert("browser does not support");
            return;
        }
        var url="disad_rate.php?ch="+str+"&pp="+str1;
     //   alert(url);
        xmlhttpp.onreadystatechange=ad1;
        xmlhttpp.open("GET",url,true);
        xmlhttpp.send(null);
}
function ad1()
{
    if (xmlhttpp.readyState==4)
	{

		document.getElementById("adrate3").innerHTML=xmlhttpp.responseText;

	}
}

function GetXmlHttpObject()
{
if (window.XMLHttpRequest)
  {
  // code for IE7+, Firefox, Chrome, Opera, Safari
  return new XMLHttpRequest();
  }
if (window.ActiveXObject)
  {
  // code for IE6, IE5
  return new ActiveXObject("Microsoft.XMLHTTP");
  }
return null;
}
