<?php
require_once 'conn.php';
$tot=$_REQUEST[qty]*$_REQUEST[rate];
//echo $_REQUEST[rate];
$up=  mysql_query("update cart set qty='$_REQUEST[qty]',total='$tot' where userid='$_SESSION[user]' and productid='$_REQUEST[id]'");





?>
                          <th>no</th>
                            <th>product image</th>
                            <th>product name</th>
                            <th>price</th>
                            
                            <th>qty</th>
                            <th>total price</th>
                            <th>delete</th>
                            <?php
                                    $c=0;
                                    $all=mysql_query("select p.productname,c.*,p.stock from product p,cart c where p.productid=c.productid and c.userid='$_SESSION[user]'");
                                    while($rec=  mysql_fetch_array($all))
                                    {
                                        $set=mysql_query("select productimage from product_mstr2 where productid='$rec[2]'");
                                        $set1=mysql_fetch_array($set);
                                        $c++;  
                            ?>
                            <tr align="center">
                                
                                <td>
                                    <?php
                                        echo $c; 
                                    ?>
                                </td>
                                <td>
                                   <img src="<?php echo $set1[0]; ?>" style="border-radius:3px;width: 50px;height: 60px;"/>
                                </td>
                                <td>
                                    <?php
                                        echo "$rec[0]"; 
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo "$rec[5]"; 
                                    ?>
                                </td>
                                
                                <td>
                                    <input type="number" min="1" name="qty" max="<?php echo $rec[7]; ?>" value="<?php echo $rec[4]; ?>" onchange="setprice(this.value,'<?php echo $rec[5];?>','<?php echo $rec[2];?>'); setgrand();" style="color: black;width: 60px;border: none;">
                                </td>
                                <td>
                                    <?php
                                       
                                        echo $rec[5]*$rec[4]; 
                                    ?>
                                </td>
                                <td>
                                    <center><a href="delete.php?&ek=cartt"><img src="images/delete.png" style="width: 25px;"/></a></center>
                                </td>
                                
                            </tr>
                            <?php
                                $tot=$rec[5]*$rec[4];
                                $maintot=$maintot+$tot;
                                }
                            ?>       
                            
                            <tr id="grandid">
                                
                                <td colspan="7" style="background: #23272a;padding: 15px;color: white;text-align: right;font-size: 15px;font-weight: bold;">
                                    grand total :
                                        <?php
                                           echo  $_SESSION[hardik]=$maintot;
                                           
                                        ?>
                                </td>
                            </tr>
                            <tr align="right" style="">
                                <td colspan="8">
                                    <a href="product.php" style="background: #23272a;color: white;font-size: 12px;padding: 10px;text-decoration: none;">continue shopping</a>
                                    <a href="checkout.php" style="background: #23272a;color: white;font-size: 12px;padding: 10px;text-decoration: none;">check out</a>
                                </td>
                            </tr>  