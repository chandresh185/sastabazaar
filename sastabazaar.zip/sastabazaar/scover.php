<script type="text/javascript">
$(document).ready(function(){
   $("#ssett").click(function(){
       $(".ssetting").css('display','block');
       $(".sset").css('display','block');
   });
});

</script>
<div style="padding: 5px;margin-top: 10px;">
              <div>
                  <?php
                        $c=  mysql_query("select * from scover where userid='$_SESSION[user]'");
                        $cc=  mysql_fetch_array($c);
                  ?>
                  <img src="<?php echo $cc[1]; ?>" height="450px" width="1288px" style="border-radius:5px;border: 1px solid #e44f2b;"/>
              </div>   
              <div style="margin-left: 40px;width: 200px;margin-top: -150px;">
                  <?php
                    $im=  mysql_query("select image from registration where userid='$_SESSION[user]'");
                    $imm=  mysql_fetch_array($im); 
                  ?>
                  <img src="<?php echo $imm[0]; ?>" height="200px" width="250px" style="z-index: 999;position: relative;border-radius:100px;-webkit-filter:drop-shadow(4px 4px 4px #23272a);"/>
              </div>
              <div style="font-size: 20px;text-transform: capitalize;margin-left: 250px;margin-top: -85px;position: absolute;color: #e44f2b;">
                  <?php
                        $in=  mysql_query("select * from registration where userid = '$_SESSION[user]'");
                        $a=  mysql_fetch_array($in);
                        echo $a[1];
                  ?>
              </div> 
    <div id="ssett" style="position: absolute;margin-top: -85px;margin-left: 1250px;">
        <img src="images/settings-icon.png" width="25px"/>
    </div>
              <div class="coverhead" style="background: #e44f2b;color: white;margin-left: 30px;padding: 20px;border-radius:50px 0px 0px 50px;margin-top: -40px;">
                  <?php
                       $in1=  mysql_query("select * from logintime where userid = '$_SESSION[user]'");
                      $a1=  mysql_fetch_array($in1);
                      $in2=  mysql_query("select * from login where userid = '$_SESSION[user]'");
                      $a2=  mysql_fetch_array($in2);
                  ?>
                  Registration Time :
                  <div style="float: right;margin-right: 20px;">
                        <?php
                            echo "last login date & time : ".$a1[1]."&nbsp;&nbsp;".$a1[2];
                        ?>
              </div>    
              <?php
                echo $a2[3];
              ?>
                  &nbsp;&nbsp;
              <?php
                echo $a2[4];
              ?>
              </div>
          </div>