<?php
    require_once 'conn.php';
?>

<div class="navigation">


  		    	<a class="toggleMenu" href="#">Menu</a>
					<ul class="nav">
						<li>
                                                    <a href="index.php">Home</a>
						</li>
                                                <li>
							<a href="auction.php#auction">Auction</a>
						</li>
                                                <li>
                                                    <a href="#">adpost</a>
                                                </li>
                                                <li>
							<a href="feedback.php">Feedback</a>
						</li>
                                                <li>
							<a href="aboutus.php">About Us</a>							
						</li>
                                                <li>
							<a href="contact.php">Contact Us</a>
                                                </li>
                                                <li>
                                                 
                                                </li>
					</ul>
					 <span class="left-ribbon"> </span> 
      				 <span class="right-ribbon"> </span>    
  		    </div>
   