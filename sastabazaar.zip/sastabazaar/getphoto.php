


<img id="mjimg" class="photo" src="<?php echo $_REQUEST[kyo]; ?>" /><br><br>