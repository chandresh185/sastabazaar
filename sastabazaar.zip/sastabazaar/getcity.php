<?php
    require_once 'conn.php';
    $a=mysql_query("select * from city where stateid=$_REQUEST[id] ");
    echo "<option>--Select--</option>";
        while($row = mysql_fetch_array($a))
	{
 ?>
                <option value="<?php echo $row[1]; ?>"><?php echo $row[2]; ?></option>
<?php
	}
?>