<?php
    require_once 'conn.php';
    if(isset($_REQUEST[submit]))
    {
       $y=date(y);
       $m=date(m);
       $d=date(d);
       $h=date(h);
       $i=date(i);
       $s=date(s);
       $dt=$y."/".$m."/".$d;
       $ti=$h.":".$i.":".$s;
       $date=$_REQUEST[year]."/".$_REQUEST[month]."/".$_REQUEST[day];
       $terms="yes";
       $c=mysql_query("select * from country where countryid=$_REQUEST[country]");
       while($cc=  mysql_fetch_array($c))
       {
           $country=$cc[1];
       }
       $s=mysql_query("select * from state where stateid=$_REQUEST[state]");
       while($st=  mysql_fetch_array($s))
       {
           $state=$st[2];
       }
       $ci=mysql_query("select * from city where cityid=$_REQUEST[city]");
       while($cci=  mysql_fetch_array($ci))
       {
           $city=$cci[2];
       }
       if($_REQUEST[name]=='')
       {
           $ename=1;
       }
       if($_REQUEST[address]=='')
       {
           $eaddress=1;
       }
       if($_REQUEST[day]=='--Select--' || $_REQUEST[month]=='--Select--' || $_REQUEST[year]=='--Select--')
       {
           $dmy=1;
       }
       if($_REQUEST[email]=='')
       {
           $eemail=1;
       }
       if($_REQUEST[country]=='--Select--')
       {
           $ecountry=1;
       }
       if($_REQUEST[state]=='--Select--')
       {
           $estate=1;
       }
       if($_REQUEST[city]=='--Select--')
       {
           $ecity=1;
       }
       if($_REQUEST[userid]=='')
       {
           $euserid=1;
       }
       /*password*/
       if($_REQUEST[pass]=='')
       {
           $epass=1;
       }
       if($_REQUEST[pass]!=$_REQUEST[repass])
       {
           $repass=1;
       }
       $pat4='/^......../';
       if(!preg_match($pat4, $_REQUEST[pass]))
       {
           $epasslenth=1;
       }
       $pwd=$_REQUEST[pass];
        $pass1=$_REQUEST[repass];
        $pass2=strlen($pass1);
       
        
        for($i=0;$i<$pass2;$i++)
        {
            $abc=substr($pass1,$i);
            
            $ch=ord($abc);
       
            if($ch>=65 && $ch<=90)
            {
                $cap++;
            }
            elseif($ch>=97 && $ch<=122)
            {
                $sml++;
             
            }
            elseif($ch>=48 && $ch<=57)
            {
                $dg++;
          
            }
            else
            {
                $sp++;
          
            } 
        }
        if($cap==0 || $sml==0 || $dg==0 || $sp==0)
        {
           $epasscheck=1;
        }
        /*password end*/
       if($_REQUEST[que]=='--Select--')
       {
           $eque=1;
       }
       if($_REQUEST[ans]=='')
       {
           $eans=1;
       }
       if($_REQUEST[gender]=='--Select--')
       {
           $egender=1;
       }
       $pat1='/^[a-zA-Z ]+$/';
       $pat2='/^[0-9]+$/';
       $pat3='/^..........$/';
       if(!preg_match($pat1, $_REQUEST[name]))
       {
           $ename1=1;
       }
       if(!preg_match($pat2, $_REQUEST[mobile]) || !preg_match($pat3, $_REQUEST[mobile]) || $_REQUEST[mobile]=="")
       {
           $emobile=1;
       }
       
       /*file uploading*/
       
       $fname=$_FILES[userimg][name];
       $types=substr($_FILES[userimg][type],6);
       $siz=$_FILES[userimg][size];
       $siz=$siz/1024;
       $siz=$siz/1024;
       $ex=".".substr($_FILES[userimg][type],6);
       if($siz<=5)
       {
           if($ex==".jpg" || $ex==".jpeg")
           {
               $nwname=$_REQUEST[userid].$ex;
               $path1="profile/".$nwname;
               $path2=dirname(__FILE__)."/profile/".$nwname;
           }
           else
           {
               $er1=1;
           }
       }
       else
       {
           $er2=1;
       }
       
       /*file uploading end*/
       
       /*capcha*/
       
       if(strlen($_REQUEST[capcha])!=5)
        {
            $cap1=1;
        }
        else
        {
            for($i=0;$i<=strlen($_REQUEST[capcha])-1;$i++)
            {
                if($i==0)
                {
                    $e1=substr($_REQUEST[capcha],$i,1);
                }
                if($i==1)
                {
                    $e2=substr($_REQUEST[capcha],$i,1);
                }
                if($i==2 || $i==3)
                {
                    $e3=$e3.substr($_REQUEST[capcha],$i,1);
                }
                if($i==4)
                {
                    $e4=substr($_REQUEST[capcha],$i,1);
                }
            }
            if($e1==$_SESSION[ek] && $e2==$_SESSION[be] && $e3==$_SESSION[chothi] && $e4==$_SESSION[tran])
            {
                
            }
            else
            {
                $cap1=1;
            }
           
        } 
       
       
       
       
       /*end capcha*/
       
       if($cap1!=1 && $name!=1 && $address!=1 && $gender!=1 && $email!=1 && $mobile!=1 && $country!=1 && $state!=1 && $city!=1 && $dob!=1 && $userid!=1 && $pass!=1 && $que!=1 && $ans!=1 && $er1!=1 && $er2!=1)
       {   
           
            $in=mysql_query("insert into registration values('$_REQUEST[choice]','$_REQUEST[name]',
                    '$_REQUEST[address]','$_REQUEST[gender]',
                    '$_REQUEST[email]','$_REQUEST[mobile]','$country',
                    '$state','$city','$date','$_REQUEST[userid]','$path1',
                    '$_REQUEST[pass]','$_REQUEST[que]','$_REQUEST[ans]','$terms')");
           
            if($_REQUEST[choice]=="dealer")
            {
                $tp=1;
            }
            if($_REQUEST[choice]=="buyer")
            {
                $tp=2;
            }
            if($_REQUEST[choice]=="seller")
            {
                $tp=3;
            }
            $inn=mysql_query("insert into login values('$_REQUEST[userid]','$_REQUEST[pass]','$tp','$dt','$ti')");
            $inn=mysql_query("insert into logintime values('$_REQUEST[userid]','$dt','$ti')");
            //echo $in;
            //echo $inn;
            move_uploaded_file($_FILES[userimg][tmp_name], $path2);
            
            $send=1;
            $_SESSION[timee]=$ti;
            $_SESSION[datee]=$dt;
            $_SESSION[type]=$tp;
            $_SESSION[user]=$_REQUEST[userid];
            
            if($_REQUEST[choice]=="dealer")
            {
                //echo "hiii";
                header('location:dealerhome.php');
            }
            if($_REQUEST[choice]=="buyer")
            {
                //echo "hiii";
                header('location:buyerhome.php');
            }
            if($_REQUEST[choice]=="seller")
            {
                //echo "hiiii";
                header('location:sellerhome.php');
            }
       
        }
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="ref();">
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
    </div>
</div>
   <div class="main">
 	<div class="wrap">
            <div class="preview-page">       
                <div class="contact-form">
		<h3>registration</h3>
                <div class="regi">    
                    <form action="" method="post" enctype="multipart/form-data" name="dealerregi">
                    <table>
                        <tr>
                            <td colspan="3">
                            <?php
                                if($send==1)
				{
                                    echo "insert Successed....!";
				}
                            ?> 	
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <div class="head">
                                    <h3>personal information</h3>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <br>
                                </td>
                        </tr>
                        <tr>
                            <td>user type :</td>
                            <td colspan="2">
                                <input type="radio" name="choice" value="dealer" checked="true" />&nbsp;dealer&nbsp;&nbsp;
                                <input type="radio" name="choice" value="buyer"/>&nbsp;buyer&nbsp;&nbsp; 
                                <input type="radio" name="choice" value="seller"/>&nbsp;seller&nbsp;&nbsp;
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <br>
                            </td>
                        </tr>
                        <tr>
                            <td>name :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="name" type="text" placeholder="Enter Name"/>
                            </td>
                            <td>
                                <?php
                                    if($ename==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                    else
                                    {
                                        if($ename1==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>address :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td colspan="2">
                                <textarea name="address" placeholder="Enter Address" style="vertical-align: top;"></textarea>
                                <?php
                                    if($eaddress==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>gender :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="gender">
                                    <option>--Select--</option>
                                    <option>male</option>
                                    <option>female</option>
                                </select>
                                <?php
                                    if($egender==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>email :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="email" type="email" placeholder="Enter Email"/>
                            </td>
                            <td>
                                <?php
                                    if($eemail==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>contact :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="mobile" type="text" placeholder="Enter Contact" maxlength="10"/>
                                
                            </td>
                            <td>
                                <?php
                                    if($emobile==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>country :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="country" onchange="setstate(this.value)">
                                    <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from country");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[0]?>"><?php echo $row[1]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                                <?php
                                    if($ecountry==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>state :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="state" id="state" onchange="setcity(this.value)">
                                   
                                </select>
                                <?php
                                    if($estate==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>city :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>    
                                <select class="select" name="city" id="city">
                                    
                                </select>
                                <?php
                                    if($ecity==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>date of birth :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="select" name="day">
                                    <option>--Select--</option>
                                    <?php
                                        for($i=1;$i<=31;$i++)
                                        {
                                    ?>
                                    <option><?php echo "$i"; ?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                                &nbsp;&nbsp;&nbsp;&nbsp;   
                                <select class="select" name="month">
                                    <option>--Select--</option>
                                    <?php
                                        for($i=1;$i<=12;$i++)
                                        {
                                    ?>
                                    <option><?php echo "$i"; ?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <select class="select" name="year">
                                    <option>--Select--</option>
                                    <?php                    
                                        for($i=1950;$i<=2000;$i++)
                                        {
                                    ?>
                                    <option><?php echo "$i"; ?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                                <?php
                                    if($dmy==1)
                                    {
                                       echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <div class="head">
                                    <h3>login information</h3>
                                </div>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>user ID:&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="userid" type="text" placeholder="Enter user id"/>
                                
                            </td>
                            <td>
                                <?php
                                    if($euserid==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="file" name="userimg"/>
                            </td>
                            <td>
                                <?php
                                    if($er1==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                    elseif($er2==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>password :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="pass" type="password" placeholder="Enter Password"/>
                                
                            </td>
                            <td>
                                <?php
                                    if($epass==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                    else
                                    {
                                        if($epasslenth==1 || $epasscheck==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                        
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>re-password :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="repass" type="password" placeholder="Enter Password"/>
                                
                            </td>
                            <td>
                                <?php
                                    if($erepass==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                    else
                                    {
                                        if($erepass1==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td colspan="2">
                                <div class="head">
                                    <h3>security information</h3>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>security question :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <select class="que" name="que">
                                    <option>--Select--</option>
                                    <option>Your Favourite Sport?</option>
                                    <option>Your Favourite Car?</option>
                                    <option>Your Favourite Actor?</option>
                                    <option>Your Favourite Actress?</option>
                                </select>
                                <?php
                                    if($eque==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                             </td>    
                        </tr>
                        <tr>
                            <td>security answer :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="ans" type="text" placeholder="Enter Answer"/>
                                
                             </td>
                             <td>
                                <?php
                                    if($eans==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?> 
                             </td>    
                        </tr>
                        <tr>
                            <td colspan="2">
                                <br>
                            </td>
                        </tr>    
                        <tr>
                            <td  colspan="2">
                                <div id="capid" style="padding: 1px;padding-left: 20px;width: 150px;border: black solid 1px;background-image: url(images/capcha.jpg);opacity:0.5;text-transform: none;">
                                    
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <div style="float: left;text-transform: none;">
                                    <input type="text" name="capcha" placeholder="Type hear what you see.."  style="width:160px;">
                                    <?php
                                        if($cap1==1)
                                        {
                                            echo "<font color=red>*</font>";
                                        }
                                    ?>
                                </div>
                                <div style="margin-top: -60px;margin-left: 190px;">
                                    <img src="images/update2.png" style="margin-top: -200px;width: 25px;" onclick="ref();"/>
                                </div>    
                                
                                
                            </td>    
                        </tr>    
                        <tr>
                            <td colspan="2">
                                <div class="head">
                                    <h3>terms information</h3>
                                </div>
                            </td>
                        </tr>
                        
                        <tr>
                            <td colspan="2"><br/>
                            <input type="checkbox" name="term" checked="true" disabled="true">
                                                    I Agree With Your Term & Condition
                        </tr>
                        
                    </table>    
                        <div>
                                <button type="submit" class="feedbackbutton" name="submit">registration</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
			</div>
                    <font style="font-size: 10px;color: red;">note : * blank | ^ invalid </font>
                  </form>
                  </div>
                </div>
            </div>		
         </div> 
    </div>
   <?php
            require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script> 
</body>
</html>

