<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'header.php';
        ?>
  	<?php
            require_once 'menu.php';
        ?>
    </div>
</div>
<div class="about1">
    <div class="about2" style="font-size: 15px;">
        <h3><b style="color: #e44f2b;font-size: 18px;">A</b>bout <b style="color: #e44f2b;font-size: 18px;">U</b>s</h3><br>
        <div class="aboutus">
            <div class="link">
                <font>sastabazaar link</font><br><br>
            </div>
            <?php
                require_once 'spage.php';
            ?>
        </div>
        <div class="about">
            <br>
                <img src="images/aboutusbanner.jpg" />
                <font>
                <br><br><br>
                <p>
                    SastaBazaar is India’s no.1 online classifieds platform, 
                    a placewhere people can connect with each other to buy or sell goods and services. 
                    Launched in 2008 with the vision for buyers and sellers to “meet online, transact offline”, 
                    today we have over 4.2 million listings and have generated over 150 million replies.
                </p></br>
                <p>
                    Headquartered in Mumbai, 
                    SastaBazaar operates from 940 cities across India and is accessed by more than 30 million unique users and 26 million brand new customers per month. 
                    We now have over 13 categories and 170 sub-categories,
                    with the most popular being mobile phones and electronics, real estate, cars and bikes.
                </p></br>
                <p>
                    At SastaBazaar, we have created an online community which is simple and secure. 
                    We are constantly innovating so that users can buy and sell in the easiest and most convenient way possible. 
                    We recognized that getting a fair price could be a hurdle for our customers,and 
                    we developed a Maximum Selling Price (MSP) calculator to help users estimate a reasonable price range. 
                    We also pioneered the Missed Call service in India, 
                    enabling first time or non internet users in India to give us a missed call so that we can help them post an ad. 
                    This way we aim to make people ‘SastaBazaar’ users,
                    perhaps even before they are internet users.

                </p></br>
                <p>
                    Our efforts are being recognized. 
                    In BAV® 2014 (a Brand Asset Valuator by Rediffusion-Y&R), 
                    SastaBazaar was the only classifieds platform to be featured in the list of top ten 
                    ‘Best E-commerce Brands in India Amongst Youth’.
                   
                </p></br>    
                <p>
                    We have been fortunate to have some of the world’s best renowned investment partners with us on our 
                    journey: Kinnevik,Matrix Partners India, Omidyar Network, Norwest Venture Partners, 
                    Nokia Growth Partners, Warburg Pincus and investments by eBay Inc. 
                    as well.

                </p></br></br>
                <p>
                    Happy trading everyone!
                </p>
                </font>
        </div>
    </div>
</div>    
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

