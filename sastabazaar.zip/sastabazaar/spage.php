<ul>
                    <li><a href="aboutus.php">about us</a></li><br>     
                    <li><a href="privacypolicy.php#lpolicy">listing policy</a></li><br>
                    <li><a href="privacypolicy.php#ppolicy">privacy policy</a></li><br>
                    <li><a href="privacypolicy.php#terms">terms of use</a></li><br>
                    <li><a href="sitemap.php">site map</a></li>
            </ul>