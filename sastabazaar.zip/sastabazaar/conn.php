<?php
    session_start();
    ob_start();
    $con=mysql_connect("localhost","root","hello");
    if(!$con)
    {
        die("not connected");
    }
    mysql_select_db("sastabazzar",$con);
?>



