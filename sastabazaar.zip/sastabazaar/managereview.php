<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(reviewid) from review");
    $chhe=mysql_fetch_array($ketla);
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="rev('<?php echo $_REQUEST[base]; ?>');">
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
          <div class="managecountry" id="review">
              <h3>manage review
              <div style="float: right;margin-right: 20px;">
                        <?php
                            echo "total review are : ".$chhe[0];
                        ?>
              </div>
              </h3></br>
              <div class="fmain">
                    <input type="text" name="search" onkeyup="search1(this.value,'review');" placeholder="Search Here" />
                    <a href="delete.php?all=review"><img src="images/delete2.png" title="delete all records" width="30px" style="vertical-align: middle;"/></a>
              </div>
              <div class="cdis" id="view">
              <form method="post" action="">
                  
              </form>  
              </div> 
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>