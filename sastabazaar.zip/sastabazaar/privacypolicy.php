<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'header.php';
        ?>
  	<?php
            require_once 'menu.php';
        ?>
    </div>
</div>
<div class="about1">
    <div class="about2">
        <h3>policy</h3><br>
        <div class="aboutus">
            <div class="link">
                <font>sastabazaar link</font><br><br>
            </div>
            <?php
                require_once 'spage.php';
            ?>
        </div>
        <div class="about">
            <br>
                <font>
                <p id="lpolicy">
                    <b>listing policy</b><br><br>
                    <div class="line2"></div>
                    <br><b>1. Prohibited Items Policy.</b><br><br> 
                    <b>a. We specifically prohibit any listing or posting of classifieds or information in relation to the following items:</b>
                    <br><br>1. Alcoholic Beverages, Liquor, tobacco products, drugs, psychotropic substances, narcotics, intoxicants of any description, medicines, palliative/curative substances nor shall you provide link directly or indirectly to or include descriptions of items, goods or services that are prohibited under any applicable law for the time being in force including but not limited to the Drugs and Cosmetics Act, 1940, the Drugs And Magic Remedies (Objectionable Advertisements) Act, 1954 Narcotic Drug and Prohibited Substances Act and the Indian Penal Code, 1860.

                    <br><br>2. Living, dead person and/or the whole or any part of any human which has been kept or preserved by any means whether artificial or natural including any blood, bodily fluids and/ or body parts

                    <br><br>3. Prostitution or any other service in the nature there of that purports to violate the provisions of Immoral Act or Indecent representation of women which violates the contemporary standards of morality and decency in Indian society.

                    <br><br>4. Religious items, including books, artifacts, etc. or any information, description of any such item that is likely to affect the religious sentiments of any person or group

                    <br><br>5. Mature Audiences Policy includes films which do not have a certificate for public exhibition issued by the Central Board of Film Certification and or described and depict or otherwise deal with matters which are revolting or repulsive and or tend to deprave a persons mind in such a way that they tend to offend against the standards of morality, decency and propriety generally accepted by reasonable adults    
                    <br><br><b>b. Without prejudice to the generality of the above, SastaBazaar does not permit posting or listing of classifieds in relation to the following:</b>

                    <br><br>1. "Securities" within the meaning of the Securities Contract Regulation Act, 1956, including shares, bonds, debentures, etc. and/or any other financial instruments/assets of any description.

                    <br><br>2. Living, dead creatures and/or the whole or any part of any animal which has been kept or preserved by any means whether artificial or natural including rugs, skins, specimens of animals, antlers, horns, hair, feathers, nails, teeth, musk, eggs, nests, other animal products of any description the sale and purchase of which is prevented or restricted in any manner by applicable laws (including those prohibited under The Wildlife Protection Act, 1972 and/ or The Environment Protection Act, 1986)
                    <br><br><b>c. Your listing, information, Advertisement</b>

                    <br><br>1. Shall not be defamatory, trade libelous, unlawfully threatening or unlawfully harassing. Further shall not be fraudulent, misrepresenting, misleading or pertain to the sale of any illegal, counterfeit, stolen goods and or services which do not belong to you or you do not have the authority for. Further still shall not infringe any intellectual property, trade secret, or other proprietary rights or rights of publicity or privacy of any third party.

                    <br><br>2. Shall not contain any viruses, Trojan horses, worms, time bombs, cancel bots, easter eggs or other computer programming routines that may damage, detrimentally interfere with, surreptitiously intercept or expropriate any system, data or personal information.

                    <br><br>3. Shall not be allowed to libel anyone or include hate, derogatory, slanderous speech directed at individuals or groups. You should not advocate violence against other users or individuals or groups.
                    <br><br><b id="ppolicy">privacy policy</b><br><br>   
                    <div class="line2"></div>    
                    <br><b>Collection:</b><br><br> Information posted on SastaBazaar is obviously publicly available. Our servers are located in Mumbai, India. Therefore, if you choose to provide us with personal information, you are consenting to the transfer and storage of that information on our servers. We collect and store the following personal information: 
                    <br>• email address, physical contact information, and (depending on the service used) sometimes financial information; 
                    <br>• computer sign-on data, statistics on page views, traffic to and from SastaBazaar and Ad data (all through cookies – you can take steps to disable the cookies on your browser although this is likely to affect your ability to use the site); 
                    <br>• other information, including users IP address and standard web log information.
                    <br><br><b>Use:</b><br><br> We use users' personal information to: 
                    <br>• provide our services. 
                    <br>• resolve disputes, collect fees, and troubleshoot problems. 
                    <br>• encourage safe trading and enforce our policies. 
                    <br>• customize users' experience, measure interest in our services, and inform users about services and updates; 
                    <br>• communicate marketing and promotional offers to you.
                    <br><br><b>Using Information from SastaBazaar:</b><br><br>You may use personal information gathered from SastaBazaar only to follow up with another user about a specific posting, not to send spam/ phising or collect personal information from someone who hasn't agreed to that.
                    <br><br><b>General:</b><br><br> We may update, upgrade, modify (partially &/or fully) this policy at any time, with updates taking effect when you next post or after 30 days, whichever is sooner. If we or our corporate affiliates are involved in a merger or acquisition, we may share personal information with another company, but this policy will continue to apply. Send questions about this policy toprivacy@SastaBazaar.com.    
                    <br><br><b id="terms">terms of use</b><br><br>
                    <div class="line2"></div>
                    <p>
                        <br><b>1. Using SastaBazaar.</b><br><br>
You                 agree and understand that www.SastaBazaar.com is an internet enabled electronic platform that facilitates communication for the purposes of advertising and distributing information pertaining to goods and/ or services. You further agree and understand that we do not endorse, market or promote any of the listings, postings or information, nor do we at any point in time come into possession of or engage in the distribution of any of the goods and/ or services, you have posted, listed or provided information about on our site. While interacting with other users on our site, with respect to any listing, posting or information we strongly encourage you to exercise reasonable diligence as you would in traditional off line channels and practice judgment and common sense before committing to or complete intended sale, purchase of any goods or services or exchange of information. We recommend that you read our Safety tips before doing any activity on our site.

                    While making use of SastaBazaar classifieds and other services such as the discussion forums, comments and feedback and other services interalia, you will post in the appropriate category or area and you agree that your use of the Site shall be strictly governed by this AUP including the policy for listing of your Classified which shall not violate the prohibited and restricted items policy (herein after referred to as the Listing Policy.) (Listing Policy) The listing policy shall be read as part of this AUP and is incorporated in this AUP by way of reference:
                </p>
                <p>
                    <br><b>2. Eligibility</b><br><br>
                    Use of www.SastaBazaar.com,, either by registration or by any other means, is available only to persons, who are Citizens of the Republic of India, who are 18 yrs of age and above and persons who can enter into a legally binding contract, and or are not barred by any law for the time being in force. If you access SastaBazaar, either by registration on the Site or by any other means, not as an individual but on behalf of a legal entity, you represent that you are fully authorized to do so and the listing, posting or information placed on the site on behalf of the legal entity is your responsibility and you agree to be accountable for the same to other users of the Site.
                    <br><br><b>3. Abuse of SastaBazaar</b><br><br>
                    You agree to inform us if you come across any listing or posting that is offensive or violates our listing policy or infringes any intellectual property rights by clicking on the following link support@SastaBazaar.com to enable us to keep the site working efficiently and in a safe manner. We reserve the right to take down any posting, listing or information and or limit or terminate our services and further take all reasonable technical and legal steps to prevent the misuse of the Site in keeping with the letter and spirit of this AUP and the listing policy. In the event you encounter any problems with the use of our site or services you are requested to report the problem by clicking on this link support@SastaBazaar.com
                    <br><br><b>4. Violations by User</b><br><br>
                    You agree that in the event your listing, posting or your information violates any provision of this AUP or the listing policy, we shall have the right to terminate and or suspend your membership of the Site and refuse to provide you or any person acting on your behalf, access to the Site.
                </p>
                </font>
        </div>
    </div>
</div>    
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

