<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="jmilt1(5,'nathi','load');">
    <script>
        $(".document").ready(function(){
            $(".mfil2").click(function(){
                $(".mfilter").toggle(1000);  
            });
            
            $(".sfil2").click(function(){
                $(".sfilter").toggle(1000);  
            });
            $(".cfil2").click(function(){
                $(".cfilter").toggle(1000);  
            });
            
            $(".pfil2").click(function(){
                $(".pfilter").toggle(1000);  
            });
        });
        
    </script>
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main">
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap" id="job">
		          	   <h3>Latest Products</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
			                   <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
    	  <div class="content_bottom">
                <div class="content-bottom-left">
                    <div class="mainfil">
                        <p><b style="color: #23272a;font-size: 18px;">f</b>iltering <b style="color: #23272a;font-size: 18px;">b</b>y</p>
                        <div class="fil1">
                            <div class="mfil2">
                                <b style="font-size: 12px;cursor: pointer;">&xdtri;</b><font>&nbsp;&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 15px;">m</b>aincategories</font>
                            </div>
                            <div class="fil3">
                                <font><b>r</b>eset</font>
                            </div>
                            <div style="clear: both;">
                                 
                            </div>
                        </div>
                        <div class="mfilter">
                            <table>
                                <?php
                                    $mcate=  mysql_query("select * from maincategories");
                                    while($mcate1=mysql_fetch_array($mcate))
                                    {
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="term" value="<?php echo $mcate1[0]; ?>" onclick="jmilt1('nathi',this.value,'maincate');"/></td>
                                    <td><?php echo $mcate1[1]; ?></td>
                                </tr>
                                <?php
                                    }
                                ?>
                            </table>
                        </div>
                        <div class="fil1">
                            <div class="sfil2">
                                <b style="font-size: 12px;cursor: pointer;">&xdtri;</b><font>&nbsp;&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 15px;">s</b>ubcategories</font>
                            </div>
                            <div class="fil3">
                                <font><b>r</b>eset</font>
                            </div>
                            <div style="clear: both;">
                                 
                            </div>
                        </div>
                        <div class="sfilter">
                            <table>
                                <?php
                                    $mcate=  mysql_query("select * from subcategories");
                                    while($mcate1=mysql_fetch_array($mcate))
                                    {
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="subcat" value="<?php echo $mcate1[1]; ?>" onclick="jmilt1('nathi',this.value,'subcate');"/></td>
                                    <td><?php echo $mcate1[2]; ?></td>
                                </tr>
                                <?php
                                    }
                                ?>
                            </table>
                        </div>
                        <div class="fil1">
                            <div class="cfil2">
                                <b style="font-size: 12px;cursor: pointer;">&xdtri;</b><font>&nbsp;&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 15px;">c</b>ompany</font>
                            </div>
                            <div class="fil3">
                                <font><b>r</b>eset</font>
                            </div>
                            <div style="clear: both;">
                                 
                            </div>
                        </div>
                        <div class="cfilter">
                            <table>
                                <?php
                                    $mcate=  mysql_query("select * from company");
                                    while($mcate1=mysql_fetch_array($mcate))
                                    {
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="com" value="<?php echo $mcate1[1]; ?>" onclick="jmilt1('nathi',this.value,'company');"/></td>
                                    <td><?php echo $mcate1[2]; ?></td>
                                </tr>
                                <?php
                                    }
                                ?>
                            </table>
                        </div>
                        <div class="fil1">
                            <div class="pfil2">
                                <b style="font-size: 12px;cursor: pointer;">&xdtri;</b><font>&nbsp;&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 15px;">p</b>rice</font>
                            </div>
                            <div class="fil3">
                                <font><b>r</b>eset</font>
                            </div>
                            <div style="clear: both;">
                                 
                            </div>
                        </div>
                        <div class="pfilter">
                            <table>
                                <tr>
                                    <td><input type="checkbox" name="p1" onclick="jmilt1('nathi','0','price');"/></td>
                                    <td>0 to 1000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p2" onclick="jmilt1('nathi','1000','price');" /></td>
                                    <td>1000 to 2000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p3" onclick="jmilt1('nathi','2000','price');"/></td>
                                    <td>2000 to 3000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p4" onclick="jmilt1('nathi','3000','price');"/></td>
                                    <td>3000 to 4000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p5" onclick="jmilt1('nathi','4000','price');"/></td>
                                    <td>4000 to 5000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p6" onclick="jmilt1('nathi','5000','price');"/></td>
                                    <td>5000 to 6000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p7" onclick="jmilt1('nathi','6000','price');"/></td>
                                    <td>6000 to 7000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p8" onclick="jmilt1('nathi','7000','price');"/></td>
                                    <td>7000 to 8000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','8000','price');"/></td>
                                    <td>8000 to 9000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','9000','price');"/></td>
                                    <td>9000 to 10000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','10000','price');"/></td>
                                    <td>10000 to 50000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','50000','price');"/></td>
                                    <td>50000 to 100000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','100000','price');"/></td>
                                    <td>100000 to 500000</td>
                                </tr>
                                <tr>
                                    <td><input type="checkbox" name="p9" onclick="jmilt1('nathi','500000','price');"/></td>
                                    <td>500000 to 1000000</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
    	    	<div class="content-bottom-right" style="font-size: 15px;">
                    <h3>
                        <b style="color: #e44f2b;font-size: 18px;">L</b>atest <b style="color: #e44f2b;font-size: 18px;">P</b>roducts
                    </h3>
                    <div class="mainl"><font>World Secound Hand Product Of SastaBazaar</font>
                        <div class="mml">
                    <div style="float: left;">
                        Best Dealer
                        <select name="dealer" onchange="jmilt1(5,this.value);" style="padding: 5px;margin: 5px;background: white;border: none;">
                                    <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from registration where usertype='dealer'");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[1]?>"><?php echo $row[1];?></option>
                                    <?php
                                        }
                                    ?>           
                         </select>
                    </div>
                            <div class="lv">
                                <center><img src="images/editor_grid_view_block_-32.png" title="List View" style="cursor: pointer;" width="20px" onclick="jmilt1(5,'nathi','load');"/></center>
                                
                            </div>
                            <div class="dv">
                                <center><img src="images/feed-32.png" width="20px" title="Detail View" style="cursor: pointer;" onclick="jmilt(5,'nathi');"/></center>
                            </div>    
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                    <div style="padding-top: 8px;font-size: 10px;color: #e44f2b;">Total Product Out Of</div>
                      <div class="container" id="jmultiview1">
                          
                      </div>
                </div>
		      <div class="clear"></div>
		</div>
         </div>
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

