<?php
    require_once 'conn.php';
?>
<center>
                                    <div class="cap1">
                                        
                                        <?php
                                            $ek=rand(0,9);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo $ek;$_SESSION[ek]=$ek; ?></font>
                                    </div>
                                    <div class="cap2">
                                        <?php
                                            $biju=rand(65,90);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo chr($biju);$_SESSION[be]=chr($biju); ?></font>
                                    </div>
                                    <div class="cap3">
                                        <?php
                                            $char=rand(11,70);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo $char;$_SESSION[chothi]=$char; ?></font>
                                    </div>

                                    <div class="cap4">
                                        <?php
                                            $tran=rand(97,122);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo chr($tran);$_SESSION[tran]=chr($tran); ?></font>
                                    </div>
                                    
                                    </center>
              