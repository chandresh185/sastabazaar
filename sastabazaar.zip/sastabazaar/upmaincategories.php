<?php
    require_once 'conn.php';
    $data=mysql_query("select maincatename from maincategories where maincateid='$_REQUEST[id]'");
    $row=mysql_fetch_array($data);
        if(isset($_REQUEST[send]))
        {
            if($_REQUEST[name]=="")
            {
                $ename=1;   
            }
            $pname='/^[a-zA-Z ]+$/';
            if(!preg_match($pname, $_REQUEST[name]))
            {
                $ename1=1;
            }
            $g=mysql_query("select * from maincategories");
            while($gg=mysql_fetch_array($g))
            {
                if(stristr($gg[1],$_REQUEST[name]) && strlen($gg[1])==strlen($_REQUEST[name]))
                {
                    $ename2=1;
                    
                    break;
                }
            }
            if($ename!=1 && $ename1!=1  && $ename2!=1)
           {
               $in=mysql_query("update maincategories set maincatename='$_REQUEST[name]' where maincateid='$_REQUEST[id]' ");
               header('location:managemaincategories.php?base=1#maincate');
           }
        }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
    <div class="admin">	
          <?php
                  require_once 'adminmenu.php';
          ?>
        <div class="managecountry">
                    <h3>update maincategories</h3></br></br>	
                    <form method="post" action="">
                                  <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                  ?>
                                  <input type="text" name="name" placeholder="Enter New Categories" value="<?php echo $row[0]; ?>">
                                    <?php
                                        if($ename==1)
                                        {
                                            echo "<font color=red size=3px>*</font>";
                                        }
                                        else
                                        {
                                            if($ename1==1)
                                            {
                                                echo "<font color=red size=3px>*</font>";
                                            }
                                            else
                                            {
                                                if($ename2==1)
                                                {
                                                    echo "<font color=red size=3px>Categories Already Exist</font>";
                                                }  
                                            }
                                        }                                                                    
                                     ?>
				<div>
                                    <button type="submit" value="Submit"  class="feedbackbutton" name="send">Submit</button>
                                    <button type="reset" class="feedbackbutton" name="clear">Clear</button>
                                    <div class="clear"></div>
                                </div>
			</form>
            </div>
        </div>
    </div>     
   <?php
        require_once 'footer.php';
   ?>