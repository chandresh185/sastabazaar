<!DOCTYPE HTML>
<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=2)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    require_once 'head.php';
?>
<body>
        <?php
            require_once 'updatebcover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'bcover.php';
          ?>
          <div class="adminright" id="buyerhome">
             <div class="ht">
                  w&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;l&nbsp;&nbsp;&nbsp;&nbsp;c&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b&nbsp;&nbsp;&nbsp;&nbsp;u&nbsp;&nbsp;&nbsp;&nbsp;y&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;r&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e 
              </div><br>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          profile
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="buyerprofile.php#buyerprofile"><img src="images/contact.png" title="profile" width="140px"/></a>
                      </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          edit profile
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="buyereditprofile.php#editprofile"><img src="images/Contacts.png" title="edit profile" width="140px"/></a>
                      </div>    
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          change password
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="buyerchangepassword.php#cpass"><img src="images/feedback1.png" title="change password" width="140px"/></a>
                      </div>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total bill
                      </div>
                      <div class="box">
                          <a href="bill.php#bill"><img src="images/bill.png" title="bill" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(billid) from bill where userid='$_SESSION[user]'");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                            echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total wish
                      </div>
                      <div class="box" style="height: 140px;">
                          <a href="managewishlist#wish"><img src="images/wish.png" title="wish" width="120px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(wishlistid) from wishlist where userid='$_SESSION[user]'");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                            echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total cart
                      </div>
                      <div class="box" style="height: 140px;">
                          <a href="managecart.php#cart"><img src="images/cart.png" title="cart" width="120px" style="margin-top: 10px;"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(cartid) from cart where userid='$_SESSION[user]'");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                            echo $a[0];
                      ?>
                  </div>
              </div>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>