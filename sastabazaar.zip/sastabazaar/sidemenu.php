<div class="wrap">
    <div class="content-bottom-left">
        <div class="categories" style="font-size: 15px;">
            <ul>
                <h3><b style="color: #23272a;font-size: 18px;">B</b>rowse <b style="color: #23272a;font-size: 18px;">A</b>ll <b style="color: #23272a;font-size: 18px;">C</b>ategories</h3>
                <li><a href="product.php#mobile"><img src="images/footer/mobile.png" title="mobile" width="8px;"/>&nbsp;&nbsp;mobile</a></li>
		<li><a href="eproduct.php#elec"><img src="images/footer/computer.png" title="electronics & computer" width="10px;"/>&nbsp;&nbsp;electronics & computers</a></li>
		<li><a href="vproduct.php#vehicle"><img src="images/footer/car.png" title="car" width="10px;"/>&nbsp;&nbsp;vehicles</a></li>
		<li><a href="hproduct.php#home"><img src="images/footer/home.png" title="home" width="10px;"/>&nbsp;&nbsp;home & furniture</a></li>
		<li><a href="bproduct.php#book"><img src="images/footer/book.png" title="book & cds" width="10px;"/>&nbsp;&nbsp;books & cds</a></li>
		<li><a href="fproduct.php#fation"><img src="images/footer/bag.png" title="mobile" width="10px;"/>&nbsp;&nbsp;fashion & beauty </a></li>
		<li><a href="spproduct.php#sport"><img src="images/footer/sport.png" title="sport" width="10px;"/>&nbsp;&nbsp;sports & health</a></li>
		<li><a href="jproduct.php#job"><img src="images/footer/job.png" title="job" width="10px;"/>&nbsp;&nbsp;jobs</a></li>
		<li><a href="rproduct.php#real"><img src="images/footer/realestate.png" title="realestate" width="10px;"/>&nbsp;&nbsp;real estate</a></li>
                <li><a href="pproduct.php#pets"><img src="images/footer/pet.png" title="pet" width="10px;"/>&nbsp;&nbsp;pets</a></li>
                <li><a href="kproduct.php#kids"><img src="images/footer/kids.png" title="kids" width="10px;"/>&nbsp;&nbsp;kids & baby</a></li>
                <li><a href="auction.php#auction"><img src="images/footer/Cultures-Thor-Hammer-icon.png" title="auction" width="10px;"/>&nbsp;&nbsp;auction</a></li>
            </ul>
	</div>		
    </div>
   