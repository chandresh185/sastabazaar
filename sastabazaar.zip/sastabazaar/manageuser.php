<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(usertype) from registration");
    $chhe=mysql_fetch_array($ketla);
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="user();">
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
          <div class="manage1" style="overflow: auto;" id="user">
              <h3>manage user
              <div style="float: right;margin-right: 20px;">
                        <?php
                            $cont=  mysql_query("select count(usertype) from registration");
                            $contt=  mysql_fetch_array($cont);
                            echo "total user are : ".$contt[0];
                        ?>
              </div>
              </h3><br>
              <div class="umain">
                    <input type="text" name="search" onkeyup="search1(this.value,'registration');" placeholder="Search Here"/>
                    <a href="delete.php?all=user"><img src="images/delete2.png" title="delete all records" width="30px" style="vertical-align: middle;"/></a>
              </div>
              <div class="udis">
                        <form method="post" action="">
                            <center>
                                <table id="disid" width="100%">
                                    <th>user type</th>
                                    <th>name</th>
                                    <th>address</th>
                                    <th>gender</th>
                                    <th>email</th>
                                    <th>mobile</th>
                                    <th>country</th>
                                    <th>state</th>
                                    <th>city</th>
                                    <th>dob</th>
                                    <th>user ID</th>
                                    <th>images</th>
                                    <th>password</th>
                                    <th>question</th>
                                    <th>answer</th>
                                    <th>terms</th>
                                    <th>delete</th>
                                    <?php
                                        $no=$_REQUEST[base];
                                        $st=($no*$perpage)-$perpage;
                                        $data=mysql_query("select * from registration limit $st,$perpage");
                                        while($row=mysql_fetch_array($data))
                                        {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[0];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[2];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[3];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[4];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[5];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[6];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[7];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[8];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[9];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[10];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[11];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[12];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[13];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[14];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[15];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=user"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>
                                    </tr>
                                   <?php
                                        }
                                    ?>
                                </table><br>
                                <ul align="center">
                                        <?php
                                            $page=$chhe[0]/$perpage;
                                            $page=ceil($page);
                                            if($page>5)
                                            {
                                                if($_REQUEST[base]>=1 && $_REQUEST[base]<=5)
                                                {
                                                    $start=1;
                                                    $end=5;
                                                }
                                                else
                                                {
                                                    if($_REQUEST[next]<=$page)
                                                    {
                                                        $start=$_REQUEST[next]-4;
                                                        $end=$_REQUEST[next];
                                                    }
                                                }  
                                            }
                                            else
                                            {
                                                $start=1;
                                                $end=$page;
                                            }
                                            if($start>=1 && $end<=5)
                                            {
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;"><a href="manageuser.php?next=<?php if($end>1){echo $end-1;}else{echo $page;} ?>&base=<?php if($end>1){echo $end-1;}else{echo $page;} ?>#user" style="color: white;"><</a></li>
                                        <?php
                                            
                                        }
                                        for($i=$start;$i<=$end;$i++)
                                        {
                                            
                                            if($i==$_REQUEST[base])
                                            {
                                        ?>
                                        <li style="background: #e44f2b;border:1px solid #23272a;"><a href="manageuser.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#user" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;"><a href="manageuser.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#user" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                        }
                                        } 
                                        
                                        if($page>5)
                                        {
                                     
                                        ?>
                                        <li style="background: #23272a;"><a href="manageuser.php?next=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>&base=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>#user" style="color: white;">></a></li>
                                        <?php
                                        }
                                        ?>
                                    </ul><br>
                            </center>
                        </form>
              </div> 
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
