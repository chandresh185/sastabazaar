<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(ad_rate_id) from ad_rate");
    $chhe=mysql_fetch_array($ketla);
    if(isset($_REQUEST[send]))
        {
            if($_REQUEST[mane]=="--Select--")
            {
                     $ccname=1;
            }
            if($_REQUEST[mane1]=="--Select--")
            {
                     $ccname1=1;
            }
            $g=mysql_query("select * from ad_rate");
            while($gg=  mysql_fetch_array($g))
            {
                if(stristr($gg[1],$_REQUEST[mane]))
                {
                    $ename2=1;
                }
            }
            if($ccname!=1 && $ccname1!=1)
           {
                
                $inn=mysql_query("insert into ad_rate values(0,'$_REQUEST[mane]','$_REQUEST[mane1]')");
                //echo $inn;
                header('location:managead_rate.php?base=1#adrate');
           }
        }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="adrate();">
    <script type="text/javascript">
        $(".document").ready(function(){
            $(".cadd").hide();
            $(".cbutton").click(function(){
                $(".cadd").toggle(1000);  
            });
        });
        
        </script>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
        <div class="managecountry" id="adrate">
                    <h3>manage ad_rate
                    <div style="float: right;margin-right: 20px;">
                        <?php
                            $cont=  mysql_query("select count(ad_rate_id) from ad_rate");
                            $contt=  mysql_fetch_array($cont);
                            echo "total ad_rate are : ".$contt[0];
                        ?>
                    </div>
                    </h3></br>
                    <div class="cmain">
                        <button class="cbutton" type="submit" value="Submit" name="send">Add Here</button>  
                        <a href="delete.php?all=adrate"><img src="images/delete2.png" title="delete all records" width="30px" style="margin-left: 1140px;vertical-align: middle;"/></a>
                    </div>
                    <div class="cadd">
                    <form method="post" action="">
                        <table>
                            <tr>
                                <td colspan="2">
                                    <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <select name="mane">
                                        <option>--Select--</option>
                                        <option>1 Week</option>
                                        <option>2 Week</option>
                                        <option>3 Week</option>
                                        <option>1 Month</option>
                                        <option>3 Month</option>
                                        <option>6 Month</option>
                                        <option>1 Year</option>
                                   </select>
                                </td>
                                <td>
                                  <?php
                                        if($ccname==1)
                                        {         
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                  ?>  
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <select name="mane1">
                                        <option>--Select--</option>
                                        <option>500</option>
                                        <option>1000</option>
                                        <option>1500</option>
                                        <option>2000</option>
                                        <option>6000</option>
                                        <option>12000</option>
                                        <option>24000</option>
                                   </select>
                                </td>                                
                                <td>
                                    <?php
                                        if($ccname1==1)
                                        {         
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                        else
                                        {
                                            if($ename2==1)
                                            {
                                                echo "<font color=red size=3px><-</font>";
                                            }
                                        }    
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <button type="submit" value="Submit"  class="feedbackbutton" name="send">Submit</button>
                                    <button type="reset" class="feedbackbutton" name="clear">Clear</button>
                                    <div class="clear"></div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <font style="font-size: 10px;color: red;">note : * blank | ^ invalid | <- dublication</font>
                                </td>
                            </tr>
                        </table>
			</form>
                        </div>
                        <div class="cdis">
                        <form method="post" action="">
                            <center>
                                <table id="disid" width="100%">
                                    <th>ad_rate time period</th>
                                    <th>rs</th>
                                    <th>delete</th>
                                    <?php
                                        $no=$_REQUEST[base];
                                        $st=($no*$perpage)-$perpage;
                                        $data=mysql_query("select * from ad_rate limit $st,$perpage");
                                        while($row=mysql_fetch_array($data))
                                        {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td> 
                                            <?php
                                                echo $row[2];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=adrate"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>                                
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                </table><br>
                                <ul align="center">
                                            <?php
                                                $page=$chhe[0]/$perpage;
                                                $page=ceil($page);
                                                if($page>5)
                                                {
                                                    if($_REQUEST[base]>=1 && $_REQUEST[base]<=5)
                                                    {
                                                        $start=1;
                                                        $end=5;
                                                    }
                                                    else
                                                    {
                                                        if($_REQUEST[next]<=$page)
                                                        {
                                                            $start=$_REQUEST[next]-4;
                                                            $end=$_REQUEST[next];
                                                        }
                                                    }  
                                                }
                                                else
                                                {
                                                    $start=1;
                                                    $end=$page;
                                                }
                                                if($start>=1 && $end<=5)
                                                {
                                            
                                                }
                                                else
                                                {
                                            ?>
                                            <li style="background: #23272a;"><a href="managead_rate.php?next=<?php if($end>1){echo $end-1;}else{echo $page;} ?>&base=<?php if($end>1){echo $end-1;}else{echo $page;} ?>#adrate" style="color: white;"><</a></li>
                                            <?php
                                            
                                                }
                                                for($i=$start;$i<=$end;$i++)
                                                {
                                            
                                                    if($i==$_REQUEST[base])
                                                {
                                            ?>
                                            <li style="background: #e44f2b;border:1px solid #23272a;"><a href="managead_rate.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#adrate" style="color: white;"><?php echo $i; ?></a></li>
                                            <?php
                                            
                                                }
                                                else
                                                {
                                            ?>
                                            <li style="background: #23272a;"><a href="managead_rate.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#adrate" style="color: white;"><?php echo $i; ?></a></li>
                                            <?php
                                                }
                                            } 
                                        
                                            if($page>5)
                                            {
                                     
                                            ?>
                                            <li style="background: #23272a;"><a href="managead_rate.php?next=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>&base=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>#adrate" style="color: white;">></a></li>
                                            <?php
                                            }
                                            ?>
                                    </ul><br>
                            </center>
                        </form>    
                        </div>         
            </div>  
        <div style="clear: both;">
            
        </div>
    </div>  
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>