<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
     $perpage=10;
    $ketla=mysql_query("select count(productid) from product");
    $chhe=mysql_fetch_array($ketla);
?>

<center>
    <table id="disid" width="100%">
                            <th>name</th>
                            <th>auction</th>
                            <th>items</th>
                            <th>type</th>
                            <th>company</th>
                            <th>item name</th>
                            <th>item discription</th>
                            <th>price</th>
                            <th>active/deactive</th>
                            <th>commision</th>
                            <th>delete</th>
                           <?php
                                            $no=$_REQUEST[base];
                                            $st=($no*$perpage)-$perpage;
                                            $data=mysql_query("select * from product limit $st,$perpage");
                                            while($row=mysql_fetch_array($data))
                                            {
                                    ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        echo $row[0];
                                    ?>
                                </td>
                                <td>
                                    <?php echo $row[1]; ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from maincategories where maincateid=$row[2]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[1];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from subcategories where subcateid=$row[3]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from company where companyid=$row[4]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[6];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[7];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[8];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        if($row[9]==0)
                                        {
                                            echo "<font size='3' style='cursor:pointer;' onclick='slact($row[5]);'><img src='images/deactive.png' width='15px'/></font>";
                                        }
                                        else
                                        {
                                            echo "<font size='3' style='cursor:pointer;' onclick='slact($row[5]);'><img src='images/active.png' width='15px'/></font>";
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php echo $row[11]; ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=sadpost"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                           <?php
                                }
                            ?>
    </table><br>
</center>    
                            