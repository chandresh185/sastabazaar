<?php
    require_once 'conn.php';
    
    if($_REQUEST[status1]!="")
    {
        mysql_query("update product set stetus='$_REQUEST[status1]' where productid='$_REQUEST[proid1]'");
    }
    if($_REQUEST[prodid1]!="")
    {
        mysql_query("delete from product where productid='$_REQUEST[prodid1]'");
    }
    
?>



<div style="background: #23272a;color: white;padding: 10px;width: 990px;margin-left:240px;">
                    <b style="color: #e44f2b;font-size: 18px;">A</b>ctive 
              </div>
              <div style="background: white;margin-left: 240px;overflow: auto;height: 400px;width: 1000px;padding: 5px;">
                    
                      <div style="margin-top: 15px;">
                          <?php
                            $in3=  mysql_query("select * from product where active='1' and stetus='0' and userid='$_SESSION[user]'");

                            while($inn3=  mysql_fetch_array($in3))
                            {    

                          ?>  
                          <table>

                              <tr>

                                  <td>
                                      <div>
                                            <?php
                                                $p=mysql_query("select * from product_mstr2 where  productid='$inn3[5]'");
                                                $pp= mysql_fetch_array($p);
                                            ?>
                                            <img src="<?php echo $pp[2]; ?>" width="200px" height="235px" style="border-radius:5px;box-shadow:1px 1px 1px #23272a;"/>
                                      </div>
                                  </td>
                                  <td style="vertical-align: top;">
                                      <div class="sinfo">
                                            <table> 
                                                <tr>
                                                    <td width="15%"><b>I</b>tems :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                        $g=mysql_query("select * from maincategories where maincateid=$inn3[2]");
                                                        $gg=  mysql_fetch_array($g);
                                                        echo $gg[1];
                                                    ?>
                                                    </td>     
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>T</b>ype :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                            $g=mysql_query("select * from subcategories where subcateid=$inn3[3]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[2];
                                                        ?>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>C</b>ompany :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                            $g=mysql_query("select * from company where companyid=$inn3[4]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[2];
                                                        ?>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>I</b>tem <b>N</b>ame :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                        echo $inn3[6];
                                                    ?>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>I</b>tem <b>D</b>iscription :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                        echo $inn3[7];
                                                    ?>
                                                    </td>    
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>P</b>rice :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                    <td>
                                                    <?php
                                                        echo $inn3[8];
                                                    ?>
                                                    </td>    
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                            </table>
                                      </div>                              
                                  </td>
                              </tr>
                              <tr>
                                  <td>
                                      <br><br>
                                  </td> 
                              </tr>  
                              <tr>
                                  <td colspan="2">
                                        <div  style="margin-left: 955px;width: 25px;margin-top: -287px;">
                                            <img src="images/del.png" width="25px" onclick="setdeacthistory('1','<?php echo $inn3[5]; ?>');"/>
                                        </div>
                                  </td>
                              </tr>
                          </table>
                      
                          <?php
                            }
                      ?> 
                      </div>
                   </div>
                    <br>
                    <div style="background: #23272a;color: white;padding: 10px;width: 990px;margin-left:240px;">
                        <b style="color: #e44f2b;font-size: 18px;">D</b>eactive 
                    </div>
                    <div style="background: white;margin-left: 240px;overflow: auto;height: 400px;width: 1000px;padding: 5px;">

                          <div style="margin-top: 15px;">
                              <?php
                                $in3=  mysql_query("select * from product where active='0' and userid='$_SESSION[user]'");

                                while($inn3=  mysql_fetch_array($in3))
                                {    

                              ?>  
                              <table>

                                  <tr>

                                      <td>
                                          <div>
                                                <?php
                                                    $p=mysql_query("select * from product_mstr2 where  productid='$inn3[5]'");
                                                    $pp= mysql_fetch_array($p);
                                                ?>
                                                <img src="<?php echo $pp[2]; ?>" width="200px" height="235px" style="border-radius:5px;box-shadow:1px 1px 1px #23272a;"/>
                                          </div>
                                      </td>
                                      <td style="vertical-align: top;">
                                          <div class="sinfo">
                                                <table> 
                                                    <tr>
                                                        <td width="15%"><b>I</b>tems :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            $g=mysql_query("select * from maincategories where maincateid=$inn3[2]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[1];
                                                        ?>
                                                        </td>     
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>T</b>ype :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                                $g=mysql_query("select * from subcategories where subcateid=$inn3[3]");
                                                                $gg=  mysql_fetch_array($g);
                                                                echo $gg[2];
                                                            ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>C</b>ompany :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                                $g=mysql_query("select * from company where companyid=$inn3[4]");
                                                                $gg=  mysql_fetch_array($g);
                                                                echo $gg[2];
                                                            ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>I</b>tem <b>N</b>ame :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[6];
                                                        ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>I</b>tem <b>D</b>iscription :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[7];
                                                        ?>
                                                        </td>    
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>P</b>rice :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[8];
                                                        ?>
                                                        </td>    
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                </table>
                                          </div>                              
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <br><br>
                                      </td> 
                                  </tr>  
                                  <tr>
                                      <td colspan="2">
                                            <div  style="margin-left: 955px;width: 25px;margin-top: -287px;">
                                                <img src="images/del.png" width="25px"/>
                                            </div>
                                      </td>
                                  </tr>
                              </table>

                              <?php
                                }
                          ?> 
                          </div>
                       </div>
                        <br>
                    <div style="background: #23272a;color: white;padding: 10px;width: 990px;margin-left:240px;">
                        <b style="color: #e44f2b;font-size: 18px;">H</b>istory 
                    </div>
                    <div style="background: white;margin-left: 240px;overflow: auto;height: 400px;width: 1000px;padding: 5px;">

                          <div style="margin-top: 15px;">
                              <?php
                                $in3=  mysql_query("select * from product where active=1 and stetus=1 and userid='$_SESSION[user]'");

                                while($inn3=  mysql_fetch_array($in3))
                                {    

                              ?>  
                              <table>

                                  <tr>

                                      <td>
                                          <div>
                                                <?php
                                                    $p=mysql_query("select * from product_mstr2 where  productid='$inn3[5]'");
                                                    $pp= mysql_fetch_array($p);
                                                ?>
                                                <img src="<?php echo $pp[2]; ?>" width="200px" height="235px" style="border-radius:5px;box-shadow:1px 1px 1px #23272a;"/>
                                          </div>
                                      </td>
                                      <td style="vertical-align: top;">
                                          <div class="sinfo">
                                                <table> 
                                                    <tr>
                                                        <td width="15%"><b>I</b>tems :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            $g=mysql_query("select * from maincategories where maincateid=$inn3[2]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[1];
                                                        ?>
                                                        </td>     
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>T</b>ype :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                                $g=mysql_query("select * from subcategories where subcateid=$inn3[3]");
                                                                $gg=  mysql_fetch_array($g);
                                                                echo $gg[2];
                                                            ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>C</b>ompany :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                                $g=mysql_query("select * from company where companyid=$inn3[4]");
                                                                $gg=  mysql_fetch_array($g);
                                                                echo $gg[2];
                                                            ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>I</b>tem <b>N</b>ame :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[6];
                                                        ?>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>I</b>tem <b>D</b>iscription :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[7];
                                                        ?>
                                                        </td>    
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>P</b>rice :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td>
                                                        <?php
                                                            echo $inn3[8];
                                                        ?>
                                                        </td>    
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <br>
                                                        </td>
                                                    </tr>
                                                </table>
                                          </div>                              
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <br><br>
                                      </td> 
                                  </tr>  
                                  <tr>
                                      <td colspan="2">
                                            <div  style="margin-left: 955px;width: 25px;margin-top: -287px;">
                                                <img src="images/del.png" width="25px" onclick="deldealerhis('<?php echo $inn3[5]; ?>');"/>
                                            </div>
                                      </td>
                                  </tr>
                              </table>

                              <?php
                                }
                          ?> 
                          </div>
                       </div>
              <div style="clear: both;"></div>