<!DOCTYPE HTML>
<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=2)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'updatebcover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'bcover.php';
          ?>
          <div class="adminright" id="wish">
              <div class="cp">
                  <a href="buyerhome.php#buyerhome" style="color: white;">&vltri;</a>
              </div>
              <div class="ep" style="position: relative;">
                  <br><br>w<br>i<br>s<br>h<br>l<br>i<br>s<br>t
              </div>
              <div style="margin-left: 200px;padding: 5px;">
                  <div style="background: yellow;">
                      <ul>
                          <?php
                                        $n=0;
                                        $dataw=mysql_query("select * from wishlist where userid='$_SESSION[user]'");
                                        while($rowd1= mysql_fetch_array($dataw))
                                        {
                                            $n++;
                                            if($n>9)
                                            {
                                                break;
                                            }
                                            $c=0;
                                            $data11=mysql_query("select * from product_mstr2 where productid='$rowd1[1]'");
                                            while($row22= mysql_fetch_array($data11))
                                            {
                                                $c++;
                                                if($c>1)
                                                {
                                                    break;
                                                }
                                    ?>
                          <div style="float: left;margin: 15px;">
                                <li style="display: inline;">
                                    <div style="">
                                        <center><img width="250px" height="300px" src="<?php echo $row22[2]; ?>" style="border-radius:5px 5px 0px 0px;" /></center>
                                    </div>
                                    <center>
                                    <div style="background: #e44f2b;height: 40px;margin-top: -3px;padding-top: 4px;border-radius:0px 0px 5px 5px;">
                                        <a href="productdetail.php?id=<?php echo $rowd1[1]; ?>"><img src="images/ditale.png" title="show in details" /></a>
                                        <?php
                                            $d=  mysql_query("select * from product where userid='$_SESSION[user]'");
                                            $dd=  mysql_fetch_array($d);
                                            
                                            if ($dd[12]=='new')
                                            {
                                        ?>
                                        <a href="managecart.php?id=<?php echo $rowd1[1]; ?>#cart"> <img src="images/cart.png" title="add to cart" style="margin-left: 70px;margin-right: 70px;"></a> 
                                        <?php
                                            }
                                        ?>
                                        <a href="delete.php?id=<?php echo $rowd1[0]; ?>&ek=wish"><img src="images/remove11.png" width="32px" title="remove details" style="margin-left: 170px;"/></a>
                                    </div>
                                    </center> 
                                
                                </li>
                          </div>
                          <?php
                                        }
                                     }   
                                    ?>
                      </ul>
                  </div>
                  
              </div>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>