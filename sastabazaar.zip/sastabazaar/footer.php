<div class="popularcity" id="footer">
    
    <div class="mainpopcity">
        <p>&triangleright;&nbsp;&nbsp;&nbsp;&nbsp;Popular City</p>
        <div class="fline">
        </div>
        <div class="popcity">
            <ul>
                <li>Surat</li>
                <li>Vadodara</li>
                <li>Ahmedabad</li>
                <li>vapi</li>
                <li>Valsad</li>
            </ul>
        </div>
        <div class="popcity">
            <ul>
                <li>Ankleshwar</li>
                <li>kolkata</li>
                <li>Bangalore</li>
                <li>Delhi</li>
                <li>Chennai</li>
            </ul>
        </div>
        <div class="popcity">
            <ul>
                <li>Jaipur</li>
                <li>pune</li>
                <li>kochi</li>
                <li>Mumbai</li>
                <li>All City</li>
            </ul>
        </div>
    </div>
    <div class="app">
        <p>&triangleright;&nbsp;&nbsp;&nbsp;&nbsp;Facebook Like</p> 
        <div class="fline1">
        </div>
        <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
        <div style="background: #e44f2b;width: 422px;height: 200px;color: white;margin-top: 8px;">
           <div class="fb-page" data-href="https://www.facebook.com/pages/SastaBazaar/100660566931706?ref=bookmarks" data-width="422" data-height="200" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/pages/SastaBazaar/100660566931706?ref=bookmarks"><a href="https://www.facebook.com/pages/SastaBazaar/100660566931706?ref=bookmarks">SastaBazaar</a></blockquote></div></div>
        </div>
    </div> 
    <div class="link1">
        <p>&triangleright;&nbsp;&nbsp;&nbsp;&nbsp;SastaBazaar link</p>
        <div class="fline2">
        </div>
        <div class="flink">
            <ul>
                <li>
                    <a href="privacypolicy.php">terms of use</a>
                </li>
                <li>
                    <a href="privacypolicy.php">listing policy</a>
                </li>
                <li>
                    <a href="privacypolicy.php">privacy policy</a>
                </li>
                <li>
                    <a href="sitemap.php">site map</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="payment">
        <div class="card">
            <a href="preview.php"><img src="images/footer/credit.png" alt="" title="credit" /></a>
        </div>
        <div class="card1">
            <a href="preview.php"><img src="images/footer/visa.png" alt="" title="visa" /></a>
        </div>
        <div class="card2">
            <a href="preview.php"><img src="images/footer/master.png" alt="" title="master card" /></a>
        </div>
        <div class="card3">
            <a href="preview.php"><img src="images/footer/credit2.png" alt="" title="credit" /></a>
        </div>
        <div class="card4">
            <a href="preview.php"><img src="images/footer/paypal.png" alt="" title="paypal" /></a>
        </div>
    </div>
    <div class="email">
        <?php
            require_once 'emailsubscribe.php';
        ?>
    </div>    
</div>


<div class="footer">
    <div class="copy_right">
         <p>Copyrights &COPY; 2015 Sastabazaar All Rights Reserved | Design By : <a href="">Successoft Infotech</a></p>
    </div>
</div>
<?php
        ob_flush();
?>
