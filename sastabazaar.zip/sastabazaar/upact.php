<?php
    require_once 'conn.php';
    
    $s=mysql_query("select active from review where reviewid=$_REQUEST[id]");
    $ss=mysql_fetch_array($s);
    if($ss[0]==0)
    {
        $up=mysql_query("update review set active=1 where reviewid=$_REQUEST[id]");
    }
    else
    {
        $up=mysql_query("update review set active=0 where reviewid=$_REQUEST[id]");
    }
    $perpage=10;
    $ketla=mysql_query("select count(reviewid) from review");
    $chhe=mysql_fetch_array($ketla);
?>
<center>
    <table id="disid" width="100%">
        <th>name</th>
                            <th>review</th>
                            <th>active/deactive</th>
                            <th>date/time</th>
                            <th>delete</th>
                            <?php
                                    $no=$_REQUEST[base];
                                    $st=($no*$perpage)-$perpage;
                                    $data=mysql_query("select * from review limit $st,$perpage");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        if($row[4]==0)
                                        {
                                            echo "<font size='3' color='red' style='cursor:pointer;' onclick='act($row[0]);'> &Del;</font>";
                                        }
                                        else
                                        {
                                            echo "<font size='3' color='green' style='cursor:pointer;' onclick='act($row[0]);'> &Delta;</font>";
                                        }
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[5];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=review"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                            <?php
                                }
                            ?>
    </table><br>
    <ul align="center">
                                        <?php
                                            $page=$chhe[0]/$perpage;
                                            $page=ceil($page);
                                            if($page>5)
                                            {
                                                if($_REQUEST[base]>=1 && $_REQUEST[base]<=5)
                                                {
                                                    $start=1;
                                                    $end=5;
                                                }
                                                else
                                                {
                                                    if($_REQUEST[next]<=$page)
                                                    {
                                                        $start=$_REQUEST[next]-4;
                                                        $end=$_REQUEST[next];
                                                    }
                                                }  
                                            }
                                            else
                                            {
                                                $start=1;
                                                $end=$page;
                                            }
                                            if($start>=1 && $end<=5)
                                            {
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;"><a href="managereview.php?next=<?php if($end>1){echo $end-1;}else{echo $page;} ?>&base=<?php if($end>1){echo $end-1;}else{echo $page;} ?>#review" style="color: white;"><</a></li>
                                        <?php
                                            
                                        }
                                        for($i=$start;$i<=$end;$i++)
                                        {
                                            
                                            if($i==$_REQUEST[base])
                                            {
                                        ?>
                                        <li style="background: #e44f2b;border:1px solid #23272a;"><a href="managereview.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#review" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                            
                                            }
                                            else
                                            {
                                        ?>
                                        <li style="background: #23272a;"><a href="managereview.php?base=<?php echo $i; ?>&next=<?php echo $i; ?>#review" style="color: white;"><?php echo $i; ?></a></li>
                                        <?php
                                        }
                                        } 
                                        
                                        if($page>5)
                                        {
                                     
                                        ?>
                                        <li style="background: #23272a;"><a href="managereview.php?next=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>&base=<?php if($end<$page){echo $end+1;}else{echo 1;} ?>#review" style="color: white;">></a></li>
                                        <?php
                                        }
                                        ?>
                                    </ul><br>
</center> 