<?php
    require_once 'conn.php';
?>
<center>
                                    <div style="float: left;padding-left:20px; -webkit-transform:rotate(20deg);color: #ef5f21;">
                                        
                                        <?php
                                            $ek=rand(0,9);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo $ek;$_SESSION[ek]=$ek; ?></font>
                                    </div>
                                    <div style="float: left;padding-left: 10px ;-webkit-transform:rotate(-20deg);color:d61f85;margin-left: -16px;">
                                        <?php
                                            $biju=rand(65,90);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo chr($biju);$_SESSION[be]=chr($biju); ?></font>
                                    </div>
                                    <div style="float: left; padding-left: 10px;color: #d5331d;-webkit-transform:rotate(-30deg);margin-left: -16px;">
                                        <?php
                                            $char=rand(11,70);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo $char;$_SESSION[chothi]=$char; ?></font>
                                    </div>

                                    <div style="float: left; padding-left: 10px; color:#00677c;-webkit-transform:rotate(30deg);margin-left: -16px;">
                                        <?php
                                            $tran=rand(97,122);
                                        ?>
                                        <font style="font-size: 35px;"><?php echo chr($tran);$_SESSION[tran]=chr($tran); ?></font>
                                    </div>
                                    
                                    </center>
                                <div style="clear: both;"></div>