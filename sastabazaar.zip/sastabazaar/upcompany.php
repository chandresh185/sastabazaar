<?php
	require_once 'conn.php';	
	$data=mysql_query("select companyname from company where companyid='$_REQUEST[id]'");
	$row=mysql_fetch_array($data);
        if(isset($_REQUEST[send]))
        {
            if($_REQUEST[name]=="")
             {
                    $ename=1;
             }
            $pat='/^[a-zA-Z ]+$/';
            if(!preg_match($pat, $_REQUEST[name]))
            {
                   $ename1=1;
            }
            $g=mysql_query("select * from company");
            while($gg=mysql_fetch_array($g))
            {
                
                if(stristr($gg[1],$_REQUEST[name]) && strlen($gg[1])==strlen($_REQUEST[name]))
                {
                    $ename2=1;
                    
                    break;
                }
            }
            if($ename!=1 && $ename1!=1  && $ename2!=1)
           {
               $in=mysql_query("update company set companyname='$_REQUEST[name]' where companyid='$_REQUEST[id]' ");
               header('location:managecompany.php?base=1#company');
           }
        }
?>

<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
    <div class="admin">	
          <?php
                  require_once 'adminmenu.php';
          ?>
        <div class="managecountry">
                    <h3>update company</h3></br></br>	
                    <form method="post" action="">
                                  <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                  ?>
                                  <input type="text" name="name" placeholder="update company" value="<?php echo $row[0]; ?>">
                                    <?php
                                        if($ename==1)
                                        {
                                            echo "<font color=red size=3px>*</font>";
                                        }
                                        else
                                        {
                                            if($ename1==1)
                                            {
                                                echo "<font color=red size=3px>*</font>";
                                            }
                                            else
                                            {
                                                if($ename2==1)
                                                {
                                                    echo "<font color=red size=3px>Country Already Exist</font>";
                                                }  
                                            }
                                        }                                                                    
                                     ?>
				<div>
                                    <button type="submit" value="Submit"  class="feedbackbutton" name="send">Submit</button>
                                    <button type="reset" class="feedbackbutton" name="clear">Clear</button>
                                    <div class="clear"></div>
                                </div>
			</form>
            </div>
        </div>
    </div>     
   <?php
        require_once 'footer.php';
   ?>