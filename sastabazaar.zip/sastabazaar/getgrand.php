<?php
require_once 'conn.php';
$main=0;
$s=  mysql_query("select total from cart where userid='$_SESSION[user]'");
while($gg=  mysql_fetch_array($s))
{
    $main=$main+$gg[0];
}


?>
<td colspan="8" style="background: #23272a;padding: 15px;color: white;text-align: right;font-size: 15px;font-weight: bold;">
                                    grand total :
                                    <?php
                                        echo "&#8377;".$_SESSION[hardik];
                                        
                                    ?>    
</td>