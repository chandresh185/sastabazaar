<?php
    require_once 'conn.php';
    if(isset($_REQUEST[ssend]))
    {
    /*file uploading*/
       
       $fname=$_FILES[scoverimg][name];
       $types=substr($_FILES[scoverimg][type],6);
       $siz=$_FILES[scoverimg][size];
       $siz=$siz/1024;
       $siz=$siz/1024;
       $ex=".".substr($_FILES[scoverimg][type],6);
       if($siz<=5)
       {
           if($ex==".jpg" || $ex==".jpeg")
           {
               $nwname=$_SESSION[user].$ex;
               $path1="scover/".$nwname;
               $path2=dirname(__FILE__)."/scover/".$nwname;
           }
           else
           {
               $er1=1;
           }
       }
       else
       {
           $er2=1;
       }
       
       /*file uploading end*/
       
       if($er1!=1 && $er2!=1)
       {
           $cov=mysql_query("update scover set scoverimage='$path1' where userid='$_SESSION[user]'");
          
           //echo $cov;
           move_uploaded_file($_FILES[scoverimg][tmp_name], $path2);
       }
    }     
?>


    <div class="ssetting">
        
    </div>
    <div class="sset">
        <div style="padding: 5px;">
            <?php
                        $c=  mysql_query("select * from scover where userid='$_SESSION[user]'");
                        $cc=  mysql_fetch_array($c);
                  ?>
            <img src="<?php echo $cc[1]; ?>" width="350px" height="200px" style="border-radius:5px;"/>
        </div>
        <div>
            <form method="post" action="" enctype="multipart/form-data">
                <table width="100%">
                    <tr>
                        <td style="text-align: center;">
                            <input type="file" name="scoverimg" style="margin-left: 100px;"/>
                            <?php
                                    if($er1==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                    elseif($er2==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div style="margin-left: 100px;">
                                <button type="submit" name="ssend" class="feedbackbutton">send</button>
                                <button type="submit" class="feedbackbutton">cancel</button>
                            </div>                            
                        </td>
                    </tr>
                </table>
            </form>
        </div>    
    </div>