<?php
    require_once 'conn.php';
//    echo $_REQUEST[str];
    if($_REQUEST[str]!="")
    {
        $ser=mysql_query("select * from product where productname like '%$_REQUEST[str]%'");
        while($s=  mysql_fetch_array($ser))
        {
            ?>
                <a href="productdetail.php?id=<?php echo $s[5]; ?>" style="color: #23272a;font-size: 15px;padding: 5px;"><?php echo $s[6]; ?><br></a>
            <?php
        }
    }
?>