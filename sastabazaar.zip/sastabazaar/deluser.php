<?php
    
    require_once 'conn.php';
    
    $del= mysql_query("delete from registration where usertype='$_REQUEST[id]'");
    
    header ('location:manageuser.php');
?>