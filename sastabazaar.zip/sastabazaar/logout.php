<?php
        require_once 'conn.php';
       
        $de=mysql_query("delete from logintime where userid='$_SESSION[user]'");
        $inn=mysql_query("insert into logintime values('$_SESSION[user]','$_SESSION[datee]','$_SESSION[timee]')");
       
        $c=mysql_query("delete from cart where userid='$_SESSION[user]'");
        
        unset($_SESSION[user]);
        unset($_SESSION[type]);
        unset($_SESSION[datee]);
        unset($_SESSION[timee]);
        unset($_SESSION[wrong]);
        header('location:index.php');
?>
