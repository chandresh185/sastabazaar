<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>Amazing Slider</title>
    
    <!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
    
</head>
<body>
<div style="margin:30px auto;max-width:1500px;">
    
    <!-- Insert to your webpage where you want to display the slider -->
    <div id="amazingslider-1" style="display:block;position:relative;margin:16px auto 56px;">
        <ul class="amazingslider-slides" style="display:none;">
            <li><img src="images/03_banner.jpg" alt="03_banner" /></li>
            <li><img src="images/05_banner (1).jpg" alt="05_banner (1)" /></li>
            <li><img src="images/christian-banner-home-bg.jpg" alt="christian-banner-home-bg" /></li>
            <li><img src="images/hindu-banner-home-bg.jpg" alt="hindu-banner-home-bg" /></li>
            <li><img src="images/marvari-banner-home-bg.jpg" alt="marvari-banner-home-bg" /></li>
            <li><img src="images/MENS-JEWELLERY3.jpg" alt="MENS-JEWELLERY3" /></li>
        </ul>
        <ul class="amazingslider-thumbnails" style="display:none;">
            <li><img src="images/03_banner-tn.jpg" /></li>
            <li><img src="images/05_banner (1)-tn.jpg" /></li>
            <li><img src="images/christian-banner-home-bg-tn.jpg" /></li>
            <li><img src="images/hindu-banner-home-bg-tn.jpg" /></li>
            <li><img src="images/marvari-banner-home-bg-tn.jpg" /></li>
            <li><img src="images/MENS-JEWELLERY3-tn.jpg" /></li>
        </ul>
        <div class="amazingslider-engine" style="display:none;"><a href="http://amazingslider.com">jQuery Slideshow</a></div>
    </div>
    <!-- End of body section HTML codes -->
    
</div>
</body>
</html>