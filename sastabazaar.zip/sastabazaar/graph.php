<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=0)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    $perpage=10;
    $ketla=mysql_query("select count(inquireid) from inquire");
    $chhe=mysql_fetch_array($ketla);
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
        <div class="managecountry" id="grapha">
            <h3>general graph 
              </h3></br>
              <div class="fmain">
                  <div style="background: #EBE7DF;padding: 10px;margin: 5px;">
                        <p style="font-size: 50px;text-align: center;color: #23272a;font-weight: bold;text-shadow:1px 1px 1px #e44f2b;">SastaBazaar progress of&nbsp;&nbsp;&nbsp;&nbsp;2014 - 15</p>
                  </div>
              </div>
              <div  style="background: white;width: 1006px;overflow: auto;margin-left: 10px;padding: 5px;border: 1px solid #e44f2b;">
                
                  <div class="mon" style="margin-top: 3px;">
                      jan
                  </div>
                   <?php
                            $w=335.33;
                            $w1=670.66;
                            $w2=1006;
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='01')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                        
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      feb
                  </div>
                   <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='02')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      mar
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='03')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      apr
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='04')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      may
                  </div>
                   <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='05')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      june
                  </div>
                   <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='06')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      jul
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='07')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      aug
                  </div>
                   <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='08')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      sep
                  </div>
                   <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='09')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      oct
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='10')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      nov
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='11')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div class="mon">
                      dec
                  </div>
                  <?php
                            $sum=0;
                            $d=  mysql_query("select * from bill");
                            while($dd=  mysql_fetch_array($d))
                            {
                                $t=$dd[4];
                                $t=substr($t,5,2);
                                
                                if($t=='12')
                                {
                                    $sum=$sum+$dd[2];
                                }
                            }
                            $m=($sum*100)/10000;
                            
                        ?>
                  <?php
                    if($m<=$w)
                    {
                  ?>
                  <div class="pato" style="background: red;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    elseif($m<=$w1)
                    {
                  ?>
                  <div class="pato" style="background: blue;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                    else
                    {
                  ?>
                  <div class="pato" style="background: green;width: <?php echo $m ?>px;">
                      
                  </div>
                  <?php
                    }
                  ?>
                  <div style="clear: both;"></div>
              </div>
              <div style="background: white;width: 1006px;padding: 10px;margin-left: 10px;border: 1px solid #e44f2b;margin-top: 3px;">
                  <div style="background: red;width: 80px;padding: 15px;margin-bottom: 5px;border-top: 2px #23272a solid;">
                      
                  </div>
                  <div style="font-size: 25px;text-transform: capitalize;margin-top: -40px;padding: 5px;position: absolute;color: #23272a;text-shadow:1px 1px 1px #e44f2b;margin-left: 120px;">
                      lower progress
                  </div>
                  <div style="background: blue;width: 80px;padding: 15px;margin-bottom: 5px;border-top: 2px #23272a solid;">
                      
                  </div>
                  <div style="font-size: 25px;text-transform: capitalize;margin-top: -40px;padding: 5px;position: absolute;color: #23272a;text-shadow:1px 1px 1px #e44f2b;margin-left: 120px;">
                      middle progress
                  </div>
                  <div style="background: green;width: 80px;padding: 15px;border-top: 2px #23272a solid;">
                      
                  </div>
                  <div style="font-size: 25px;text-transform: capitalize;margin-top: -40px;padding: 5px;position: absolute;color: #23272a;text-shadow:1px 1px 1px #e44f2b;margin-left: 120px;">
                      higher progress
                  </div>
              </div>
        </div>
          <br>
    </div>
    <div style="clear: both;"></div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>