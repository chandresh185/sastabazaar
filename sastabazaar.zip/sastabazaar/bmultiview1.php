<?php
    require_once 'conn.php';
?>

<div>
                                <ul>
                                    <?php
                                        $n=0;
                                        
                                        if($_REQUEST[shu]=="nathi" && $_REQUEST[how]!="" && $_REQUEST[kyathi]=="load")
                                        {
                                            unset ($_SESSION[wr]);
                                            $data=mysql_query("select * from product where maincateid='5' and auction='0' and  active=1 and producttype='old' limit 0,$_REQUEST[how]");
                                        }
                                        elseif ($_REQUEST[how]=="nathi" && $_REQUEST[shu]!="" && $_REQUEST[kyathi]=="maincate") 
                                        {
                                            $wr="maincateid=$_REQUEST[shu] or ";
                                            $_SESSION[wr].=$wr;
                                            $l=strlen($_SESSION[wr]);
                                            $fi=substr($_SESSION[wr],0,$l-3);
                                            $data=mysql_query("select * from product where $fi and maincateid='$_REQUEST[shu]' and auction='0' and  active=1 and producttype='old' order by productid desc");
                                        }
                                        elseif ($_REQUEST[how]=="nathi" && $_REQUEST[shu]!="" && $_REQUEST[kyathi]=="subcate") 
                                        {
                                            $wr="subcateid=$_REQUEST[shu] or ";
                                            $_SESSION[wr].=$wr;
                                            $l=strlen($_SESSION[wr]);
                                            $fi=substr($_SESSION[wr],0,$l-3);
                                            $data=mysql_query("select * from product where $fi and subcateid='$_REQUEST[shu]' and auction='0' and  active=1 and producttype='old' order by productid desc");
                                        }
                                        elseif ($_REQUEST[how]=="nathi" && $_REQUEST[shu]!="" && $_REQUEST[kyathi]=="company") 
                                        {
                                            $wr="companyid=$_REQUEST[shu] or ";
                                            $_SESSION[wr].=$wr;
                                            $l=strlen($_SESSION[wr]);
                                            $fi=substr($_SESSION[wr],0,$l-3);
                                            $data=mysql_query("select * from product where $fi and companyid='$_REQUEST[shu]' and auction='0' and  active=1 and producttype='old' order by productid desc");
                                        }
                                        elseif ($_REQUEST[how]=="nathi" && $_REQUEST[shu]!="" && $_REQUEST[kyathi]=="price") 
                                        {
                                            $min=$_REQUEST[shu];
                                            //echo $min;
                                            $max=$_REQUEST[shu]+1000;
                                            //echo $max;
                                            $data=mysql_query("select * from product where price between $min and $max and auction='0' and  active=1 and producttype='old' order by productid desc");
                                        }
                                        else
                                        {
                                            
                                            $u=mysql_query("select userid from registration where name like '$_REQUEST[shu]'");
                                            $uu=mysql_fetch_array($u);
                                            
                                            $data=mysql_query("select * from product where maincateid='5' and auction='0' and  active=1 and producttype='new' and userid like '$uu[0]'");
                                        }
                                        
                                        while($row1= mysql_fetch_array($data))
                                        {
//                                            $n++;
//                                            if($n>9)
//                                            {
//                                                break;
//                                            }
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[5]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c>1)
                                                {
                                                    break;
                                                }
                                    ?>
                                    <div class="dpro">
                                    <li style="display: inline;">
                                        <div class="pro1">
                                            <img width="200px" height="200px" src="<?php echo $row2[2];?>" style="border-radius:5px;box-shadow:1px 1px 1px #e44f2b;"/>
                                        </div>
                                        <div class="pro2">
                                            <table>
                                                <tr>
                                                    <td width="12%"><b>I</b>tems <b>N</b>ame : </td>
                                                    <td><?php echo $row1[6]; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>C</b>ompany :</td>
                                                    <td>
                                                        <?php
                                                            $g=mysql_query("select * from company where companyid=$row1[4]");
                                                            $gg=  mysql_fetch_array($g);
                                                            echo $gg[2];
                                                        ?>    
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>D</b>iscription :</td>
                                                    <td><?php echo $row1[7]; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="pro3">
                                            <?php
                                                if ($row1[12]=='new')
                                                {
                                            ?>
                                            <a href="managecart.php?id=<?php echo $row1[5]; ?>#cart"><img src="images/cart.png" title="add to cart" width="30px"/></a>  
                                            <?php
                                                }
                                            ?>
                                            <a href="wishlist.php? id=<?php echo $row1[5]; ?>&shu=product"><img src="images/wish.png" title="add to wishlist" width="25px" style="margin-right: 20px;margin-left: 20px;"/></a>
                                            <a href="rating.php?id=<?php echo $row1[5]; ?>&shu=product"><img src="images/ret.png" title="give rate" width="30px" style="margin-right: 20px;"/></a>
                                            <a href="productdetail.php?id=<?php echo $row1[5]; ?>#prodetail"><img src="images/ditale.png" title="show in details" width="30px"/></a>
                                        </div>    
                                    </li>
                                    </div>
                                    <div style="clear: both;">
                                        
                                    </div>    
                                    <?php
                                        }
                                     }
                                     if($_REQUEST[shu]=="nathi")
                                     {
                                    ?>
                                    
    <div class="vm" onclick="bmilt1('<?php echo $_REQUEST[how]+5; ?>','nathi','load')">
        <center>View More</center>
    </div>
                                    <?php
                                    }
                                  ?>  
                                </ul>
                            </div>
