<div class="adminleft">
              
    <center><p>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">W</b>elcome Mr.&nbsp;/&nbsp;Mrs.<br>
              <?php
                    $im=  mysql_query("select image from registration where userid='$_SESSION[user]'");
                    $imm=  mysql_fetch_array($im);
                
              ?>
               &nbsp;&nbsp;&nbsp;<img src="<?php echo $imm[0]; ?>" width="130px" height="130px;" style="border-radius:100px;border: 2px solid #e44f2b;"/>
              <?php
                $in=  mysql_query("select * from registration where userid = '$_SESSION[user]'");
                $a=  mysql_fetch_array($in);
                echo $a[1];
              ?></p></center>
    
                <ul>
                    <li><a href="buyerhome.php#buyerhome">dashboard</a></li>
                    <li><a href="buyerprofile.php#buyerprofile">Profile</a></li>     
                    <li><a href="buyereditprofile.php#editprofile">Edit Profile</a></li> 
                    <li><a href="buyerchangepassword.php#cpass">Change Password</a></li>
                    <li><a href="managewishlist.php#wish">wishlist</a></li>
                    <li><a href="managecart.php#cart">shopping cart</a></li>
                    <li><a href="bill.php#bill">view bill</a></li>
                </ul>
          </div>