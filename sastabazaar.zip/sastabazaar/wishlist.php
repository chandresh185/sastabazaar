<?php
    require_once 'conn.php';
    //echo $_REQUEST[shu];
    if($_SESSION[user]!="")
    {
        $ekk=mysql_query("select * from wishlist where userid='$_SESSION[user]' and productid= '$_REQUEST[id]'");
        
        $ekk1=  mysql_fetch_array($ekk);
        //echo $ekk1[1];
            
            if($ekk1[0]!="")
            {
                //echo "not insert<br>";
                
                if($_REQUEST[shu]=="product")
                {
                    
                    header('location:product.php');
                }
            }
            else
            {
                //echo "insert<br>";
                    $iin=mysql_query("insert into wishlist values('0','$_REQUEST[id]','$_SESSION[user]')");
                    //header('location:index.php');
                   
                    if($_REQUEST[shu]=="product")
                    {
                    
                        header('location:product.php');
                    }
            }
        
      
    }
    else
    {
                
                if($_REQUEST[shu]=="product")
                {
                    header('location:product.php');
                }
    }
?>