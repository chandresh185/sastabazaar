<?php
require_once 'conn.php';
    if(isset($_REQUEST[click]))
    {
        if($_REQUEST[name]=="")
        {
            $ename=1;
        }
        if($_REQUEST[mobile]=="")
        {
            $emobile=1;
        }
        if($_REQUEST[message]=="")
        {
            $emessage=1;
        }
        $pname='/^[a-zA-Z ]+$/';
        if(!preg_match($pname, $_REQUEST[name]))
        {
            $ename2=1;
        }
        $pmobile='/^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]+$/';
        if(!preg_match($pmobile, $_REQUEST[mobile]))
        {
            $emobile2=1;
        }
        if($ename!=1 && $emobile!=1 && $emessage!=1 && $ename2!=1 && $emobile2!=1)
        {
            $in=mysql_query("insert into feedback values(0,'$_REQUEST[name]','$_REQUEST[mobile]','$_REQUEST[message]')");
            $send=1;
        }
            
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  		    <?php
                        require_once 'menu.php';
                    ?>
    </div>
</div>   
 <div class="main">
 	<div class="wrap">
            <div class="preview-page">       
                <div class="contact-form" style="font-size: 15px;">
                    <h3><b style="color: #e44f2b;font-size: 18px;">F</b>eedback</h3>
		<form method="post" action="" name="feedback">
                    <table>
                        <tr>
                            <td colspan="2">
                                <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input name="name" type="text" placeholder="Enter Name" />
                            </td>
                            <td>
                            <?php
                                if($ename==1)
                                {
                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                }
                                else
                                {
                                    if($ename2==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                    }
                                }
                            ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>
                                <input name="mobile" maxlength="10" type="text" placeholder="Enter Mobile" />
                            </td>
                            <td>
                                <?php
                                    if($emobile==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                    }
                                    else
                                    {
                                        if($emobile2==1)
                                        {
                                            echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                        }
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span><textarea name="message" placeholder="Enter Message" ></textarea></span>
                            </td>
                            <td>
                                <?php
                                    if($emessage==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                    }
                                ?>
                            </td>
                        </tr>
                    </table>
                        <div class="clear"></div>
                        <div>
                           
                                <button type="submit" class="feedbackbutton" name="click">submit</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
			</div>
                        <font style="font-size: 10px;color: red;">note : * blank | ^ invalid </font>
		</form>
                </div>
            </div>		
         </div> 
    </div>
 </div>
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

