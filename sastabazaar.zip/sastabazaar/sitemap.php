<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  		    <?php
                        require_once 'menu.php';
                    ?>
    </div>
</div>   
            <div class="sitemap">
                    <h3>site map</h3></br></br>
                    <div class="sitemap1">
                        <ul>
                            <li><a href="index.php">&triangleright;&nbsp;&nbsp;home</a></li>
                            <li><a href="auction.php">&triangleright;&nbsp;&nbsp;auction</a></li>
                            
                            <li><a href="adpost.php">&triangleright;&nbsp;&nbsp;ad post</a></li>
                            <li><a href="registration.php">&triangleright;&nbsp;&nbsp;registration</a></li>
                            <li><a href="aboutus.php">&triangleright;&nbsp;&nbsp;about us</a></li>
                            <li><a href="contact.php">&triangleright;&nbsp;&nbsp;contact us</a></li>
                            <li><a href="feedback.php">&triangleright;&nbsp;&nbsp;feedback</a></li>
                            <li>
                                <a href="privacypolicy.php">&triangledown;&nbsp;&nbsp;policy</a>
                                <ul>
                                    <li><a href="privacypolicy.php#lpolicy">&triangleright;&nbsp;&nbsp;listing policy</a></li>
                                    <li><a href="privacypolicy.php#ppolicy">&triangleright;&nbsp;&nbsp;privacy policy</a></li>
                                    <li><a href="privacypolicy.php#terms">&triangleright;&nbsp;&nbsp;terms and use</a></li>
                                </ul>
                            </li>
                            
                            
                        </ul>
                    </div>
                    <div class="sitemap2">
                        <font><b>s</b>tatic <b>p</b>age <b>n</b>avigation</font>
                    </div>
                    <div style="clear: both;">
                        
                    </div>
            </div>        
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

