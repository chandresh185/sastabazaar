<!DOCTYPE HTML>
<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=2)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
    require_once 'head.php';
?>
<body>
	<?php
            require_once 'updatebcover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'bcover.php';
          ?>
          <div class="adminright" id="buyerprofile">
              
              <div class="profile">    
                <table width="100%">
                    <tr align="center">
                        <td colspan="2">
                            <?php
                                    echo "<img src='$a[11]' width='150px' height='150px' style='border:2px solid #23272a;border-radius:150px'";
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h3>
                                Personal Info :
                            </h3>
                            <div class="sp">
                                <table>
                                    <tr>
                                        <td>
                                            <b>N</b>ame:
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[1];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>E</b>mail :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[4];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>D</b>ate <b>O</b>f <b>B</b>irth :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[9];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <br>
                                        </td>
                                        <td>
                                            <br>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                        <td>
                            <h3>
                            Contact Info :
                            </h3>
                            <div class="sp">
                                <table>
                                    <tr>
                                        <td>
                                            <b>C</b>ountry :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[6];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>S</b>tate :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[7];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>C</b>ity :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[8];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>C</b>ontact :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[5];
                                            ?>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h3>
                            Login Info :
                            </h3>
                            <div class="sp">
                                <table>
                                    <tr>
                                        <td>
                                            <b>U</b>ser <b>I</b>D:
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[10];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>P</b>assword :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[12];
                                            ?>
                                        </td>
                                    </tr>
                                    
                                </table>
                            </div>
                        </td>
                        <td>
                            <h3>
                            Security Info :
                            </h3>
                            <div class="sp">
                                <table>
                                    <tr>
                                        <td>
                                            <b>Q</b>uestion :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[13];
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>A</b>nswer :
                                        </td>
                                        <td>
                                            <?php
                                                echo $a[14];
                                            ?>
                                        </td>
                                    </tr>
                                    
                                </table>
                            </div>
                        </td>
                    </tr>
                </table>    
                  </div>
              
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
   <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>       
</body>
</html>
