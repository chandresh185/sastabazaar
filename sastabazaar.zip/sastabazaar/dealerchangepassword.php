<?php
    require_once 'conn.php';
    if(isset($_REQUEST[submit2]))
    {
        /*password*/
        if($_REQUEST[pass]=='')
        {
           $epass=1;
        }
        if($_REQUEST[pass]!=$_REQUEST[repass])
        {
           $repass=1;
        }
        $pat4='/^......../';
        if(!preg_match($pat4, $_REQUEST[pass]))
        {
           $epasslenth=1;
        }
        $pwd=$_REQUEST[pass];
        $pass1=$_REQUEST[repass];
        $pass2=strlen($pass1);
       
        
        for($i=0;$i<$pass2;$i++)
        {
            $abc=substr($pass1,$i);
            
            $ch=ord($abc);
       
            if($ch>=65 && $ch<=90)
            {
                $cap++;
            }
            elseif($ch>=97 && $ch<=122)
            {
                $sml++;
             
            }
            elseif($ch>=48 && $ch<=57)
            {
                $dg++;
          
            }
            else
            {
                $sp++;
          
            } 
        }
        if($cap==0 || $sml==0 || $dg==0 || $sp==0)
        {
           $epasscheck=1;
        }
        /*password end*/
        if($epass!=1 && $erepass!=1 && $epasscheck!=1 && $epasslenth!=1)
        {
            $in=mysql_query("update registration set password='$_REQUEST[pass]' where userid='$_SESSION[user]'");
            $up=mysql_query("update login set password='$_REQUEST[pass]' where userid='$_SESSION[user]'");
            //echo $in;
            //echo $up;
            header('location:dealerprofile.php#dealerprofile');
        }    
    }    
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'ucover.php';
          ?>
          <div class="adminright" id="cpass">
              <div class="cp">
                  <a href="dealerhome.php#dealerhome" style="color: white;">&vltri;</a>
              </div>
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;float: left;margin-top: 30px;height: 450px;width: 50px;margin-left: 100px;">
                  <br><br>c<br>h<br>a<br>n<br>g<br>e<br><br> p<br>a<br>s<br>s<br>w<br>o<br>r<br>d
              </div>
              <div class="contact-form" style="margin-left: 250px;">
                <form action="" method="post">
                    <table>
                        <tr>
                            <td>password :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input type="text" placeholder="Enter Password" value="<?php echo $a[12]; ?>" readonly="true"/>
                            </td>
                                
                        </tr>
                        <tr>
                            <td>new password :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="pass" type="password" placeholder="Enter New Password" />
                            </td>
                            <td>
                                <?php
                                    if($epass==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                    else
                                    {
                                        if($epasslenth==1 || $epasscheck==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                        
                                    }
                                ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>re-password :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <input name="repass" type="password" placeholder="Enter Re-Password" />
                            </td>
                            <td>
                                <?php
                                    if($erepass==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                    else
                                    {
                                        if($erepass1==1)
                                        {
                                            echo "<font color=red size=3px>^</font>";
                                        }
                                    }
                                ?>
                            </td>    
                        </tr>
                    </table>    
                    <div>
                                <button type="submit" class="feedbackbutton" name="submit2">apply change</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
			</div>
                    <font style="font-size: 10px;color: red;position: absolute;margin-top: -200px;">note : * blank | ^ invalid </font>
                </form>        
              </div>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>