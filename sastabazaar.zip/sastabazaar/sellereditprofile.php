<?php
    require_once 'conn.php';
    if(isset($_REQUEST[send1]))
    {
       $c=mysql_query("select * from country where countryid=$_REQUEST[country]");
       while($cc=  mysql_fetch_array($c))
       {
           $country=$cc[1];
       }
       $s=mysql_query("select * from state where stateid=$_REQUEST[state]");
       while($st=  mysql_fetch_array($s))
       {
           $state=$st[2];
       }
       $ci=mysql_query("select * from city where cityid=$_REQUEST[city]");
       while($cci=  mysql_fetch_array($ci))
       {
           $city=$cci[2];
       }
       if($_REQUEST[country]=='--Select--')
       {
           $ecountry=1;
       }
       if($_REQUEST[state]=='--Select--')
       {
           $estate=1;
       }
       if($_REQUEST[city]=='--Select--')
       {
           $ecity=1;
       }
       if($_REQUEST[address]=='')
       {
           $eaddress=1;
       }
       if($_REQUEST[email]=='')
       {
           $eemail=1;
       }
       $pat2='/^[0-9]+$/';
       $pat3='/^..........$/';
       if(!preg_match($pat2, $_REQUEST[mobile]) || !preg_match($pat3, $_REQUEST[mobile]) || $_REQUEST[mobile]=="")
       {
           $emobile=1;
       }
       
        /*file uploading*/
       
       $fname=$_FILES[userimg][name];
       $types=substr($_FILES[userimg][type],6);
       $siz=$_FILES[userimg][size];
       $siz=$siz/1024;
       $siz=$siz/1024;
       $ex=".".substr($_FILES[userimg][type],6);
       if($siz<=5)
       {
           if($ex==".jpg" || $ex==".jpeg")
           {
               $nwname=$_SESSION[user].$ex;
               $path1="profile/".$nwname;
               $path2=dirname(__FILE__)."/profile/".$nwname;
           }
           else
           {
               $er1=1;
           }
       }
       else
       {
           $er2=1;
       }
       
       /*file uploading end*/

       
       
       if($ecountry!=1 && $estate!=1 && $ecity!=1 && $eaddress!=1 && $eemail!=1 && $er1!=1 && $er2!=1)
       {
           $in=mysql_query("update registration set address='$_REQUEST[address]',email='$_REQUEST[email]', mobile='$_REQUEST[mobile]', country='$country',state='$state',city='$city',image='$path1' where userid='$_SESSION[user]'");
            //echo $in;
           move_uploaded_file($_FILES[userimg][tmp_name], $path2);
           
           
           header('location:sellerprofile.php#sellerprofile');
       }    
    }    
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
	<?php
        require_once 'updatescover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'scover.php';
          ?>
          <div class="adminright" id="editprofile">
              <div class="cp">
                  <a href="sellerhome.php#sellerhome" style="color: white;">&vltri;</a>
              </div>
              <div class="ep">
                  <br><br>e<br>d<br>i<br>t<br><br> p<br>r<br>o<br>f<br>i<br>l<br>e
              </div>
              <div class="contact-form" style="margin-left: 250px;">
                <form action="" method="post" enctype="multipart/form-data">  
                <table>
                    <tr>
                        <td>
                            profile :&nbsp;&nbsp;&nbsp;&nbsp;
                        </td>
                        <td>
                                <input type="file" name="userimg"/>
                        </td>
                        <td>
                                <?php
                                    if($er1==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                    elseif($er2==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                        </td>
                    </tr>
                    <tr>
                        <td>name :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td colspan="2">
                            <input type="text" placeholder="Your Name" value="<?php echo $a[1]; ?>" readonly="true"/>            
                        </td>    
                    </tr>
                    <tr>
                        <td>
                            <br>
                        </td>
                    </tr>
                    <tr>
                        <td style="vertical-align:top;">address :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td>
                            <textarea name="address" placeholder="Enter Message" ><?php echo $a[2]; ?></textarea>
                        </td>
                        <td>
                                <?php
                                    if($eaddress==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                        </td>    
                    </tr>
                    <tr>
                        <td>email :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td>
                            <input name="email" type="email" placeholder="Enter Email" value="<?php echo $a[4]; ?>" />
                        </td>
                        <td>
                                <?php
                                    if($eemail==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                        </td>
                    </tr>
                    <tr>
                        <td>mobile :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td>
                            <input name="mobile" maxlength="10" type="text" placeholder="Enter Mobile" value="<?php echo $a[5]; ?>" />
                        </td>
                        <td>
                                <?php
                                    if($emobile==1)
                                    {
                                        echo "<font color=red size=3px>*</font>";
                                    }
                                ?>
                        </td>    
                    </tr>
                    <tr>
                        <td>country :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                         <td colspan="2">
                            <select class="select" name="country" onchange="setstate(this.value)">
                                    <option>--Select--</option>
                                    <?php
                                        $data=  mysql_query("select * from country");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[0]?>"><?php echo $row[1]?></option>
                                    <?php
                                        }
                                    ?>
                             </select>
                                <?php
                                    if($ecountry==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>state :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td colspan="2">
                                <select class="select" name="state" id="state" onchange="setcity(this.value)">
                                   
                                </select>
                                <?php
                                    if($estate==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>city :&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td colspan="2">    
                                <select class="select" name="city" id="city">
                                    
                                </select>
                                <?php
                                    if($ecity==1)
                                    {
                                        echo "<font color=red size=3px>^</font>";
                                    }
                                ?>
                            </td>
                        </tr>    
                </table>
                <div>
                                <button type="submit" class="feedbackbutton" name="send1">apply change</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
			</div>
                    <font style="font-size: 10px;color: red;">note : * blank | ^ invalid </font>    
                </form>    
              </div>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>