<?php
    require_once 'conn.php';
    if(isset($_SESSION[user]))
    {
        if($_SESSION[type]!=3)
        {
            header('location:logout.php');
        }
    }
    else
    {
            header('location:logout.php');
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
        <?php
        require_once 'updatescover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'scover.php';
          ?>
          <div class="adminright" id="sellerhome">
             <div class="ht">
                  w&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;l&nbsp;&nbsp;&nbsp;&nbsp;c&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; s&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;l&nbsp;&nbsp;&nbsp;&nbsp;l&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;r&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e 
              </div><br>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          profile
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="sellerprofile.php#sellerprofile"><img src="images/contact.png" title="profile" width="140px"/></a>
                      </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          edit profile
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="sellereditprofile.php#editprofile"><img src="images/Contacts.png" title="edit profile" width="140px"/></a>
                      </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          change password
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="sellerchangepassword.php#cpass"><img src="images/feedback1.png" title="change password" width="140px"/></a>
                      </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          ad post
                      </div>
                      <div class="box" style="margin-left: 70px;">
                          <a href="selleradpost.php#sadpost"><img src="images/world.png" title="seller adpost" width="140px"/></a>
                      </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          view post
                      </div>
                      <div class="box">
                          <a href="sellerview.php#viewpost"><img src="images/world.png" title="view post" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(productid) from product where userid='$_SESSION[user]'");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          view commision
                      </div>
                      <div class="box">
                          <a href="commisionbill.php#commision"><img src="images/world.png" title="commision" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(productid) from product where userid='$_SESSION[user]'");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
        <div style="clear: both;">
            
        </div>
    </div>
    </div>        
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
