<?php
    require_once 'conn.php';
    if($_REQUEST[shu]=='country')
    {
        
?>

<th>name</th>
                                    <th>delete</th>
                                    <th>update</th>
                            
                                    <?php
                                        
                                        $data=mysql_query("select * from country where countryname like '%$_REQUEST[val]%'");
                                        while($row=mysql_fetch_array($data))
                                        {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=country"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>
                                        <td>
                                            <a href="upcountry.php?id=<?php echo $row[0]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                        </td>
                                    
                                    </tr>
                                    <?php
                                        }
    }
    if($_REQUEST[shu]=='state')
    {
                                    ?>
     <th>country name</th>
                            <th>state name</th>
                            <th>delete</th>
                            <th>update</th>
                            <?php
                                    $data=mysql_query("select * from state where statename like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        $g=mysql_query("select * from country where countryid=$row[0]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[1];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[1]; ?>&ek=state1"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                                <td>
                                    <a href="upstate.php?id=<?php echo $row[1]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='city')
    {
                            ?> 
                            <th>state name</th>
                            <th>city name</th>
                            <th>delete</th>
                            <th>update</th>
                            <?php
                                    $data=mysql_query("select * from city where cityname like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        $g=mysql_query("select * from state where stateid=$row[0]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[1]; ?>&ek=city"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                                <td>
                                    <a href="upcity.php?id=<?php echo $row[1]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='feedback')
    {
                            ?>  
                            <th>name</th>
                            <th>mobile</th>
                            <th>message</th>
                            <th>delete</th>
                            <?php
                                    $data=mysql_query("select * from feedback where feedname like '%$_REQUEST[val]%' or feedmsg like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=feedback"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>                                
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='contact')
    {
                            ?>
<th>name</th>
                            <th>email</th>
                            <th>mobile</th>
                            <th>message</th>
                            <th>delete</th>
                            <?php
                                    $data=mysql_query("select * from contact where conname like '%$_REQUEST[val]%' or conemail like '%$_REQUEST[val]%' or conmsg like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[4];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=contact"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='registration')
    {
                            ?>
                            <th>user type</th>
                            <th>name</th>
                            <th>address</th>
                            <th>gender</th>
                            <th>email</th>
                            <th>mobile</th>
                            <th>country</th>
                            <th>state</th>
                            <th>city</th>
                            <th>dob</th>
                            <th>user ID</th>
                            <th>images</th>
                            <th>password</th>
                            <th>question</th>
                            <th>answer</th>
                            <th>terms</th>
                            <th>delete</th>
                            <?php
                                $data=mysql_query("select * from registration where name like '%$_REQUEST[val]%' or usertype like '%$_REQUEST[val]%' or address like '%$_REQUEST[val]%' or email like '%$_REQUEST[val]%' or userid like '%$_REQUEST[val]%' or que like '%$_REQUEST[val]%' or ans like '%$_REQUEST[val]%'");
                                while($row=mysql_fetch_array($data))
                                {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[0];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[4];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[5];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[6];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[7];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[8];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[9];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[10];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[11];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[12];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[13];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[14];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[15];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=user"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                           <?php
                                }
    }
    if($_REQUEST[shu]=='email')
    {
        ?>
                            <th>email ID</th>
                                    <th>delete</th>
                                    <?php
                                            $no=$_REQUEST[base];
                                            $st=($no*$perpage)-$perpage;
                                            $data=mysql_query("select * from email where emailname like '%$_REQUEST[val]%'");
                                            while($row=mysql_fetch_array($data))
                                            {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=emaile"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>                                
                                    </tr>
                                    <?php
                                        }
    }
                           
    if($_REQUEST[shu]=='maincategories')
    {
                                    ?> 
     
     
                            <th>maincategories</th>
                                    <th>delete</th>
                                    <th>update</th>
                            
                                    <?php
                                        $data=mysql_query("select * from maincategories where maincatename like '%$_REQUEST[val]%'");
                                        while($row=mysql_fetch_array($data))
                                        {
                                    ?>
                                    <tr align="center">
                                        <td> 
                                            <?php
                                                echo $row[1];
                                            ?>
                                        </td>
                                        <td>
                                            <a href="delete.php?id=<?php echo $row[0]; ?>&ek=maincate"/><img src="images/delete1.png" title="delete one row"/></a>
                                        </td>
                                        <td>
                                            <a href="upmaincategories.php?id=<?php echo $row[0]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                        </td>
                                    
                                    </tr>
                                    <?php
                                        }
    }
    if($_REQUEST[shu]=='subcategories')
    {
                            ?>
                           <th>maincategories</th>
                            <th>subcategories</th>
                            <th>delete</th>
                            <th>update</th>
                            <?php
                                    $data=mysql_query("select * from subcategories where subcatename like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        $g=mysql_query("select * from maincategories where maincateid=$row[0]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[1];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[1]; ?>&ek=subcate"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                                <td>
                                    <a href="upsubcategories.php?id=<?php echo $row[1]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='company')
    {
                            ?> 
                            <th>subcategories</th>
                            <th>company</th>
                            <th>delete</th>
                            <th>update</th>
                            <?php
                                    $data=mysql_query("select * from company where companyname like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        $g=mysql_query("select * from subcategories where subcateid=$row[0]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[1]; ?>&ek=company"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                                <td>
                                    <a href="upcompany.php?id=<?php echo $row[1]; ?>"/><img src="images/update2.png" title="update one row" onclick="return confirm ('Are You Sure Want To Update ??');"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='product')
    {
                            ?>
<th>name</th>
                            <th>auction</th>
                            <th>items</th>
                            <th>type</th>
                            <th>company</th>
                            <th>item name</th>
                            <th>item discription</th>
                            <th>price</th>
                            <th>active/deactive</th>
                            <th>commision</th>
                            <th>delete</th>
                            <?php
                                $data=mysql_query("select * from product where userid like '%$_REQUEST[val]%' or auction like '%$_REQUEST[val]%' or productname like '%$_REQUEST[val]%' or productdiscription like '%$_REQUEST[val]%' or commision like '%$_REQUEST[val]%' or price like '%$_REQUEST[val]%'");
                                while($row=mysql_fetch_array($data))
                                {
                            ?>
                            <tr align="center">
                                <td>
                                    <?php
                                        echo $row[0];
                                    ?>
                                </td>
                                <td>
                                    <?php echo $row[1]; ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from maincategories where maincateid=$row[2]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[1];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from subcategories where subcateid=$row[3]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $g=mysql_query("select * from company where companyid=$row[4]");
                                        $gg=  mysql_fetch_array($g);
                                        echo $gg[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[6];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[7];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[8];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        if($row[9]==0)
                                        {
                                            echo "<font size='3' style='cursor:pointer;' onclick='slact($row[5]);'><img src='images/deactive.png' width='15px'/></font>";
                                        }
                                        else
                                        {
                                            echo "<font size='3' style='cursor:pointer;' onclick='slact($row[5]);'><img src='images/active.png' width='15px'/></font>";
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php echo $row[11]; ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=sadpost"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                           <?php
                                }
    }
    if($_REQUEST[shu]=='review')
    {
                            ?>
                            <th>name</th>
                            <th>review</th>
                            <th>active/deactive</th>
                            <th>date/time</th>
                            <th>delete</th>
                            <?php
                                    $data=mysql_query("select * from review where userid like '%$_REQUEST[val]%' or review like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        if($row[4]==0)
                                        {
                                            echo "<font size='3' color='red' style='cursor:pointer;' onclick='act($row[0]);'> &Del;</font>";
                                        }
                                        else
                                        {
                                            echo "<font size='3' color='green' style='cursor:pointer;' onclick='act($row[0]);'> &Delta;</font>";
                                        }
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[5];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=review"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='bill')
    {
                            ?>
                            <th>bill no</th>
                            <th>transaction date</th>
                            <th>user</th>
                            <th>amount</th>
                            <?php
                                    $data=mysql_query("select * from bill where userid like '%$_REQUEST[val]%' or amount like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[0];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[4];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[1];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                            </tr>
                            <?php
                                }
    }
    if($_REQUEST[shu]=='inquire')
    {
                            ?>
<th>name</th>
                            <th>email</th>
                            <th>mobile</th>
                            <th>need</th>
                            <th>delete</th>
                            <?php
                                    $data=mysql_query("select * from inquire where name like '%$_REQUEST[val]%' or email like '%$_REQUEST[val]%' or need like '%$_REQUEST[val]%'");
                                    while($row=mysql_fetch_array($data))
                                    {
                            ?>
                            <tr align="center">
                                <td> 
                                    <?php
                                        echo $row[2];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[3];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[4];
                                    ?>
                                </td>
                                <td> 
                                    <?php
                                        echo $row[5];
                                    ?>
                                </td>
                                <td>
                                    <a href="delete.php?id=<?php echo $row[0]; ?>&ek=inquire"/><img src="images/delete1.png" title="delete one row"/></a>
                                </td>
                            </tr>
                            <?php
                                }
    }
                            ?>