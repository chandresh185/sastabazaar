<?php
require_once 'conn.php';
    if(isset($_REQUEST[click]))
    {
        if($_REQUEST[name]=="")
        {
            $ename=1;
        }
        if($_REQUEST[mobile]=="")
        {
            $emobile=1;
        }
        if($_REQUEST[email]=="")
        {
            $eemail=1;
        }
        if($_REQUEST[need]=="")
        {
            $eneed=1;
        }
        $pname='/^[a-zA-Z ]+$/';
        if(!preg_match($pname, $_REQUEST[name]))
        {
            $ename2=1;
        }
        $pmobile='/^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]+$/';
        if(!preg_match($pmobile, $_REQUEST[mobile]))
        {
            $emobile2=1;
        }
        
         $y=date(Y);
       $m=date(m);
       $d=date(d);
      
       $dt=$y."/".$m."/".$d;
     
        if($ename!=1 && $emobile!=1 && $eemail!=1 && $eneed!=1 && $ename2!=1 && $emobile2!=1)
        {
            $in=mysql_query("insert into inquire values('$_REQUEST[id]',0,'$_REQUEST[name]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[need]','$dt')");
            //echo $in;
            $send=1;
        }
            
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
    <script type="text/javascript">
        $(".document").ready(function(){
            $(".ide1").hide();
            $(".idde").click(function(){
                $(".ide1").toggle(1000);  
            });
        });
        
        </script> 
	<?php
        require_once 'header.php';
        ?>
  		    <?php
                        require_once 'menu.php';
                    ?>
    </div>
</div>   
 <div class="main">
 	<div class="wrap">
            
            <div class="preview-page" style="font-size: 15px;"> 
                <h3><b style="font-size: 18px;color: #e44f2b;">I</b>nquire</h3>
                <div class="contact-form" style="float: left;">
		
		<form method="post" action="">
                    <table>
                        <tr>
                            <td colspan="2">
                                <?php
                                    if($send==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">send successfully</font>';
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input name="name" type="text" placeholder="Enter Name" />
                            </td>
                            <td>
                            <?php
                                if($ename==1)
                                {
                                    echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                }
                                else
                                {
                                    if($ename2==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                    }
                                }
                            ?>
                            </td>    
                        </tr>
                        <tr>
                            <td>
                                <input name="mobile" maxlength="10" type="text" placeholder="Enter Mobile" />
                            </td>
                            <td>
                                <?php
                                    if($emobile==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                    }
                                    else
                                    {
                                        if($emobile2==1)
                                        {
                                            echo '<font color=red size=2 style="text-transform:capitalize ">^</font>';
                                        }
                                    }
                                ?>
                            </td>
                        </tr>
                        <tr>
                              <td>
                                <input name="email" type="email" placeholder="Enter Email"/>
                              </td>
                              <td>
                               <?php
                                    if($eemail==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                    }
                                ?>
                              </td>
                        </tr>
                        <tr>
                            <td>
                                <span><textarea name="need" placeholder="Enter Your Need For This Product" ></textarea></span>
                            </td>
                            <td>
                                <?php
                                    if($eneed==1)
                                    {
                                        echo '<font color=red size=2 style="text-transform:capitalize ">*</font>';
                                    }
                                ?>
                            </td>
                        </tr>
                    </table>
                        <div class="clear"></div>
                        <div>
                           
                                <button type="submit" class="feedbackbutton" name="click">submit</button>
                                <button type="reset" class="feedbackbutton" name="clear">clear</button>
                                <div class="clear"></div>
			</div>
                        <font style="font-size: 10px;color: red;">note : * blank | ^ invalid </font>
		</form>
                </div>
                <div class="ide" style="float: left;margin-top: 25px;">
                    <?php
                        $tg=  mysql_query("select productimage from product_mstr2 where productid='$_REQUEST[id]'");
                        $tgg=  mysql_fetch_array($tg);
                    ?>
                    <img src="<?php echo $tgg[0]; ?>" width="215px" height="315px" style="border-radius:10px;"/>
                </div> 
                 <?php
                                                    $dat=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                                    $r=mysql_fetch_array($dat);
                                                    
                                              ?>
                <div class="idde">
                    <center>product detail</center>
                </div>    
                <div class="ide1">
                    <div class="ide2" >
                        <table width="100%">
                            <tr>
                                <td width="25%">name :</td>
                                <td><?php echo $r[0]; ?></td>
                            </tr>
                            <tr>
                                <td>contact :</td>
                                <td>
                                    <?php
                                        $r1=mysql_query("select * from registration where userid='$r[0]'");
                                        $rr=  mysql_fetch_array($r1);
                                        echo $rr[5]; 
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td>email :</td>
                                <td><?php echo $rr[4]; ?></td>
                            </tr>
                            <tr>
                                <td>city :</td>
                                <td><?php echo $rr[8]; ?></td>
                            </tr>
                            <tr>
                                <td>price :</td>
                                <td>10000</td>
                            </tr>
                            <tr>
                                <td colspan="2"><center><a href="productdetail.php?id=<?php echo $r[5]; ?>#prodetail">if you want to show more detail click here</a></center></td>
                            </tr>
                        </table>
                    </div>
                </div>    
                <div style="clear: both;">
                    
                </div>
                
            </div>
            
         </div>     
    </div>
 </div>
   <?php
        require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
         <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

