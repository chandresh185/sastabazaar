
<div class="adminleft" >
              
              
              <center><p>&nbsp;&nbsp;<b style="color: #e44f2b;font-size: 18px;">W</b>elcome Mr.&nbsp;/&nbsp;Mrs.<br>
              <?php
                    $im=  mysql_query("select image from registration where userid='$_SESSION[user]'");
                    $imm=  mysql_fetch_array($im);
                
              ?>
              &nbsp;&nbsp;&nbsp;<img src="<?php echo $imm[0]; ?>" width="130px" height="130px" style="border-radius:100px;border: 2px solid #e44f2b;"/>        
              <?php
                $in=  mysql_query("select * from registration where userid = '$_SESSION[user]'");
                $a=  mysql_fetch_array($in);
                echo $a[1];
              ?></p></center>
                <ul>
                    <li><a href="sellerhome.php#sellerhome">dashboard</a></li>
                    <li><a href="sellerprofile.php#sellerprofile">Profile</a></li>     
                    <li><a href="sellereditprofile.php#editprofile">Edit Profile</a></li> 
                    <li><a href="sellerchangepassword.php#cpass">Change Password</a></li>
                    <li><a href="selleradpost.php#sadpost">Ad Post</a></li>
                    <li><a href="sellerview.php#viewpost">View Post</a></li>
                    <?php
                            $in3=  mysql_query("select * from product where active='1' and userid='$_SESSION[user]'");
                            $inn3=  mysql_fetch_array($in3);
                            if($inn3[9]==1)
                            {
                          ?>
                    <li><a href="commisionbill.php#commision">View Commision</a></li>
                    <?php
                            }
                    ?>
                </ul>
          </div>