<?php
    require_once 'conn.php';
    
    $ck=0;
    if(isset($_REQUEST[next1]))
    {
        $ck=1;
        $_SESSION[add]=$_REQUEST[address];
    }
    if(isset($_REQUEST[pre1]))
    {
        $ck=0;
    }
    if(isset($_REQUEST[next2]))
    {
        if($_REQUEST[card]=="cash on delivery")
        {
            $_SESSION[mt]="cod";
        }
        else
        {
            $_SESSION[mt]="card";
        }
        $_SESSION[mv]=$_REQUEST[card];
        $ck=2;
    }
    if(isset($_REQUEST[pre2]))
    {
        $ck=1;
    }
//    if(isset($_REQUEST[pay]))
//    {
//        header('location:pay.php');
//    }
    
    /*capcha*/
    if(isset($_REQUEST[pay]))
    {    
       if(strlen($_REQUEST[capcha])!=5)
        {
            $cap=1;
            $ck=2;
        }
        else
        {
            for($i=0;$i<=strlen($_REQUEST[capcha])-1;$i++)
            {
                if($i==0)
                {
                    $e1=substr($_REQUEST[capcha],$i,1);
                }
                if($i==1)
                {
                    $e2=substr($_REQUEST[capcha],$i,1);
                }
                if($i==2 || $i==3)
                {
                    $e3=$e3.substr($_REQUEST[capcha],$i,1);
                }
                if($i==4)
                {
                    $e4=substr($_REQUEST[capcha],$i,1);
                }
            }
            if($e1==$_SESSION[ek] && $e2==$_SESSION[be] && $e3==$_SESSION[chothi] && $e4==$_SESSION[tran])
            {
                
            }
            else
            {
                $cap=1;
                $ck=2;
            }
           
        }
        if($cap!=1)
        {    
            header('location:pay.php');
            
        }
    }   
       /*end capcha*/
        
    
    
    
       
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body onload="ref1();">
    <script type="text/javascript">
            $(document).ready(function(){
                $("#two").hide();
                $("#three").hide();
                <?php
                    if($ck==0)
                    {
                ?>
                    $("#one").show();
                    $("#two").hide();
                    $("#three").hide();
                    <?php
                    }
                    if($ck==1)
                    {
                    ?>
                            $("#one").hide();
                            $("#two").show();
                            $("#three").hide();
                            <?php
                            }
                            if($ck==2)
                            {
                            ?>
                                    $("#one").hide();
                                    $("#two").hide();
                                    $("#three").show();
                            <?php
                            }
                            ?>
            });
        </script>    
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
  <div class="main">
      <div class="content">
    	        <div class="content_top">
    	        	<div class="wrap">
		          	   <h3>Latest Products</h3>
		          	</div>
		          	<div class="line"> </div>
		          	<div class="wrap">
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="5">
			                <div class="ocarousel_window">
			                   <a href="#" title="laptop"> <img src="images/laptop.jpg" alt="" title="laptop" /><p>laptop</p></a>
			                   <a href="#" title="car1"> <img src="images/car1.jpg" alt="" title="car" /><p>car</p></a>
			                   <a href="#" title="furniture"> <img src="images/furniture.jpg" alt="" title="furniture" /><p>furniture</p></a>
			                   <a href="#" title="watch1"> <img src="images/watch1.jpg" alt="" title="watches" /><p>watches</p></a>
			                   <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
			                   <a href="#" title="gt"> <img src="images/gt.jpg" alt="" title="toys & game" /><p>toys & games</p></a>
			                   <a href="#" title="bike1"> <img src="images/bike1.jpg" alt="" title="bike" /><p>bike</p></a>
			                   <a href="#" title="job1"> <img src="images/job1.jpg" alt="" title="job" /><p>jobs</p></a>
			                   <a href="#" title="com1"> <img src="images/com1.jpg" alt="" title="computer" /><p>computer</p></a>
                                           <a href="#" title="house1"> <img src="images/house1.jpg" alt="" title="house" /><p>house</p></a>
                                        </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" style="float: left;" class="prev"> </a>
			                <a href="#" data-ocarousel-link="right" style="float: right;" class="next"> </a>
			               </span>
					   </div>
				     </div>  
				   </div>    		
    	       </div>
                <div class="content_bottom" style="padding: 10px;">
                    <?php
                        $r=  mysql_query("select name,email,address,city,mobile from registration where userid='$_SESSION[user]'");
                        $rr=  mysql_fetch_array($r);
                    ?>
                        <div class="paybox" >
                            <form method="post" action="">
                                <table id="one">
                                    <tr>
                                        <td colspan="3">
                                            <b style="color: #e44f2b;font-size: 25px;">S</b>hipping <b style="color: #e44f2b;font-size: 25px;">A</b>ddress . . <b style="color: #e44f2b;font-size: 20px;">!</b> 
                                        </td>
                                    </tr>    
                                    <tr>
                                        <td colspan="3">
                                            <div class="pline"></div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <br>
                                            <input name="name" type="text" readonly="true" placeholder="Enter Name" value="<?php echo $rr[0]; ?>"/>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <br>
                                            <input name="email" type="email" readonly="true" placeholder="Enter Email" value="<?php echo $rr[1]; ?>"/>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <br>
                                            <textarea name="address" placeholder="Enter Address" style=""><?php echo $rr[2]; ?></textarea>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <br>
                                            <input name="city" type="text" readonly="true" placeholder="Enter City" value="<?php echo $rr[3]; ?>" />
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <br>
                                            <input name="mobile" type="email" readonly="true" placeholder="Enter Mobile" value="<?php echo $rr[4]; ?>" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <br><input type="checkbox" name="term" checked="true" disabled="true" style="margin-left: -80px;" />
                                            <font style="font-size: 15px;margin-left: -80px;">This is my billing address</font>
                                        </td>            
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <br>
                                        </td>
                                    </tr>    
                                    <tr>
                                        <td colspan="2">
                                            <div class="pemail">
                                                <form>
                                                    <table width="100%">
                                                        <th>
                                                            <input type="checkbox" name="term" style="margin-left: -150px;"/>&nbsp;&nbsp;<font style="margin-left: -80px;">Send Me Email For Order</font>
                                                        </th>
                                                        <tr>
                                                            <td>
                                                                <br><input name="email" readonly="true" type="email" placeholder="Enter Email"  style="padding: 7px;width: 280px;"/>
                                                            </td>
                                                        </tr>
                                                            
                                                    </table>
                                                </form>    
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <br><button type="submit" name="next1" id="next1" class="next1">Next&nbsp;&vrtri;</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                        <div class="paybox" >
                            <form method="post" action="">
                                <table id="two">
                                    <tr>
                                        <td colspan="3">
                                            <b style="color: #e44f2b;font-size: 25px;">P</b>ayment <b style="color: #e44f2b;font-size: 25px;">T</b>ype . . <b style="color: #e44f2b;font-size: 20px;">!</b> 
                                        </td>
                                    </tr>    
                                    <tr>
                                        <td colspan="3">
                                            <div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><input type="radio" name="card" value="credit/debit" checked="" style="margin-left: -80px;" />&nbsp;<font style="margin-left: -80px;">Credit&nbsp;/&nbsp;Debit Cart&nbsp;&nbsp;</font>    
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><img src="images/cash8.png" width="90px" style="margin: 2px;margin-left: 45px;"/>
                                            <img src="images/footer/master.png" width="90px" style="margin: 2px;"/>
                                            <img src="images/footer/visa.png" width="90px" style="margin: 2px;"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"><br>
                                            <div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br>
                                        </td>
                                    </tr>    
                                    <tr>
                                        <td colspan="3">
                                            <input type="radio" name="card" value="cash on delivery" style="margin-left: -80px;" />&nbsp;<font style="margin-left: -80px;">Cash On Delivery &nbsp;(COD)&nbsp;</font>    
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><img src="images/cash4.jpg" width="90px" style="margin: 2px;margin-left: 45px;"/>
                                            <img src="images/cash2.jpg" width="90px" style="margin: 2px;"/>
                                            <img src="images/cash7.jpg" width="90px" style="margin: 2px;"/>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td style="font-size: 10px;color: red;" colspan="3"><br>Available Only For India</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"><br>
                                            <div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <br><button type="submit" name="pre1" id="pre1" class="pre1">&vltri;&nbsp;Previous</button>
                                        </td>
                                        <td colspan="2">
                                            <br><button type="submit" name="next2" id="next2" class="next2" >Next&nbsp;&vrtri;</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                        <div class="paybox">
                            
                            <form method="post" action="">
                                <table id="three">
                                    
                                    <tr>
                                        <td colspan="3">
                                            <b style="color: #e44f2b;font-size: 25px;">P</b>ayment <b style="color: #e44f2b;font-size: 25px;">D</b>etail . . <b style="color: #e44f2b;font-size: 20px;">!</b> 
                                        </td>
                                    </tr>    
                                    <tr>
                                        <td colspan="3">
                                            <div class="pline"></div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td>
                                            <br>Product Name 
                                        </td>
                                        <td>
                                            <br>Qty 
                                        </td>
                                        <td>
                                            <br>Rs. 
                                        </td>
                                    </tr>
                                    <?php
                                        $pa=  mysql_query("select p.productname,c.qty,c.total from product p,cart c where p.productid=c.productid and c.userid='$_SESSION[user]'");
                                        while($ppa=  mysql_fetch_array($pa))
                                        {  
                                    ?>
                                    <tr>
                                        <td>
                                            <br><?php echo $ppa[0]; ?>
                                        </td>
                                        <td>
                                            <br><?php echo $ppa[1]; ?>
                                        </td>
                                        <td>
                                            <br><?php echo $ppa[2]; ?>
                                        </td>
                                    </tr>
                                    <?php
                                            $tot=$tot+$ppa[2];
                                        }
                                    ?>
                                    <tr>
                                        <td colspan="3">
                                            <br><div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr style="text-align: right;">
                                        <td colspan="3">
                                            <br>Subtotal : <?php echo $_SESSION[hardik]; ?> Rs.<br>
                                            <?php
                                                $sh=  mysql_query("select country from registration where userid='$_SESSION[user]'");
                                                $shh=  mysql_fetch_array($sh);
                                                if(stristr($shh[0],'india'))
                                                {
                                                    $_SESSION[sp]=100;
                                                }       
                                                else
                                                {
                                                    $_SESSION[sp]=700;
                                                }
                                            ?>
                                        
                                            <br>Shippingcharge : (+)<?php echo $_SESSION[sp]; ?> Rs.
                                        </td>    
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr style="text-align: right;">
                                        <td colspan="3">
                                            <br>You Pay : <?php echo $_SESSION[hardik]+$_SESSION[sp]; ?> Rs.
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><div class="pline"></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <center><br>
                                            <div id="pcapid" class="ppay" style="background-image: url(images/capcha.jpg);">
                                                
                                            </div>
                                           </center> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <div style="float: left;text-transform: none;">
                                                <input type="text" name="capcha" placeholder="Type hear what you see.."  style="width:150px;padding: 5px;margin-left: 120px;margin-top: 10px;">
                                                <?php
                                                    if($cap==1)
                                                    {
                                                        echo "<font color=red>*</font>";
                                                    }
                                                ?>
                                            </div>
                                            <div style="margin-top: -20px;margin-left: 297px;">
                                                <img src="images/update2.png" style="margin-top: 30px;width: 25px;" onclick="ref1();"/>
                                            </div>
                                        </td>    
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <br><button type="submit" name="pay" id="pay" class="pay">&nbsp;Pay Security</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <br><button type="submit" name="pre2" id="pre2" class="pre2" >&vltri;&nbsp;Previous</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                        <div class="clear"></div>
                </div>
         </div>
      </div>
   <?php
            require_once 'footer.php';
   ?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

