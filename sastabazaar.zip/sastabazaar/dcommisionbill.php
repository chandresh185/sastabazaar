<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>   
        <script type="text/javascript">
            function printdiv()
            {
                var p=document.getElementById('print');
                var pp=window.open("","_blank");
                
                pp.document.open();
                pp.document.write('<html><body onload="window.print()">'+p.innerHTML+'</html>');
                pp.document.close();
            }
        </script>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
        <?php
            require_once 'ucover.php';
        ?>
          <div class="adminright" id="dcommision">
              <div class="cp">
                  <a href="dealerhome.php#dealerhome" style="color: white;">&vltri;</a>
              </div>
              <div style="background: #e44f2b;text-align: center;font-size: 20px;position: relative;text-transform: uppercase;color: white;border-radius:50px 50px 5px 5px;float: left;margin-top: 30px;height: 520px;width: 50px;margin-left: 100px;">
                  <br><br>c<br>o<br>m<br>m<br>i<br>s<br>i<br>o<br>n<br><br> o<br>f<br><br> p<br>o<br>s<br>t
              </div>
              <div style="margin-left: 240px;width: 1010px;padding: 10px;" id="print">
                  <?php
                            $in3=  mysql_query("select * from product where active='1' and userid='$_SESSION[user]'");
                            while($inn3=  mysql_fetch_array($in3))
                            {    

                          ?>
                  <div class="com1">
                      <?php
                                                $p=mysql_query("select * from product_mstr2 where  productid='$inn3[5]'");
                                                $pp= mysql_fetch_array($p);
                                            ?>
                      <img src="<?php echo $pp[2]; ?>" width="200px" height="270px"/>
                  </div>
                  <div class="com">
                      <table width="100%">
                          <th colspan="2">
                                <center>Commision</center>
                          </th>
                          <tr>
                              <td>Name :</td>
                              <td><?php echo $inn3[0]; ?></td>
                          </tr>
                          <tr>
                              <td>Items Name :</td>
                              <td><?php echo $inn3[6]; ?></td>
                          </tr>
                          <tr>
                              <td>Price :</td>
                              <td><?php echo $inn3[8]; ?></td>
                          </tr>
                          <tr>
                              <td>Commision :</td>
                              <td>1%</td>
                          </tr>
                          <tr>
                              <td>Total Price :</td>
                              <td><?php echo $inn3[11]; ?></td>
                          </tr>
                          <tr>
                              <td colspan="2">
                                    <center><button onclick="printdiv();" >print</button></center>
                              </td>
                          </tr>
                      </table>
                      <div  style="margin-top: -287px;margin-left: 197px;width: 25px;">
                          <img src="images/del.png" width="25px"/>
                      </div>
                  </div>
                  <?php
                            }
                  ?>
                    
                  <div style="clear: both;">
                      
                  </div>
              </div>
         </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>
