<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'penal.php';
?>
<?php
    require_once 'head.php';
?>
<body>
        <?php
        require_once 'updatecover.php';
        ?>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
              <div class="managedashboard" id="dash">
              <div class="ht">
                  w&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;l&nbsp;&nbsp;&nbsp;&nbsp;c&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a&nbsp;&nbsp;&nbsp;&nbsp;d&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;i&nbsp;&nbsp;&nbsp;&nbsp;n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h&nbsp;&nbsp;&nbsp;&nbsp;o&nbsp;&nbsp;&nbsp;&nbsp;m&nbsp;&nbsp;&nbsp;&nbsp;e 
              </div><br>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total country
                      </div>
                      <div class="box">
                          <a href="managecountry.php?base=1#country"><img src="images/world.png" title="country" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(countryid) from country");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total state
                      </div>
                      <div class="box">
                          <a href="managestate.php?base=1#state1"><img src="images/state.png" title="state" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(stateid) from state");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total city
                      </div>
                      <div class="box">
                          <a href="managecity.php?base=1#city1"><img src="images/realestate.png" title="city" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(cityid) from city");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total feedback
                      </div>
                      <div class="box">
                          <a href="managefeedback.php?base=1#feed"><img src="images/feed.png" title="feedback" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(feedid) from feedback");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total contact
                      </div>
                      <div class="box">
                          <a href="managecontact.php?base=1#contact"><img src="images/contact.png" title="contact us" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(conid) from contact");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total user
                      </div>
                      <div class="box">
                          <a href="manageuser.php?base=1#user"><img src="images/user.png" title="user" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(usertype) from registration");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total email
                      </div>
                      <div class="box">
                          <a href="manageemail.php?base=1#emaile"><img src="images/emailsub.png" title="email" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(eid) from email");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total maincategories
                      </div>
                      <div class="box">
                          <a href="managemaincategories.php?base=1#maincate"><img src="images/subcategory.png" title="maincategories" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(maincateid) from maincategories");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div> 
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total subcategories
                      </div>
                      <div class="box">
                          <a href="managesubcategories.php?base=1#subcate"><img src="images/subcategory.png" title="subcategories" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(subcateid) from subcategories");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total company
                      </div>
                      <div class="box">
                          <a href="managecompany.php?base=1#company"><img src="images/subcategory.png" title="company" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(companyid) from company");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total adpost
                      </div>
                      <div class="box">
                          <a href="manageselleradpost.php?base=1#sadpost"><img src="images/user.png" title="seller adpost" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(productid) from product");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total bill
                      </div>
                      <div class="box">
                          <a href="showbill.php?base=1#bil"><img src="images/user.png" title="bill" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(billid) from bill");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total review
                      </div>
                      <div class="box">
                          <a href="managereview.php?base=1#review"><img src="images/user.png" title="review" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(reviewid) from review");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total transaction
                      </div>
                      <div class="box">
                          <a href="managetransaction.php?base=1#tran"><img src="images/user.png" title="transaction" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(traid) from tra");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>    
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total summary report
                      </div>
                      <div class="box">
                          <a href="managereport.php?base=1#report"><img src="images/user.png" title="summary report" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(billid) from bill");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          total inquire
                      </div>
                      <div class="box">
                          <a href="manageinq.php?base=1#inquire"><img src="images/user.png" title="inquire" width="140px"/></a>
                      </div>    
                        <?php
                            $in=  mysql_query("select count(inquireid) from inquire");
                            $a=mysql_fetch_array($in);
                        ?>
                  <div style="text-align: center;font-size: 50px;margin-top: 35px;">
                      <?php
                        echo $a[0];
                      ?>
                  </div>
              </div>
              <div class="dashboard">
                      <div style="background: #23272a;color: white;padding: 10px;text-align: center;text-transform: capitalize;">
                          chart
                      </div>
                      <div class="box">
                          <a href="graph.php?base=1#grapha"><img src="images/contact.png" title="contact us" width="140px" style="margin-left: 75px;"/></a>
                      </div>    
              </div>    
          </div>
        <div style="clear: both;">
            
        </div>
    
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>    