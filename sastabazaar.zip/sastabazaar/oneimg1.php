<?php
    require_once 'conn.php';
    $data=mysql_query("select * from product where productid='$_REQUEST[id]'");
                                        while($row1= mysql_fetch_array($data))
                                        {
                                            $c=0;
                                            $data1=mysql_query("select * from product_mstr2 where productid='$row1[4]'");
                                            while($row2= mysql_fetch_array($data1))
                                            {
                                                $c++;
                                                if($c==1)
                                                {
                                                    ?>
                                                <center><img id="mjimg1" class="i1" src="<?php echo $row2[2]; ?>"/></center>
                        
                        <?php
                                                }
                                                if ($c!=0)
                                                {
                        ?>
                        <div style="display: inline;">
                            <img src="<?php echo $row2[2]; ?>"  style="width: 100px;height: 100px;border-radius:5px;margin-top: 10px;" onclick="mjj();"/>
                        </div>     
                        <?php
                                                }
                                            }
                                        }
                       ?>