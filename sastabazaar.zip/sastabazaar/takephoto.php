

<center><img id="mjimg1" class="i1" src="<?php echo $_REQUEST[ky]; ?>"/></center>