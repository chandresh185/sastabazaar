<?php
    require_once 'conn.php';

                $gb=  mysql_query("select * from bill");
                while($row=  mysql_fetch_array($gb))
                {
                    $t=$row[4];
                    $t=substr($t,0,4);
                
                    if($_REQUEST[ye] <= $t && $_REQUEST[ye1] >= $t)
                    {
                       
                        $rg=  mysql_query("select name from registration where userid='$row[1]'");
                        $rgg=  mysql_fetch_array($rg);
                        $pd=  mysql_query("select * from tra where billid='$row[0]'");
                        
                    ?>
                        <div style="border-radius:5px;border: 1px solid #e44f2b;">  
                  <table width="100%" style="">
                      <tr>
                          <td colspan="4" align="center" style="padding: 10px;">
                              <img src="images/shree.png" width="130px"/>
                          </td>
                      </tr>
                      <tr>
                          <td colspan="2" > 
                              <div style="float: left;">
                                  <img src="images/ek1.png" width="200px" />
                              </div>
                              <div style="margin-left: 650px;">
                                  <font style="font-size: 15px;">
                                  <br><b style="color: #e44f2b;font-size: 20px;">T</b>oll <b style="color: #e44f2b;font-size: 20px;">F</b>ree&nbsp;&nbsp;<b style="color:#e44f2b;">:</b>&nbsp;&nbsp;1800-100-5000<br><br>
                                  <b style="color: #e44f2b;font-size: 20px;">E</b>mail&nbsp;&nbsp;<b style="color:#e44f2b;">:</b>&nbsp;&nbsp;SastaBazaarbechde@gmail.com
                                  </font>
                              </div>   
                          </td>
                      </tr>
                      <tr>
                          <td colspan="4" style="padding: 5px;font-size: 15px;">
                              <table width="100%">
                                  <tr>
                                      <td rowspan="2" style="background: #e44f2b;color: #23272a;padding: 10px;border: 1px solid #23272a;">Name :<br><br> Add :</td>
                                      <td rowspan="2" style="background: #e44f2b;color: #23272a;padding: 10px;border: 1px solid #23272a;"><?php echo $rgg[0]; ?><br><br><?php echo $row[7]; ?></td>
                                      <td rowspan="2" style="background: #e44f2b;color: #23272a;padding: 10px;border: 1px solid #23272a;">Bill No :<br><br> Date :</td>
                                      <td rowspan="2" style="background: #e44f2b;color: #23272a;padding: 10px;border: 1px solid #23272a;"><?php echo $row[0]; ?><br><br><?php echo $row[4]; ?></td>
                                  </tr>
                              </table>
                          </td>
                      </tr>
                      <tr>
                          <td colspan="4" style="padding: 5px;font-size: 15px;">
                              <table width="100%">
                                  <tr>
                                      <th style="border: 1px solid #e44f2b;background: #23272a;color: white;padding: 10px;"><b style="color:#e44f2b;font-size: 16px;">N</b>o</th>
                                      <th style="border: 1px solid #e44f2b;background: #23272a;color: white;padding: 10px;"><b style="color:#e44f2b;font-size: 16px;">P</b>roduct Name</th>
                                      <th style="border: 1px solid #e44f2b;background: #23272a;color: white;padding: 10px;"><b style="color:#e44f2b;font-size: 16px;">Q</b>ty</th>
                                      <th style="border: 1px solid #e44f2b;background: #23272a;color: white;padding: 10px;"><b style="color:#e44f2b;font-size: 16px;">A</b>mount</th>
                                  </tr>
                                  <?php 
                                        $t=0;
                                        while($td=mysql_fetch_array($pd))
                                        {    
                                            $t++;
                                            $pn=  mysql_query("select productname from product where productid=$td[2]");
                                            $pnn=  mysql_fetch_array($pn);
                                  ?>
                                  <tr>
                                      <td align="center" style="border: 1px solid #e44f2b;"><?php echo $t; ?></td>
                                      <td align="center" style="border: 1px solid #e44f2b;"><?php echo $pnn[0]; ?></td>
                                      <td align="center" style="border: 1px solid #e44f2b;"><?php echo $td[4]; ?></td>
                                      <td align="center" style="border: 1px solid #e44f2b;"><?php echo $td[5]; ?></td>
                                  </tr>
                                  <?php
                                        }
                                  ?>
                              </table>
                          </td>
                      </tr>
                      <tr>
                          <td colspan="4">
                              <table width="100%" style="border: 1px solid #23272a;">
                                  <tr>
                                      <td align="right" style="font-size: 16px;">Amount : <?php echo $row[2]; ?>&nbsp;&nbsp;<b style="color:#e44f2b;">&#8377;</b></td>
                                  </tr>
                              </table>
                          </td>
                      </tr>
                      <tr>
                          <td colspan="4">
                              <table width="100%">
                                  <tr>
                                      <td colspan="2" align="left" style="border: 1px solid #23272a;">
                                          <div style="float:left;">
                                              <font style="font-size: 15px;"><b style="color:#e44f2b;font-size: 20px;">D</b>eclaration :<br>
                                            <br><b style="color:#e44f2b;font-size: 15px;">1)</b> . Product once sold will not be taken back. 
                                            <br><b style="color:#e44f2b;font-size: 15px;">2)</b> . Product has been delivery from above address.
                                            <br><b style="color:#e44f2b;font-size: 15px;">3)</b> . We are not responsible for any kind of physical/burn damage after delivery.
                                            <br><b style="color:#e44f2b;font-size: 15px;">4)</b> . Your shipping charge is include in your payable amount.
                                            </font>
                                            <form method="post" action="">
                                            <br><button type="submit" class="feedbackbutton" onclick="printdiv();">Print</button>
                                            </form>
                                          </div>
                                          <div style="margin-left: 750px;">
                                              <font style="font-size: 15px;">
                                              <br><img src="images/namelogo1.png" width="100px"/>
                                              <br><br>for&nbsp;&nbsp;<b style="color:#e44f2b;font-size: 20px;">S</b>ignature,
                                              <br><br><img src="images/namelogo1.png" width="100px" />
                                              </font>
                                          </div>
                                            
                                      </td>
                                  </tr>
                              </table>
                          </td>
                      </tr>
                  </table>
                </div>
<?php
                    }
                
                
            }    
    
    
?>
