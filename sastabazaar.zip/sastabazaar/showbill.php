<?php
    require_once 'conn.php';
?>
<!DOCTYPE HTML>
<?php
    require_once 'penal.php';
?>
<?php
    require_once 'head.php';
?>
<body onload="adminb();">
    <script>
        $(".document").ready(function(){
            $(".bpenal").hide();
            $(".bbutton").click(function(){
                $(".bpenal").toggle(1000);  
            });
        });
        
    </script>
	<?php
        require_once 'header.php';
        ?>
  	<?php
        require_once 'menu.php';
        ?>
            </div>
          </div>
          <?php
              require_once 'cover.php';
          ?>
          <div class="sb" id="bil">
              <h3>view bill
              <div style="float: right;margin-right: 20px;">
                  <?php
                        $g=  mysql_query("select count(billid) from bill");
                        $gg=  mysql_fetch_array($g);
                        echo "total bill are : ".$gg[0];
                  ?>
              </div>
              </h3><br>
              <div class="bbutton">
                      <button type="submit" name="bill">Bill Search</button>
              </div>
              <div class="bpenal">
                  <div class="bpenal1">
                      <table>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">B</b>uyer&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="ubill(this.value);">
                                      <option>--select--</option>
                                      <?php
                                            $u=  mysql_query("select distinct(userid) from bill");
                                            while($uu=  mysql_fetch_array($u))
                                            {
                                      ?>
                                      <option value="<?php echo $uu[0]; ?>"><?php echo $uu[0]; ?></option>

                                      <?php
                                            }
                                      ?>
                                    </select>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">B</b>ill <b style="color: #e44f2b;font-size: 17px;">N</b>o&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="bon(this.value);">
                                      <option>--select--</option>
                                      <?php
                                            $b=  mysql_query("select billid from bill");
                                            while($bi=  mysql_fetch_array($b))
                                            {
                                      ?>
                                      <option value="<?php echo $bi[0]; ?>"><?php echo $bi[0]; ?></option>

                                      <?php
                                            }
                                      ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">C</b>ountry&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="setconbill(this.value);">
                                    <option>--select--</option>
                                    <?php
                                        $data=  mysql_query("select * from country");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[1];?>"><?php echo $row[1];?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">S</b>tate&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="setstabill(this.value);">
                                      <option>--select--</option>
                                    <?php
                                        $data=  mysql_query("select * from state");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[2]?>"><?php echo $row[2]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">C</b>ity&nbsp;:&nbsp;</td>
                              <td>
                                  <select style="padding: 5px;" onchange="setcitybill(this.value);">
                                      <option>--select--</option>
                                    <?php
                                        $data=  mysql_query("select * from city");
                                        while($row=  mysql_fetch_array($data))
                                        {
                                    ?>
                                    <option value="<?php echo $row[2]?>"><?php echo $row[2]?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                              </td>    
                          </tr>
                      </table>
                  </div>
                  <div class="bpenal3">
                      <table>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">A</b>mount&nbsp;&nbsp;:&nbsp;</td>
                              <td>
                                    <input type="text" name="lp" style="padding: 5px;width: 74px;" id="lp"/>
                                    <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                    <input type="text" name="hp" style="padding: 5px;width: 74px;" id="hp"/>
                                    <img src="images/update2.png" width="20px" style="vertical-align: middle;" onclick="lphp1(document.getElementById('lp').value,document.getElementById('hp').value);"/>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>    
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">D</b>ate&nbsp;:&nbsp;</td>
                              <td>
                                  <input type="text" name="date" style="padding: 5px;width: 74px;" id="dt"/>
                                  <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                 <input type="text" name="date" style="padding: 5px;width: 74px;" id="dt1"/> 
                                <img src="images/update2.png" width="20px" style="vertical-align: middle;" onclick="dtdt1(document.getElementById('dt').value,document.getElementById('dt1').value);"/>
                              </td>    
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">M</b>onth&nbsp;:&nbsp;</td>
                              <td>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mn1"/>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mn2"/>
                                  <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mn3"/>
                                  <input type="text" name="month" style="padding: 5px;width: 30px;" id="mn4"/>
                                  <img src="images/update2.png" width="20px" style="vertical-align: middle;" onclick="getmonth(document.getElementById('mn1').value,document.getElementById('mn2').value,document.getElementById('mn3').value,document.getElementById('mn4').value)"/>
                              </td>    
                          </tr>
                          <tr>
                              <td>
                                  <br>
                              </td>
                          </tr>
                          <tr>
                              <td><b style="color: #e44f2b;font-size: 17px;">Y</b>ear&nbsp;:&nbsp;</td>
                              <td>
                                  <input type="text" name="date" style="padding: 5px;width: 74px;" id="ye"/>
                                  <b style="color: #e44f2b;font-size: 17px;">&nbsp;to&nbsp;</b> 
                                 <input type="text" name="date" style="padding: 5px;width: 74px;" id="ye1"/> 
                                <img src="images/update2.png" width="20px" style="vertical-align: middle;" onclick="yeye1(document.getElementById('ye').value,document.getElementById('ye1').value);"/>
                              </td>    
                          </tr>
                      </table>
                        
                        
                  </div>    
              </div><br>
              
              <div class="bmain" id="printt">
                  
              </div><br>
          </div>
        <div style="clear: both;">
            
        </div>
    </div>
   <?php
        require_once 'footer.php';
   ?>
<script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>