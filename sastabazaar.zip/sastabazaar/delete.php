<?php
    require_once 'conn.php';
    if (isset($_REQUEST[delete]))
    {
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="inquire")
            {
                $del= mysql_query("delete from inquire where inquireid='$_REQUEST[id]'");
    
                header ('location:manageinq.php?base=1#inquire');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="inquire")
            {
                $del=mysql_query("delete from inquire where userid='$_SESSION[user]'");
    
                header ('location:manageinq.php?base=1#inquire');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="review")
            {
                $del= mysql_query("delete from review where reviewid='$_REQUEST[id]'");
    
                header ('location:managereview.php?base=1#review');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="review")
            {
                $del=mysql_query("delete from review where userid='$_SESSION[user]'");
    
                header ('location:managereview.php?base=1#review');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="cart")
            {
                $del= mysql_query("delete from cart where cartid='$_REQUEST[id]'");
    
                header ('location:managecart.php?base=1#cart');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="cart")
            {
                $del=mysql_query("delete from cart where userid='$_SESSION[user]'");
    
                header ('location:managecart.php?base=1#cart');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="wish")
            {
                $del= mysql_query("delete from wishlist where wishlistid='$_REQUEST[id]'");
    
                header ('location:managewishlist.php?base=1#wish');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="wish")
            {
                $del=mysql_query("delete from wishlist where userid='$_SESSION[user]'");
    
                header ('location:managewishlist.php?base=1#wish');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="feedback")
            {
                $del= mysql_query("delete from feedback where feedid='$_REQUEST[id]'");
    
                header ('location:managefeedback.php?base=1#feed');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="feedback")
            {
                $del=mysql_query("delete from feedback");
    
                header ('location:managefeedback.php?base=1#feed');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="emaile")
            {
                $del= mysql_query("delete from email where eid='$_REQUEST[id]'");
    
                header ('location:manageemail.php?base=1#emaile');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="emaile")
            {
                $del=mysql_query("delete from email");
    
                header ('location:manageemail.php?base=1#emaile');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="contact")
            {
                $del= mysql_query("delete from contact where conid='$_REQUEST[id]'");
    
                header ('location:managecontact.php?base=1#contact');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="contact")
            {
                $del=mysql_query("delete from contact");
    
                header ('location:managecontact.php?base=1#contact');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="adrate")
            {
                $del= mysql_query("delete from ad_rate where ad_rate_id='$_REQUEST[id]'");
    
                header ('location:managead_rate.php?base=1#adrate');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="adrate")
            {
                $del=mysql_query("delete from ad_rate");
    
                header ('location:managead_rate.php?base=1#adrate');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="country")
            {
                $del= mysql_query("delete from country where countryid='$_REQUEST[id]'");
    
                header ('location:managecountry.php?base=1#country');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="country")
            {
                $del=mysql_query("delete from country");
    
                header ('location:managecountry.php?base=1#country');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="state1")
            {
                $del= mysql_query("delete from state where stateid='$_REQUEST[id]'");
    
                header ('location:managestate.php?base=1#state1');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="city")
            {
                $del= mysql_query("delete from city where cityid='$_REQUEST[id]'");
    
                header ('location:managecity.php?base=1#city1');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="user")
            {
                $del= mysql_query("delete from registration where usertype='$_REQUEST[id]'");
    
                header ('location:manageuser.php?base=1#user');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="user")
            {
                $del=mysql_query("delete from registration");
    
                header ('location:manageuser.php?base=1#user');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="maincate")
            {
                $del= mysql_query("delete from maincategories where maincateid='$_REQUEST[id]'");
    
                header ('location:managemaincategories.php?base=1#maincate');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="maincate")
            {
                $del=mysql_query("delete from maincategories");
    
                header ('location:managemaincategories.php?base=1#maincate');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="subcate")
            {
                $del= mysql_query("delete from subcategories where subcateid='$_REQUEST[id]'");
    
                header ('location:managesubcategories.php?base=1#subcate');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="company")
            {
                $del= mysql_query("delete from company where companyid='$_REQUEST[id]'");
    
                header ('location:managecompany.php?base=1#company');
            }
        }
        if ($_REQUEST[id]!="")
        {
            if ($_REQUEST[ek]=="sadpost")
            {
                $del= mysql_query("delete from product where productid='$_REQUEST[id]'");
    
                header ('location:manageselleradpost.php?base=1#sadpost');
            }
        }
        if ($_REQUEST[id]=="")
        {
            if ($_REQUEST[all]=="sadpost")
            {
                $del=mysql_query("delete from product");
    
                header ('location:manageselleradpost.php?base=1#sadpost');
            }
        }
    }
    if (isset($_REQUEST[cancel]))
    {
        if ($_REQUEST[ek]=="inquire" || $_REQUEST[all]=="inquire")
        {
            header ('location:manageinq.php?base=1#inquire');
        }
        if ($_REQUEST[ek]=="review" || $_REQUEST[all]=="review")
        {
            header ('location:managereview.php?base=1#review');
        }
        if ($_REQUEST[ek]=="cart" || $_REQUEST[all]=="cart")
        {
            header ('location:managecart.php?base=1#cart');
        }
        if ($_REQUEST[ek]=="wish" || $_REQUEST[all]=="wish")
        {
            header ('location:managewishlist.php?base=1#wish');
        }
        if ($_REQUEST[ek]=="feedback" || $_REQUEST[all]=="feedback")
        {
            header ('location:managefeedback.php?base=1#feed');
        }
        if ($_REQUEST[ek]=="emaile" || $_REQUEST[all]=="emaile")
        {
            header ('location:manageemail.php?base=1#emaile');
        }
        if ($_REQUEST[ek]=="contact" || $_REQUEST[all]=="contact")
        {
            header ('location:managecontact.php?base=1#contact');
        }
        if ($_REQUEST[ek]=="adrate" || $_REQUEST[all]=="adrate")
        {
            header ('location:managead_rate.php?base=1#adrate');
        }
        if ($_REQUEST[ek]=="country" || $_REQUEST[all]=="country")
        {
            header ('location:managecountry.php?base=1#country');
        }
        if ($_REQUEST[ek]=="state")
        {
            header ('location:managestate.php?base=1#state1');
        }
        if ($_REQUEST[ek]=="city")
        {
            header ('location:managecity.php?base=1#city1');
        }
        if ($_REQUEST[ek]=="user" || $_REQUEST[all]=="user")
        {
            header ('location:manageuser.php?base=1#user');
        }
        if ($_REQUEST[ek]=="maincate" || $_REQUEST[all]=="maincate")
        {
            header ('location:managemaincategories.php?base=1#maincate');
        }
        if ($_REQUEST[ek]=="subcate")
        {
            header ('location:managesubcategories.php?base=1#subcate');
        }
        if ($_REQUEST[ek]=="company")
        {
            header ('location:managecompany.php?base=1#company');
        }
        if ($_REQUEST[ek]=="sadpost" || $_REQUEST[all]=="sadpost")
        {
            header ('location:manageselleradpost.php?base=1#sadpost');
        }
    }
?>
<!DOCTYPE HTML>
<?php
    require_once 'head.php';
?>
<body>
    <div style="opacity:0.2;">
	<?php
            require_once 'header.php';
        ?>
        <?php
            require_once 'menu.php';
        ?>
        <?php
            require_once 'header1.php';
        ?>
    </div>
</div>
     <!------------End Header ------------>
 
     
     
   <?php
            require_once 'footer.php';
   ?>
     </div>
    <div style="margin-top: -700px;position: fixed;margin-left: 550px;">
       
            <?php
                if ($_REQUEST[ek]!="" || $_REQUEST[all]!="")
                {
            ?>
            <div>
                <img src="images/delete2.png" align="center" width="130px"/>
            </div>
            <div class="msg">
                <font>
                    are you sure want to remove ?
                </font>
            </div>
            <div class="btn">
                <form action="" method="post">
                    <button type="submit" name="delete">delete</button>
                    <button type="submit" name="cancel">cancel</button>
                </form>
            </div>
            <?php
                }
                else
                {
            ?>
            
            <?php
                }
            ?>
        
    </div>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"> </a>
    <script type="text/javascript" src="js/navigation.js"></script>
</body>
</html>

